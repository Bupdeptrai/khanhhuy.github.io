-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: time_rec_jp
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `request`
--
drop database if exists `time_rec_jp`;
create database time_rec_jp;
use time_rec_jp;

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `REQUEST_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESHEET_ID` bigint(20) NOT NULL,
  `TIME_IN` char(4) DEFAULT NULL,
  `TIME_IN_REQUEST` char(4) DEFAULT NULL,
  `TIME_OUT` char(4) DEFAULT NULL,
  `TIME_OUT_REQUEST` char(4) DEFAULT NULL,
  `DATE_FROM` char(8) DEFAULT NULL,
  `DATE_TO` char(8) DEFAULT NULL,
  `STYLE_OFF` char(2) DEFAULT NULL,
  `REASON` varchar(256) NOT NULL,
  `NOTE` varchar(256) DEFAULT NULL,
  `STATUS` varchar(10) NOT NULL,
  `CREATE_DATE` date NOT NULL,
  `CREATOR_ID` varchar(8) NOT NULL,
  `APPROVAL_DATE` date DEFAULT NULL,
  `APPROVER_ID` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`REQUEST_ID`),
  KEY `timesheet_id_idx` (`TIMESHEET_ID`),
  CONSTRAINT `FKcv847j97famf5hrgtr0f1ok9m` FOREIGN KEY (`TIMESHEET_ID`) REFERENCES `timesheet` (`TIMESHEET_ID`),
  CONSTRAINT `timesheet_id` FOREIGN KEY (`TIMESHEET_ID`) REFERENCES `timesheet` (`TIMESHEET_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(50) NOT NULL,
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `special_day`
--

DROP TABLE IF EXISTS `special_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `special_day` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DATE` varchar(8) NOT NULL,
  `BASIC_WORKING_TIME` decimal(3,2) NOT NULL,
  `CONTENT` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `HOL_ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL,
  `DATE` varchar(8) NOT NULL,
  `DATE_OF_WEEK` varchar(2) NOT NULL,
  PRIMARY KEY (`HOL_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `GROUP_ID` varchar(50) NOT NULL,
  `GROUP_NAME` varchar(50) NOT NULL,
  `STATUS` int(1) NOT NULL,
  `CREATE_ID` varchar(50) NOT NULL,
  `CREATE_DATE` date NOT NULL,
  `UPDATE_ID` varchar(50),
  `UPDATE_DATE` date DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `timesheet`
--

DROP TABLE IF EXISTS `timesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timesheet` (
  `TIMESHEET_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TIMESHEET_USER_ID` bigint(20) NOT NULL,
  `DATE` varchar(2) NOT NULL,
  `TIME_IN` char(4) DEFAULT NULL,
  `TIME_OUT` char(4) DEFAULT NULL,
  `BREAK_TIME` decimal(4,2) DEFAULT NULL,
  `TIME_OT` decimal(4,2) DEFAULT NULL,
  `TIME_WE_OT` decimal(4,2) DEFAULT NULL,
  `TIME_ON` decimal(4,2) DEFAULT NULL,
  `TIME_WE_ON` decimal(4,2) DEFAULT NULL,
  `TIME_SUM` decimal(4,2) DEFAULT NULL,
  `UPDATE_DATE` date DEFAULT NULL,
  `UPDATE_ID` varchar(8) DEFAULT NULL,
  `OFF_DAY` varchar(150) DEFAULT NULL,
  
  PRIMARY KEY (`TIMESHEET_ID`),
  UNIQUE KEY `TIMESHEET_UNIQUE` (`TIMESHEET_USER_ID`,`DATE`),
  CONSTRAINT `FKuvfvt8bqj129uvo65yb3u8gt` FOREIGN KEY (`TIMESHEET_USER_ID`) REFERENCES `timesheet_user` (`TIMESHEET_USER_ID`),
  CONSTRAINT `Timesheet_FK` FOREIGN KEY (`TIMESHEET_USER_ID`) REFERENCES `timesheet_user` (`TIMESHEET_USER_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timesheet_user`
--

DROP TABLE IF EXISTS `timesheet_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timesheet_user` (
  `TIMESHEET_USER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` varchar(8) NOT NULL,
  `MONTH` varchar(2) NOT NULL,
  `YEAR` varchar(4) NOT NULL,
  PRIMARY KEY (`TIMESHEET_USER_ID`),
  UNIQUE KEY `UNIQUE` (`USER_ID`,`MONTH`,`YEAR`),
  CONSTRAINT `FKkud3p4vlkhk9nake6adh4nhnf` FOREIGN KEY (`USER_ID`) REFERENCES `user` (`USER_ID`),
  CONSTRAINT `ts_user_id` FOREIGN KEY (`USER_ID`) REFERENCES `user` (`USER_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `USER_ID` varchar(8) NOT NULL,
  `STAFF_ID` varchar(8) NOT NULL,
  `NAME` varchar(160) NOT NULL,
  `PASSWORD` varchar(160) NOT NULL,
  `EMAIL` varchar(120) NOT NULL,
  `PHONE` varchar(20) DEFAULT NULL,
  `ROLE_ID` int(11) NOT NULL,
  `GROUP_ID` varchar(50) NOT NULL,
  `DEL_FLG` char(1) NOT NULL,
  `PWD_FLG` char(1) NOT NULL,
  `CREATE_DATE` date NOT NULL,
  `CREATE_ID` varchar(8) NOT NULL,
  `UPDATE_DATE` date DEFAULT NULL,
  `UPDATE_ID` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `EMAIL_UNIQUE` (`EMAIL`),
  UNIQUE KEY `STAFF_ID_UNIQUE` (`STAFF_ID`),
  UNIQUE KEY `USER_ID_UNIQUE` (`USER_ID`),
  KEY `groups_id_idx` (`GROUP_ID`),
  CONSTRAINT `FKfa83d3bb616ectwmy9qd0hqlu` FOREIGN KEY (`GROUP_ID`) REFERENCES `groups` (`GROUP_ID`),
  CONSTRAINT `ts_groups_id` FOREIGN KEY (`GROUP_ID`) REFERENCES `groups` (`GROUP_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  KEY `role_id_idx` (`ROLE_ID`),
  CONSTRAINT `FKn82ha3ccdebhokx3a8fgdqeyy` FOREIGN KEY (`ROLE_ID`) REFERENCES `role` (`ROLE_ID`),
  CONSTRAINT `role_id` FOREIGN KEY (`ROLE_ID`) REFERENCES `role` (`ROLE_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
  
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-20 10:01:53
-- Insert Role
INSERT INTO role (ROLE_NAME)
VALUES ('ROLE_ADMIN');
INSERT INTO role (ROLE_NAME)
VALUES ('ROLE_LEADER');
INSERT INTO role (ROLE_NAME)
VALUES ('ROLE_MEMBER');
-- Insert Group
INSERT INTO `time_rec_jp`.`groups` (`GROUP_ID`, `GROUP_NAME`, `STATUS`, `CREATE_ID`, `CREATE_DATE`, `UPDATE_ID`, `UPDATE_DATE`)
VALUES ('GR0000', 'MANAGER', '1', 'ARCH0001', '2018-07-09', null, null);
INSERT INTO `time_rec_jp`.`groups` (`GROUP_ID`, `GROUP_NAME`, `STATUS`, `CREATE_ID`, `CREATE_DATE`, `UPDATE_ID`, `UPDATE_DATE`) 
VALUES ('GR0001', 'FREE', '1', 'ARCH0001', '2018-07-09', null, null);
-- Insert User
INSERT INTO `time_rec_jp`.`user` (`USER_ID`, `STAFF_ID`, `NAME`, `PASSWORD`, `EMAIL`, `ROLE_ID`, `GROUP_ID`, `DEL_FLG`, `PWD_FLG`, `CREATE_DATE`, `CREATE_ID`)
 VALUES ('ARCH0001', 's0001', 'ADMIN', '$2a$10$QZNcgn2vGWSCElnLameesOHBtvUkCh87kooetD7Ad.YxGdqj7lxmK', 'ADMIN@arch-vietnam.vn', '1', 'GR0000', '1', '', '2018-01-07', 'ARCH0001');
