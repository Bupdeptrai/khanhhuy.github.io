
  $(document).ready(function() {
	var start, end;
	var radio = $("#radio:checked").val()
	  $("#date-picker-from").change(function(){
	  	start = $(this).val();
	  });
	  $("#date-picker-to").change(function(){
	  	end = $(this).val();
	  	
	    var dateSum = $("#dateSum");
	    var startDate = new Date(start);
	    var endDate = new Date(end);
	    
	    // Get date, month, year Start
	    var dateStart = startDate.getDate();
	    var monthStart = startDate.getMonth();
	    var yearStart = startDate.getFullYear();
	    
	    // Get date, month, year End
	    var dateEnd = endDate.getDate();
	    var monthEnd = endDate.getMonth();
	    var yearEnd = endDate.getFullYear();
	    	    
	    var month = monthEnd - monthStart;
	       
	    var endDate = new Date(end);
	    var oneDay = 24*60*60*1000;
	    var timeDiff = Math.round(Math.abs((startDate.getTime() - endDate.getTime())/(oneDay)))+1;
	    
	    if(timeDiff < 0){
	    	alert($('#message_TogreatFrom').val());
	    	
	    }


	   sum = countDate(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd); 
	   document.getElementById('dateSum').value =sum;
	  });
  }	); 
	// Count date in month
		function countDayInMonth(month, year) {
			return new Date(year, month + 1, 0).getDate();
		}
	// Get Date Name of Week
		function getDateName(date, month, year) {
			var dateFunction = new Date(year, month, date);
			return dateFunction.getDay();
		}
	// Find Sunday, Saturday
		function getDateNameSatSun(date, month, year) {
			var dateName = getDateName(date, month, year);
			if (dateName == 0 || dateName == 6) {
				return 0;
			} else {
				return 1;
			}
		}
	// Count Day MonthStart
		function countDateMonthStart(dateStart, monthStart, yearStart) {
			var countDate = 0;
			var dateInMonth = countDayInMonth(monthStart, yearStart);		
			
			for (var i = dateStart; i <= dateInMonth; i++) {
				if (getDateNameSatSun(i, monthStart, yearStart) == 1) {
					countDate++;
				}			
			}
			return countDate;
		}
	// Count Day MonthEnd
		function countDateMonthEnd(dateEnd, monthEnd, yearEnd) {
			var countDate = 0;		
			
			for (var i = 1; i <= dateEnd; i++) {
				if (getDateNameSatSun(i, monthEnd, yearEnd) == 1) {
					countDate++;
				}			
			}
			return countDate;
		}
	// Count Offday Month
		function countOffDateMonth(month, year) {
			var countDate = 0;	
			var dateInMonth = countDayInMonth(month, year);
			
			for (var i = 1; i <= dateInMonth; i++) {
				if (getDateNameSatSun(i, month, year) == 1) {
					countDate++;
				}			
			}
			return countDate;
		}
	// Count Offday Month
		function countDate(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd) {
			var countDate = 0;
			var month = monthEnd - monthStart;
			
			// 1 Month
			if (yearEnd == yearStart) {
				countDate = countDateOneYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd);
			}
			else {
				countDate = countDateYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd);
			}
			
			return countDate;			
		}
		
	// Count Offday One Year
		function countDateOneYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd) {
			var countDate = 0;
			var month = monthEnd - monthStart;
			
			// 1 Month
			if (month == 0) {
				for (var i = dateStart; i <= dateEnd; i++) {
					if (getDateNameSatSun(i, monthStart, yearStart) == 1) {
						countDate++;
					}			
				}
			}
			else if (month == 1) {
				// Add OffDate Month Start
				countDate = countDateMonthStart(dateStart, monthStart, yearStart);
				// Add OffDate Month End
				countDate = countDate + countDateMonthEnd(dateEnd, monthEnd, yearEnd);
			}
			else if (month > 1){
				countDate = countDateMonthStart(dateStart, monthStart, yearStart);
				countDate = countDate + countDateMonthEnd(dateEnd, monthEnd, yearEnd);
				
				var iStart = monthStart + 1;
				var iEnd = monthEnd - 1;
				for (var i = iStart; i <= iEnd; i++) {
					countDate = countDate + countOffDateMonth(iStart, yearStart);
				}
			}		
			
			return countDate;			
		}
		
		// Count Offday Year
		function countDateYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd) {
			var countDate = 0;
			var year = yearEnd - yearStart;

			// 1 year
			if (year == 1) {
				countDate = countDateTwoYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd);
			} else {
				countDate = countDateThreeYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd);
			}
			
			return countDate;			
		}
		
		// Count Offday Two Year
		function countDateTwoYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd) {
			var countDate = 0;
			var year = yearEnd - yearStart;
			
			// Add OffDate Month Start
			countDate = countDateMonthStart(dateStart, monthStart, yearStart);
				
			// Count date in YearStart
			var iStart = monthStart + 1;
			for (var i = iStart; i <= 11; i++) {
				countDate = countDate + countOffDateMonth(iStart, yearStart);
			}			
			
			// Count date in YearEnd
			for (var j = 0; j < monthEnd; j++) {
				countDate = countDate + countOffDateMonth(j, yearEnd);
			}	
			
			// Add OffDate Month End
			countDate = countDate + countDateMonthEnd(dateEnd, monthEnd, yearEnd);			
			return countDate;			
		}
		
		// Count Offday Three.... Year
		function countDateThreeYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd) {
			var countDate = 0;
			var year = yearEnd - yearStart;
			
			// Get Offdate year first and year finish
			countDate = countDateTwoYear(dateStart, monthStart, yearStart, dateEnd, monthEnd, yearEnd)
			
			iYearStart = yearStart + 1;			
			for (var yearNext = iYearStart; yearNext < yearEnd; yearNext++) {
				for (var monthNext = 0; monthNext <= 11; monthNext++) {
					countDate = countDate + countOffDateMonth(monthNext, yearNext);
				}
			}
			
			return countDate;			
		}
		




