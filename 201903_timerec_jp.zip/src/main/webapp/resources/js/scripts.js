function addURL(element) {
	$(element).attr('href', function() {
		if (getLang() === '') {
			return 'login?logout';
		} else {
			return 'login?logout&lg=' + getLang();
		}
	});
}

function changeLang(element, value) {
	$(element).attr('href', function() {
		var url = location.href;
		if (url.indexOf("?error") != -1) {
			url = url.replace("?error","");
		}
		
		window.location.href = setGetParameter(url, "lg", value);
	});
}

function getLang() {
	var urlParams = getTokens();
	if (urlParams.lg === undefined) {
		return '';
	} else
		return urlParams.lg;
}

function getTokens() {
	var tokens = [];
	var query = location.search;
	query = query.slice(1);
	query = query.split('&');
	$.each(query, function(i, value) {
		var token = value.split('=');
		var key = decodeURIComponent(token[0]);
		var data = decodeURIComponent(token[1]);
		tokens[key] = data;
	});
	return tokens;
}

function startTime() {
	var today = new Date();
	var h = today.getHours();
	var m = today.getMinutes();
	var s = today.getSeconds();
	var date = today.getDate();
	var month = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
			"11", "12" ];
	var year = today.getFullYear();
	m = addZero(m);
	s = addZero(s);
	date = addZero(date);
	document.getElementById('header-time').innerHTML = " <span style='font-size: 25px;'> "
			+ year
			+ "/"
			+ month[today.getMonth()]
			+ "/"
			+ date
			+ "</span> <span>  " + h + ":" + m + ":" + s + "</span></h4>";
	var t = setTimeout(startTime, 500);
}
function addZero(i) {
	if (i < 10) {
		i = "0" + i
	}
	;
	return i;
}

function currentYm() {
	var today = new Date();
	var month = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
			"11", "12" ];
	var year = today.getFullYear();
	var currYm = year + "/" + month[today.getMonth()];
	document.getElementById('month-picker').value = currYm;
}

function currentYmd() {
	var today = new Date();
	var year = today.getFullYear();
	var month = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
			"11", "12" ];
	var date = today.getDate();
	date = addZero(date);
	var currYmd = year + "/" + month[today.getMonth()] + "/" + date;
	document.getElementById('date-picker').value = currYmd;
}

function setGetParameter(url, paramName, paramValue) {
	//url = window.location.href;
	var hash = location.hash;
	url = url.replace(hash, '');
	if ((url.split("/"))[3] === '') {
		url = url + "login";
	}
	if (url.indexOf(paramName + "=") >= 0) {
		var prefix = url.substring(0, url.indexOf(paramName));
		var suffix = url.substring(url.indexOf(paramName));
		suffix = suffix.substring(suffix.indexOf("=") + 1);
		suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix
				.indexOf("&")) : "";
		url = prefix + paramName + "=" + paramValue + suffix;
	} else {
		if (url.indexOf("?") < 0)
			url += "?" + paramName + "=" + paramValue;
		else
			url += "&" + paramName + "=" + paramValue;
	}
	return url + hash;
}

function formatDateChange() {
	var getdate = document.getElementById('date-format').value;
    var d = new Date(getdate),
        month = d.getMonth() + 1,
        day = d.getDate(),
        year = d.getFullYear();
    var month = addZero(month);
    var day = addZero(day);

    document.getElementById('date-format').value = [year, month, day].join('/');
}

function formatDate() {
    document.getElementById('date-format').value = 'yyyy'+'/'+'mm'+'/'+'dd';
}

/*popup confim checkin checkout*/
var modalConfirm = function() {

	$("#btn-confirm").on("click", function() {
		$("#mi-modal-chkin").modal('show');
	});
	
	 $("#btn-confirm-checkout").on("click", function() {
		$("#mi-modal-chkout").modal('show');
	}); 
	 
};

 $("#modal-btn-yes").on("click", function() {
	window.location = $(this).attr("url");
	  $("#mi-modal-chkin").modal('hide');  
});

$("#modal-btn-no").on("click", function() {
	 $("#mi-modal-chkin").modal('hide'); 
}); 

$("#modal-btn-Yes").on("click", function() {
	window.location = $(this).attr("url");
	  $("#mi-modal-chkout").modal('hide');  
});

$("#modal-btn-No").on("click", function() {
	 $("#mi-modal-chkout").modal('hide'); 
});
	
modalConfirm(function(confirm) {
	
});

