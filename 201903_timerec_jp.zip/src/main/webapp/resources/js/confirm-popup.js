//Author: Tra Tan Hieu 
//Date Created: 30/03/2018
//Version: 1.0.0 

$(document).ready(function() {

	$('button[rel=popover]').each(function(){
		var el = $(this);

		el.popover({
			trigger: 'focus',
	        html: true,
			content: '<div class="text-center confirm"><button '+
				'class="btn btn-sm btn-default confirm-yes-button" '+
				'url="' + el.attr("url") + '" '+
				'onclick="confirmYes(this)" '+
				'><strong>&#10003;</strong> Yes</button>'+
				'<button class="btn btn-sm btn-default confirm-no-button" '+
				'onclick="confirmNo(this)" '+
				'><strong>&#10008;</strong> No</button></div>'
		});
	});
});

function confirmYes(el) {
	window.location = el.getAttribute("url");
}

function confirmNo() {
	$('button[popup=popover]').popover('hide');
}