$(document).ready(function() {   
var num;
var numArr;
  $(".timeFormat").each(function(){
  num = $(this).html();
  var checkArr = [0,1,2,3,4,5,6,7,8,9];
  numArr = num.split(".");
   if((checkArr.includes(parseInt(numArr[1])) && numArr[1].substring(0,1) != '0') || numArr[1] == '0' ){
  num = numArr[0] + ":" + numArr[1] + "0";
  }else{
  num = numArr[0] + ":" + numArr[1];
  }
  $(this).html(num);
  });
});