/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Class name: TimeRecApplication
 *
 * Launch a Spring application
 */

@SpringBootApplication
public class TimeRecApplication {

    public static void main(String[] args) {
        SpringApplication.run(TimeRecApplication.class, args);
    }
}
