package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import arch.timerec.model.Groups;
import arch.timerec.model.User;

@Repository
public interface GroupRepository extends CrudRepository<Groups,String>{
	
	Groups findByGroupId(String groupId);

	@Transactional
	@Modifying
	@Query(value = "delete from  groups where GROUP_ID = ?1",nativeQuery=true)
	int deleGroupById(String groupId);

	@Query(value = "SELECT * FROM groups where GROUP_NAME like %?1%" , nativeQuery = true)
	List<Groups> findByGroupName(String name);
	@Query(value = "SELECT * FROM groups where GROUP_ID like %?1%" , nativeQuery = true)
	List<Groups> searchByGroupId(String id);
    
	
}
