/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: dam-vanhoang
 * Create day: 2018/06/05
 * Version: 1.0
 */

package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import arch.timerec.model.Holiday;

/*
 * Class name: UserDetailsServiceImpl
 *
 * Provide the basic CRUD functions of Role table on a repository
 */
public interface HolidayRepository extends CrudRepository<Holiday, Integer> {
	@Query(value = "SELECT group_concat(HOL_ID) FROM holiday WHERE substring(DATE,1,4) = ?1", nativeQuery = true)
	String getListIdByYear(String yearNow);
	
	@Query(value = "Select * from holiday where substring(date,1,4) = ?1", nativeQuery = true)
	List<Holiday> findByYear(String year);
	
	Holiday findByDate(String date);
}
