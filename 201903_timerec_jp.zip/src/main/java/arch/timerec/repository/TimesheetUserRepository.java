/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: tran-ngocmy
 * Create day: 2017/12/11
 * Version: 1.0
 */

package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;

public interface TimesheetUserRepository extends CrudRepository<TimesheetUser, Integer>{
	
    TimesheetUser findByUser(User user);
    List<TimesheetUser> findByTimesheetUserId(int timesheetuserid);

    @Query(value="SELECT * FROM timesheet_user tsu WHERE tsu.USER_ID = ?1 AND tsu.MONTH = ?2 AND tsu.YEAR = ?3",nativeQuery = true)
    List<TimesheetUser> findByUserIdMonthYear(String userId, String month, String year);

    @Query(value="SELECT * FROM timesheet_user tsu WHERE tsu.YEAR = ?1 AND tsu.MONTH = ?2 ",nativeQuery = true)
    List<TimesheetUser> findByMonthYear(String year, String month);    

    @Query(value="SELECT * FROM timesheet_user as tsu WHERE tsu.USER_ID = ?1 AND tsu.MONTH = ?2 AND tsu.YEAR = ?3", nativeQuery = true)
    TimesheetUser findByTimesheetUserUsId(String user_id, String month, String year);
    
    @Query(value="SELECT * FROM timesheet_user tsu WHERE tsu.USER_ID = ?1 AND tsu.YEAR = ?2",nativeQuery = true)
    List<TimesheetUser> findByUserIdYear(String userId, String year);
    
    @Query(value="SELECT * FROM timesheet_user tsu"   		
    		+ " WHERE tsu.YEAR = ?1 AND tsu.MONTH = ?2",nativeQuery = true)
    List<TimesheetUser> findByMonthYearAdmin(String year, String month);    
    
    @Query(value="SELECT * FROM timesheet_user as tsu "
    		+ " inner join user as us on us.USER_ID = tsu.USER_ID"
            + " inner join groups as gr on gr.GROUP_ID = us.GROUP_ID"
    		+ " WHERE tsu.YEAR = ?1 AND tsu.MONTH = ?2 AND gr.GROUP_ID= ?3",nativeQuery = true)
    List<TimesheetUser> findByMonthYearLeader(String year, String month, String groupId);
}
