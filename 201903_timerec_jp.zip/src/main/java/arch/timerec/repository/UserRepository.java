/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import arch.timerec.model.User;

/*
 * Class name: UserDetailsServiceImpl
 *
 * Provide the basic CRUD functions of Role table on a repository
 */
public interface UserRepository extends CrudRepository<User, Integer> {

    User findByEmail(String email);
   
    User findByUserId(String userId);
    User findByName(String name);
    User deleteUserByUserId(String userId); 
    @Query(value = "select us.* \n"
            + "from user as us\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + "where  NAME  like %?1% " , nativeQuery = true)
    List<User> listSearchName(String search);
    
    @Query(value = "select us.* \n"
            + "from user as us\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + "where  user_ID like %?1% " , nativeQuery = true)
    List<User> listSearchUserId(String search);
    
    @Query(value = "select us.* \n"
            + "from user as us\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + "where GROUP_NAME like %?1%" , nativeQuery = true)
    List<User> listSearchGroupName(String search);
     
    
    @Query(value = "select * from user as u" +
    		" join groups as g on g.GROUP_ID = u.GROUP_ID" +
    		" join role as r on r.ROLE_ID = u.ROLE_ID" +
    		" WHERE g.GROUP_ID =?1" +
    		" ORDER BY r.ROLE_NAME ASC",nativeQuery = true)
    List<User> findGroupMember(String groupId);
    
    @Transactional
    @Modifying
    @Query(value = "update user set GROUP_ID = 'GR0001' where GROUP_ID = ?1",nativeQuery = true)
    int findByUserGroup(String groupId);
    
    @Query(value = "select * from user as u" +
    		" join groups as g on g.GROUP_ID = u.GROUP_ID" +
    		" join role as r on r.ROLE_ID = u.ROLE_ID" +
    		" WHERE g.GROUP_ID =?1 and u.ROLE_ID = 2" +
    		" ORDER BY r.ROLE_NAME ASC",nativeQuery = true)
    List<User> findGroupLeader(String groupId);
    
   
}
