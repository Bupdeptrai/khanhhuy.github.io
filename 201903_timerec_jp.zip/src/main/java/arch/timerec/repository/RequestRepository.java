package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import arch.timerec.model.Request;

public interface RequestRepository extends CrudRepository<Request, Integer> {

    Request findByRequestId(int requestId);
    
    @Query(value = "select * from request as rq\n" 
    		+ " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
    		+ " where u.USER_ID like %?1%",nativeQuery = true) 
    List<Request> findByUserId(String userId);	

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.NOTE, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findAllRequest();
    
    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO,  rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " where us.USER_ID like %?1%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\") , us.USER_ID", nativeQuery = true)
    List<Request> findByUserIdGroupAdmin(String id);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " where us.NAME like %?1%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findByNameGroupAdmin(String name);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " where rq.DATE_FROM = ?1"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findByDateGroupAdmin(String dateFrom);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " where rq.STATUS like %?1%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findByStatusGroupAdmin(String status);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + " where g.GROUP_ID = ?1 "
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findAllRequestMemberGropup(String groupid);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + " where us.USER_ID like %?1% and g.GROUP_ID like %?2%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\") , DATE, us.USER_ID", nativeQuery = true)
    List<Request> findByUserId(String id,String groupid);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + " where us.NAME like %?1% and g.GROUP_ID like %?2%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findByName(String name,String groupid);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + " where rq.DATE_FROM like %?1% and g.GROUP_ID like %?2%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"),  us.USER_ID", nativeQuery = true)
    List<Request> findByDate(String dateFrom, String groupid);

    @Query(value = "select rq.REQUEST_ID,us.USER_ID, rq.CREATE_DATE, rq.APPROVAL_DATE,rq.CREATOR_ID,rq.STYLE_OFF,"
            + " rq.APPROVER_ID, rq.DATE_FROM, rq.DATE_TO, rq.NOTE , us.USER_ID , us.NAME,"
            + " rq.TIME_IN, rq.TIME_IN_REQUEST, rq.TIME_OUT, rq.TIME_OUT_REQUEST," + " rq.REASON, rq.STATUS, ts.TIMESHEET_ID\n"
            + " from request as rq\n"
            + " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
            + " where rq.STATUS like %?1% and g.GROUP_ID like %?2%"
            + " order by field(rq.STATUS, \"pending\", \"accepted\",\"denied\"), us.USER_ID", nativeQuery = true)
    List<Request> findByStatus(String status,String groupid);
    
    @Query(value = "select count(*) from request\n"
    		  	+ "where status =?1",nativeQuery=true)
    Integer findCountReqPending(String status);
    
    @Query(value = "select count(*) from request as rq\n"
    		+ " inner join timesheet as ts on ts.TIMESHEET_ID = rq.TIMESHEET_ID\n"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
            + " inner join user as us on us.USER_ID = tsu.USER_ID\n"
            + " inner join groups as g on g.GROUP_ID = us.GROUP_ID\n"
		  	+ " where rq.status =?1 and us.group_id = ?2",nativeQuery=true)
	Integer findCountReqLeaderPending(String status,String groupId);

   
  
}
