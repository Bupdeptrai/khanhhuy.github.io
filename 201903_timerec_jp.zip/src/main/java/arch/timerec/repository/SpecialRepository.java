/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import arch.timerec.model.Special;

/*
 * Class name: UserDetailsServiceImpl
 *
 * Provide the basic CRUD functions of Role table on a repository
 */
public interface SpecialRepository extends CrudRepository<Special, Integer> {
	@Query(value = "SELECT group_concat(id) FROM special_day WHERE substring(date,1,4) = ?1", nativeQuery = true)
	String getListIdByYear(String yearNow);
	
	@Query(value = "Select * from special_day where substring(date,1,4) = ?1", nativeQuery = true)
	List<Special> findByYear(String year);
}
	