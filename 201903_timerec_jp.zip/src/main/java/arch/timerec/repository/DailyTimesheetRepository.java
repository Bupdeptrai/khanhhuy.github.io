/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: nguyen-vanhoang
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import arch.timerec.model.Timesheet;

public interface DailyTimesheetRepository extends CrudRepository<Timesheet, Integer> {

	@Query(value = "select ts.TIMESHEET_ID,tsu.TIMESHEET_USER_ID,us.USER_ID, us.NAME, ts.DATE,ts.BREAK_TIME, "
            + "ts.TIME_IN, ts.TIME_OUT,ts.OFF_DAY,"
            + "ts.TIME_OT, ts.TIME_WE_OT,ts.TIME_ON,ts.TIME_WE_ON,ts.TIME_SUM, ts.UPDATE_DATE,ts.UPDATE_ID"
            + " from timesheet as ts"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID"
            + " inner join user as us on us.USER_ID = tsu.USER_ID"
            + " where ts.DATE = ?1 and tsu.MONTH = ?2 and tsu.YEAR = ?3", nativeQuery = true)
    List<Timesheet> findAllTimesheetGroupAdmin(String day, String month, String year);
    
    @Query(value = "select ts.TIMESHEET_ID,tsu.TIMESHEET_USER_ID,us.USER_ID, us.NAME, ts.DATE,ts.BREAK_TIME, "
            + "ts.TIME_IN, ts.TIME_OUT,ts.OFF_DAY,"
            + "ts.TIME_OT, ts.TIME_WE_OT,ts.TIME_ON,ts.TIME_WE_ON,ts.TIME_SUM, ts.UPDATE_DATE,ts.UPDATE_ID"
            + " from timesheet as ts"
            + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID"
            + " inner join user as us on us.USER_ID = tsu.USER_ID"
            + " inner join groups as gr on gr.GROUP_ID = us.GROUP_ID"
            + " where ts.DATE = ?1 and tsu.MONTH = ?2 and tsu.YEAR = ?3 and gr.GROUP_ID = ?4", nativeQuery = true)
    List<Timesheet> findAllTimesheetGroupLeader(String day, String month, String year, String groupId);
}
