/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: tran-ngocmy
 * Create day: 2017/12/11
 * Version: 1.0
 */

package arch.timerec.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import arch.timerec.model.Timesheet;
import arch.timerec.model.TimesheetUser;

public interface TimesheetRepository extends CrudRepository<Timesheet, Integer>{
    Timesheet findByTimesheetUser (TimesheetUser timesheetuser);
    @Query(value="select * from timesheet as tsu where tsu.TIMESHEET_USER_ID=?1 AND tsu.DATE=?2 AND tsu.TIME_OUT = ?3" , nativeQuery = true)
    Timesheet findAllTimesheet(int timesheet_user_id, String date, String time_out);

    @Query(value="select * from timesheet as tsu where tsu.TIMESHEET_USER_ID=?1 AND tsu.DATE=?2" , nativeQuery = true)
    Timesheet findAllTimesheetIns(int timesheet_user_id, String date);

    @Query(value="select * from timesheet as tsu where tsu.TIMESHEET_USER_ID=?1 AND tsu.DATE=?2 AND tsu.TIME_OUT = ''" , nativeQuery = true)
    Timesheet findByTimesheetUserDate(int timesheet_user_id, String date);

    Timesheet findByTimesheetId(String id);
    
    @Query(value = "select * from timesheet as ts where ts.TIMESHEET_USER_ID = ?1", nativeQuery = true)
	List<Timesheet> findByListTimesheetId(int timeSheetUserId);
    
    @Query(value = "select * from timesheet as ts"
    			 + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID"
    			 + " inner join user as u on u.USER_ID = tsu.USER_ID"
    			 + " where u.USER_ID =?1 and ts.DATE = ?2 and tsu.MONTH = ?3 and tsu.Year = ?4",nativeQuery = true)
    Timesheet findByUserIdDateMonthYear(String userid, String date,String month, String year);
    
    @Query(value = "select * from timesheet as ts"
			 + " inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID = ts.TIMESHEET_USER_ID\n"
			 + " where tsu.MONTH = ?2 and tsu.Year = ?3",nativeQuery = true)
    List<Timesheet> findByMonthYear(String month, String year);
    
    @Query(value="select * from timesheet as ts\n"
    		+ "inner join timesheet_user as tsu on tsu.TIMESHEET_USER_ID=ts.TIMESHEET_USER_ID\n"   		
    		+ "where tsu.USER_ID=?1 AND tsu.MONTH=?2 AND tsu.YEAR=?3" , nativeQuery = true)
    List<Timesheet> findAllTimesheets(String userId, String month, String year);
   
}