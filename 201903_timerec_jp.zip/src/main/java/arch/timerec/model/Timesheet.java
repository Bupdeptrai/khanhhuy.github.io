/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import arch.timerec.common.DateUtils;

/*
 * Class name: Timesheet
 * 
 * The persistent class for the user database table.
 */
@Entity
@Table(name = "timesheet")
@NamedQuery(name = "Timesheet.findAll", query = "SELECT t FROM Timesheet t")
public class Timesheet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TIMESHEET_ID")
	private String timesheetId;

	private String date;

	@Column(name = "TIME_IN")
	private String timeIn;

	@Column(name = "TIME_OUT")
	private String timeOut;

	@Column(name = "BREAK_TIME")
	private Double breakTime;

	@Column(name = "TIME_OT")
	private Double timeOt;

	@Column(name = "TIME_WE_OT")
	private Double timeWeOt;

	@Column(name = "TIME_ON")
	private Double timeOn;

	@Column(name = "TIME_WE_ON")
	private Double timeWeOn;

	@Column(name = "TIME_SUM")
	private Double timeSum;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_DATE")
	private Date updateDate;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "OFF_DAY")
	private String offDay;

	// bi-directional many-to-one association to Request
	@OneToMany(mappedBy = "timesheet")
	private List<Request> requests;

	public List<Request> getRequests() {
		return requests;
	}

	public void setRequests(List<Request> requests) {
		this.requests = requests;
	}

	// Bi-directional many-to-one association to TimesheetUser
	@ManyToOne
	@JoinColumn(name = "TIMESHEET_USER_ID")
	private TimesheetUser timesheetUser;

	public Timesheet() {
	}

	public String getOffDay() {
		return offDay;
	}

	public void setOffDay(String offDay) {
		this.offDay = offDay;
	}

	public String getTimesheetId() {
		return this.timesheetId;
	}

	public void setTimesheetId(String timesheetId) {
		this.timesheetId = timesheetId;
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTimeIn() {
		return this.timeIn;
	}

	public void setTimeIn(String timeIn) {
		this.timeIn = timeIn;
	}

	public String getTimeOut() {
		return this.timeOut;
	}

	public void setTimeOut(String timeOut) {
		this.timeOut = timeOut;
	}

	public Double getBreakTime() {
		if (breakTime == null) {
			return 0.0;
		} else {
			return this.breakTime;
		}
	}

	public Double getTimeOn() {
		if (timeOn == null) {
			return 0.0;
		} else {
			return this.timeOn;
		}
	}

	public void setTimeOn(Double timeOn) {
		this.timeOn = timeOn;
	}

	public Double getTimeOt() {
		if (timeOt == null) {
			return 0.0;
		} else {
			return this.timeOt;
		}
	}

	public Double getTimeSum() {
		if (timeSum == null) {
			return 0.0;
		} else {
			return this.timeSum;
		}
	}

	// Calculate TimeSum
	public void setTimeSum(String timeIn) {
		double hoursIn = Integer.parseInt(timeIn) / 100;
		double hoursOut = Integer.parseInt(getTimeOut()) / 100;
		int minutesOfIn = (int) Double.parseDouble(timeIn) % 100;
		int minutesOfOut = (int) Double.parseDouble(getTimeOut()) % 100;

		// Set hour worked in day-off
		if (hoursIn == 0 & hoursOut == 0) {
			timeSum = 8.0;

		} else {

			if (hoursIn < 13 && hoursIn >= 12)
				hoursIn = 13;

			if (0 <= hoursOut && hoursOut <= 6) {
				hoursOut = hoursOut + 24;
			}
			if (hoursOut < 13 || hoursIn > 12) {
				if (minutesOfOut > minutesOfIn) {
					int minutesInOut = minutesOfOut - minutesOfIn;
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn + minutesInOutDB / 100;

				} else if (minutesOfOut < minutesOfIn) {
					int minutesInOut = minutesOfOut + (60 - minutesOfIn);
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn + minutesInOutDB / 100;

				} else if (minutesOfIn == 0 && minutesOfOut == 0) {
					timeSum = hoursOut - hoursIn;
				}

				else if (minutesOfIn == minutesOfOut && minutesOfIn != 0 && minutesOfOut != 0) {
					int minutesInOut = minutesOfOut - minutesOfIn;
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn + minutesInOutDB / 100;
					;
				}

			}

			else if (hoursOut >= 13 || hoursIn <= 12) {
				if (minutesOfOut > minutesOfIn) {
					int minutesInOut = minutesOfOut - minutesOfIn;
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn - 1 + minutesInOutDB / 100;

				} else if (minutesOfOut < minutesOfIn) {
					int minutesInOut = minutesOfOut + (60 - minutesOfIn);
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn - 2 + minutesInOutDB / 100;

				} else if (minutesOfIn == 0 && minutesOfOut == 0) {
					timeSum = hoursOut - hoursIn - 1;
				} else if (minutesOfIn == minutesOfOut && minutesOfIn != 0 && minutesOfOut != 0) {
					int minutesInOut = minutesOfOut - minutesOfIn;
					String minutesInOutStr = String.valueOf(minutesInOut);
					double minutesInOutDB = Double.parseDouble(minutesInOutStr);

					timeSum = hoursOut - hoursIn - 1 + minutesInOutDB / 100;
					;
				}
			}

			// Set hour worked in case Time Out < Time In
			if (timeSum < 0) {
				timeSum = 0.0;
			}
		}
	}

	public void setTimeSum(Double timeSum) {
		this.timeSum = timeSum;
	}

	public Double getTimeWeOn() {
		if (timeWeOn == null) {
			return 0.0;
		} else {
			return this.timeWeOn;
		}
	}

	public void setTimeWeOn(Double timeWeOn) {
		this.timeWeOn = timeWeOn;
	}

	public Double getTimeWeOt() {
		if (timeWeOt == null) {
			return 0.0;
		} else {
			return this.timeWeOt;
		}
	}

	public void setTimeWeOt(Double timeWeOt) {
		this.timeWeOt = timeWeOt;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public TimesheetUser getTimesheetUser() {
		return this.timesheetUser;
	}

	public void setTimesheetUser(TimesheetUser timesheetUser) {
		this.timesheetUser = timesheetUser;
	}

	// Convert TimeIn: String to Number
	public double getTimeInFormatNumber() {
		if (this.getTimeIn() == null || this.getTimeIn().equalsIgnoreCase("")) {
			return 0.0;
		} else {
			return Double.parseDouble(this.getTimeIn());
		}
	}

	// Convert Date: String to Number
	public int getDateFormatNumber() {
		if (this.getDate() == null || this.getDate().equalsIgnoreCase("")) {
			return 0;
		} else {
			return Integer.parseInt(this.getDate());
		}
	}

	// Convert TimeOut: String to Number
	public double getTimeOutFormatNumber() {
		if (this.getTimeOut() == null || this.getTimeOut().equalsIgnoreCase("")) {
			return 0.0;
		} else {
			return Double.parseDouble(this.getTimeOut());
		}
	}

	// Calculator Day Worked
	public double getDayWorked() {
		double dayWorked = 0;
		if (getTimeSum() >= 8) {
			dayWorked = 1;
		} else {
			dayWorked = 0.5;
		}
		return dayWorked;
	}

	// Format TimeIn 00:00
	public String getTimeInFormat() {
		if (this.timeIn != null && this.timeIn.length() != 0) {
			String formatTimeIn = this.timeIn.substring(0, 2) + ":" + this.timeIn.substring(2, 4);
			return formatTimeIn;
		} else {
			return "";
		}
	}

	// Format TimeOut 00:00
	public String getTimeOutFormat() {
		if (this.timeOut != null && this.timeOut.length() != 0) {
			String formatTimeOut = this.timeOut.substring(0, 2) + ":" + this.timeOut.substring(2, 4);
			return formatTimeOut;
		} else {
			return "";
		}

	}

	// Caculator timeLate
	/*
	 * public void setTimeLate(String timeIn) { double hoursIn =
	 * Integer.parseInt(timeIn) / 100; int minutesOfIn = (int)
	 * Double.parseDouble(timeIn) % 100; if (0 < minutesOfIn && minutesOfIn <= 30)
	 * hoursIn = Integer.parseInt(timeIn) / 100 + 0.5; else if (30 < minutesOfIn &&
	 * minutesOfIn <= 59) hoursIn = Integer.parseInt(timeIn) / 100 + 1; if (hoursIn
	 * > 11 && (hoursIn - 13) > 0) { timeLate = hoursIn - 13.0; } else if (hoursIn <
	 * 12 && (hoursIn - 8.0) > 0) timeLate = hoursIn - 8.0;
	 * 
	 * else timeLate = 0.0; }
	 */

	public void setTimeOt(Double timeOt) {
		this.timeOt = timeOt;
	}

	public double setTimeWeOt(String timeCheckOut) {
		String date = this.getDate();
		String month = this.getTimesheetUser().getMonth();
		String year = this.getTimesheetUser().getYear();
		double timeWeOt = 0.0;
		int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
		if (dayOfWeek == 7 || dayOfWeek == 1) {
			if (!this.getTimeIn().equals("") && !this.getTimeOut().equals("")) {

				timeWeOt = getTimeSum() - getTimeWeOn();

			}

		}
		return timeWeOt;
	}

	public double setTimeOn(String timeCheckOut) {
		return timeOn;
	}

	public void setBreakTime(Double breakTime) {
		this.breakTime = breakTime;
	}

	// Calculate OT
	public Double calculateTimeOt(String timeCheckOut) {
		double timeOT = 0.0;
		String date = this.getDate();
		String month = this.getTimesheetUser().getMonth();
		String year = this.getTimesheetUser().getYear();
				

		int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
		if (dayOfWeek != 7 && dayOfWeek != 1) {			
			
			//get hour, minute of timeOT
			String timeOTStr = String.valueOf(timeOT);
			String hourOTStr = timeOTStr;
			String hourOT[] = hourOTStr.split("\\.");
			hourOTStr = hourOT[0];
			String minuOTStr = hourOT[1];
			double minuteOTDB = Double.parseDouble(minuOTStr);
			double hourOTDB = Double.parseDouble(hourOTStr);
			//get hour, minute of timeON
			String timeONStr = String.valueOf(getTimeOn());
			String hourONStr = timeONStr;
			String hourON[] = hourONStr.split("\\.");
			hourONStr = hourON[0];
			String minuONStr = hourON[1];
			if(minuONStr.length() == 1) {
				minuONStr = minuONStr + "0";
			}
			double minuteONDB = Double.parseDouble(minuONStr);			
			double hourONDB = Double.parseDouble(hourONStr);
			//get hour , minute of timeSum;
			String timeSumStr = String.valueOf(getTimeSum());
			String hourSumStr = timeSumStr;
			String hourSum[] = hourSumStr.split("\\.");
			hourSumStr = hourSum[0];
			String minuSumStr = hourSum[1];
			if(minuSumStr.length() == 1) {
				minuSumStr = minuSumStr + "0";
			}
			double minuteSumDB = Double.parseDouble(minuSumStr);
			double hourSumDB = Double.parseDouble(hourSumStr);
			if (getTimeSum() >= 8 && getTimeOn() == 0) {

				timeOT = getTimeSum() - 8.0;
			} else if (getTimeSum() < 8) {
				timeOT = 0.0;
			} else if( getTimeOn() != 0) {
				if(minuteSumDB < minuteONDB) {
					minuteOTDB = 60 + minuteSumDB - minuteONDB;
					hourOTDB = hourSumDB - hourONDB - 8 -1;
				} else if(minuteSumDB >= minuteONDB) {
					minuteOTDB = minuteSumDB - minuteONDB;
					hourOTDB = hourSumDB - hourONDB - 8;
				}
				timeOT = hourOTDB + minuteOTDB/100;
			}
					
			return timeOT ;
		} else if (dayOfWeek == 7 || dayOfWeek == 1) {
			
			//get hour, minute of timeOT
			String timeWEOTStr = String.valueOf(timeOT);
			String hourWEOTStr = timeWEOTStr;
			String hourWEOT[] = hourWEOTStr.split("\\.");
			hourWEOTStr = hourWEOT[0];
			String minuWEOTStr = hourWEOT[1];
			double minuteWEOTDB = Double.parseDouble(minuWEOTStr);
			double hourWEOTDB = Double.parseDouble(hourWEOTStr);
			//get hour, minute of timeON
			String timeWEONStr = String.valueOf(getTimeWeOn());
			String hourWEONStr = timeWEONStr;
			String hourWEON[] = hourWEONStr.split("\\.");
			hourWEONStr = hourWEON[0];
			String minuWEONStr = hourWEON[1];
			if(minuWEONStr.length() == 1) {
				minuWEONStr = minuWEONStr + "0";
			}
			double minuteWEONDB = Double.parseDouble(minuWEONStr);
			double hourWEONDB = Double.parseDouble(hourWEONStr);
			//get hour , minute of timeSum;
			String timeSumStr = String.valueOf(getTimeSum());
			String hourSumStr = timeSumStr;
			String hourSum[] = hourSumStr.split("\\.");
			hourSumStr = hourSum[0];
			String minuSumStr = hourSum[1];
			if(minuSumStr.length() == 1) {
				minuSumStr = minuSumStr + "0";
			}
			double minuteSumDB = Double.parseDouble(minuSumStr);
			double hourSumDB = Double.parseDouble(hourSumStr);
			
			if (!this.getTimeIn().equals("") && !this.getTimeOut().equals("")) {
				
				if(getTimeWeOn() !=0) {
					if(minuteSumDB < minuteWEONDB) {
						minuteWEOTDB = 60 + minuteSumDB - minuteWEONDB;
						hourWEOTDB = hourSumDB - hourWEONDB -1;
					} else if(minuteSumDB >= minuteWEONDB) {
						minuteWEOTDB = minuteSumDB - minuteWEONDB;
						hourWEOTDB = hourSumDB - hourWEONDB;
					}
					timeOT = hourWEOTDB + minuteWEOTDB/100;
				} else if(getTimeWeOn() == 0){
					timeOT= getTimeSum();
				}
			}						
						
			return timeOT ;
		}
		return timeOT;
	}

	// Calculate Overnight
	public Double calculateTimeOn(String timeCheckOut) {

		String timeOutStr = this.getTimeOut();
		double timeOutDB = Double.parseDouble(timeOutStr);

		double timeON = 0.0;
		if (timeIn.equals("0000")) {
			return timeON;
		} else {
			// check timeOut == 0h Or 0h - 7h
			if (timeOutDB == 0) {
				timeOutDB = 2400;
			} else if (0 < timeOutDB && timeOutDB <= 600) {
				timeOutDB += 2400;
			}
			if(timeOutDB > 2200) {
				timeON= (timeOutDB - 2200) / 100;
			}			
			
			return timeON;
		}
	}

	public String getTimeInRequestStatus() {
		Request request = new Request();
		String timeInReq = "";
		request.setTimeInRequest("");
		request.setStatus("");
		List<Request> listRequest = this.getRequests();
		if (listRequest != null && listRequest.size() != 0) {
			request = listRequest.get(0);
			for (int i = 0; i < listRequest.size(); i++) {
				// Get max Request ID Check In
				if (request.getRequestId() <= listRequest.get(i).getRequestId()
						&& !listRequest.get(i).getTimeInRequest().equalsIgnoreCase("")) {
					request = listRequest.get(i);
					timeInReq = request.getStatus();
				}
			}
		}
		if (this.getOffDay() != null) {
			if (!timeInReq.equals("") && !this.getOffDay().equals("")) {
				timeInReq = "";
			}
		}
		return timeInReq;
	}

	public String getTimeOutRequestStatus() {
		Request request = new Request();
		String timeOutReq = "";
		request.setTimeOutRequest("");
		request.setStatus("");
		List<Request> listRequest = this.getRequests();
		if (listRequest != null && listRequest.size() != 0) {
			request = listRequest.get(0);
			for (int i = 0; i < listRequest.size(); i++) {
				// Get max Request ID Check In
				if (request.getRequestId() <= listRequest.get(i).getRequestId()
						&& !listRequest.get(i).getTimeOutRequest().equalsIgnoreCase("")) {
					request = listRequest.get(i);
					timeOutReq = request.getStatus();
				}
			}
		}
		if (this.getOffDay() != null) {
			if (!timeOutReq.equals("") && !this.getOffDay().equals("")) {
				timeOutReq = "";
			}
		}
		return timeOutReq;
	}

}