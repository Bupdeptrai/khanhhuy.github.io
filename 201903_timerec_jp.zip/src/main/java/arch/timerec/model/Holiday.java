package arch.timerec.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "holiday")
// @NamedQuery(name = "Holiday.findAll", query = "SELECT h FROM HOLIDAY h")
public class Holiday implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HOL_ID", columnDefinition = "serial")
	private Integer holId;

	@Column(name = "DATE")
	private String date;

	@Column(name = "DATE_OF_WEEK")
	private String dateOfWeek;

	@Column(name = "NAME")
	private String name;

	public Integer getHolId() {
		return holId;
	}

	public void setHolId(Integer holId) {
		this.holId = holId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDateOfWeek() {
		return dateOfWeek;
	}

	public void setDateOfWeek(String dateOfWeek) {
		this.dateOfWeek = dateOfWeek;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
