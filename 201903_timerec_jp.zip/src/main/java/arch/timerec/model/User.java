package arch.timerec.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="USER_ID")
    private String userId;
    
    @Column(name="STAFF_ID")
    private String staffId;
    
    
    
    @Temporal(TemporalType.DATE)
    @Column(name="CREATE_DATE")
    private Date createDate;

    @Column(name="CREATE_ID")
    private String createId;

    @Column(name="DEL_FLG")
    private String delFlg;

    private String email;

    private String name;

    private String password;

    private String phone;

    @Column(name="PWD_FLG")
    private String pwdFlg;

    @Temporal(TemporalType.DATE)
    @Column(name="UPDATE_DATE")
    private Date updateDate;

    @Column(name="UPDATE_ID")
    private String updateId;

	//bi-directional many-to-one association to TimesheetUser
    @OneToMany(mappedBy="user")
    private List<TimesheetUser> timesheetUsers;

    //bi-directional many-to-one association to Role
    
    @ManyToOne
    @JoinColumn(name="ROLE_ID")
    private Role role;
    
    @ManyToOne
    @JoinColumn(name="GROUP_ID")
    private Groups group;
       

	public User() {
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateId() {
        return this.createId;
    }

    public void setCreateId(String createId) {
        this.createId = createId;
    }

    public String getDelFlg() {
        return this.delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPwdFlg() {
        return this.pwdFlg;
    }

    public void setPwdFlg(String pwdFlg) {
        this.pwdFlg = pwdFlg;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateId() {
        return this.updateId;
    }

    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    

    public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public List<TimesheetUser> getTimesheetUsers() {
        return this.timesheetUsers;
    }

    public void setTimesheetUsers(List<TimesheetUser> timesheetUsers) {
        this.timesheetUsers = timesheetUsers;
    }

    public TimesheetUser addTimesheetUser(TimesheetUser timesheetUser) {
        getTimesheetUsers().add(timesheetUser);
        timesheetUser.setUser(this);

        return timesheetUser;
    }

    public TimesheetUser removeTimesheetUser(TimesheetUser timesheetUser) {
        getTimesheetUsers().remove(timesheetUser);
        timesheetUser.setUser(null);

        return timesheetUser;
    }

    public Role getRole() {
        return this.role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

	public Groups getGroup() {
		return group;
	}

	public void setGroup(Groups group) {
		this.group = group;
	}

	

	

	
    
   

}