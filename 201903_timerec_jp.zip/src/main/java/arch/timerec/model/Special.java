package arch.timerec.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "special_day")
public class Special implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID",columnDefinition = "serial")
	private Integer id;

	@Column(name = "DATE")
	private String date;

	@Column(name = "BASIC_WORKING_TIME")
	private Double working_Time;

	@Column(name = "CONTENT")
	private String conTent;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	

	public Double getWorking_Time() {
		return working_Time;
	}

	public void setWorking_Time(Double working_Time) {
		this.working_Time = working_Time;
	}

	public String getConTent() {
		return conTent;
	}

	public void setConTent(String conTent) {
		this.conTent = conTent;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
