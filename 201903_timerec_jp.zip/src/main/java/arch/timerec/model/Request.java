/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/*
 * Class name: Request
 * 
 * The persistent class for the user database table.
 */
@Entity
@Table(name = "request")
@NamedQuery(name = "Request.findAll", query = "SELECT r FROM Request r")
public class Request implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "REQUEST_ID")
    private int requestId;

    @Temporal(TemporalType.DATE)
    @Column(name = "APPROVAL_DATE")
    private Date approvalDate;

    @Column(name = "APPROVER_ID")
    private String approverId;

    @Temporal(TemporalType.DATE)
    @Column(name = "CREATE_DATE")
    private Date createDate;
	
	@Column(name = "DATE_FROM")
    private String dateFrom;
	
	@Column(name = "DATE_TO")
    private String dateTo;	
	
	@Column(name = "STYLE_OFF")
    private String styleOff;

    @Column(name = "CREATOR_ID")
    private String creatorId;
    
    private String reason;
    
    private String note;

    private String status;

    @Column(name = "TIME_IN_REQUEST")
    private String timeInRequest;

    @Column(name = "TIME_OUT_REQUEST")
    private String timeOutRequest;
    
    @Column(name = "TIME_IN")
    private String timeIn;

    @Column(name = "TIME_OUT")
    private String timeOut;

 // Bi-directional many-to-one association to Timesheet
    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "TIMESHEET_ID")
    private Timesheet timesheet;
    
    
    
    public String getStyleOff() {
		return styleOff;
	}

	public void setStyleOff(String styleOff) {
		this.styleOff = styleOff;
	}


	public Timesheet getTimesheet() {
		return timesheet;
	}

	public void setTimesheet(Timesheet timesheet) {
		this.timesheet = timesheet;
	}

	public Request() {
    }
		

    public String getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}

	public String getDateTo() {
		return dateTo;
	}

	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}

	public int getRequestId() {
        return this.requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public Date getApprovalDate() {
        return this.approvalDate;
    }

    public void setApprovalDate(Date approvalDate) {
        this.approvalDate = approvalDate;
    }

    public String getApproverId() {
        return this.approverId;
    }

    public void setApproverId(String approverId) {
        this.approverId = approverId;
    }

    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreatorId() {
        return this.creatorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }
    
    public String getNote() {
        return this.note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getReason() {
        return this.reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTimeInRequest() {
        return this.timeInRequest;
    }

    public void setTimeInRequest(String timeInrequest) {
        this.timeInRequest = timeInrequest;
    }

    public String getTimeOutRequest() {
        return this.timeOutRequest;
    }

    public void setTimeOutRequest(String timeOutrequest) {
        this.timeOutRequest = timeOutrequest;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

   

    // Format TimeIn 00:00
    public String formatTimeIn() {
        if (this.timeIn != null && this.timeIn.length() != 0) {
            String formatTimeIn = this.timeIn.substring(0, 2) + ":" + this.timeIn.substring(2, 4);
            return formatTimeIn;
        } else {
            return "";
        }
    }

    // Format TimeOut 00:00
    public String formatTimeOut() {
        if (this.timeOut != null && this.timeOut.length() != 0) {
        String formatTimeOut = this.timeOut.substring(0, 2) + ":" + this.timeOut.substring(2, 4);
        return formatTimeOut;
        } else {
            return "";
        }
        
    }
    // Format TimeInRequest 00:00
    public String formatTimeInRequest() {
        if (this.timeInRequest != null && this.timeInRequest.length() != 0) {
            String formatTimeInRequest = this.timeInRequest.substring(0, 2) + ":" + this.timeInRequest.substring(2, 4);
            return formatTimeInRequest;
        } else {
            return "";
        }
    }

    // Format TimeOutRequest 00:00
    public String formatTimeOutRequest() {
        if (this.timeOutRequest != null && this.timeOutRequest.length() != 0) {
            String formatTimeOutRequest = this.timeOutRequest.substring(0, 2) + ":" + this.timeOutRequest.substring(2, 4);
            return formatTimeOutRequest;
        } else {
            return "";
        }
    }
    
 // Format date yyyy/mm/dd
    public String getDateFromFormat() {
        if (this.dateFrom != null && this.dateFrom.length() != 0) {
            String formatDate = this.dateFrom.substring(0, 4) 
            		+ "/" + this.dateFrom.substring(4, 6) 
            		+ "/" + this.dateFrom.substring(6, 8);
            return formatDate;
        } else {
            return "";
        }
    }
    
    public String getDateToFormat() {
        if (this.dateTo != null && this.dateTo.length() != 0) {
            String formatDate = this.dateTo.substring(0, 4) 
            		+ "/" + this.dateTo.substring(4, 6) 
            		+ "/" + this.dateTo.substring(6, 8);
            return formatDate;
        } else {
            return "";
        }
    }
}
