/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import arch.timerec.common.DateUtils;

/*
 * Class name: TimesheetUser
 * 
 * The persistent class for the user database table.
 */
@Entity
@Table(name = "timesheet_user")
@NamedQuery(name = "TimesheetUser.findAll", query = "SELECT t FROM TimesheetUser t")
public class TimesheetUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TIMESHEET_USER_ID")
	private int timesheetUserId;

	private String month;

	private String year;

	// Bi-directional many-to-one association to Timesheet
	@OneToMany(mappedBy = "timesheetUser")
	private List<Timesheet> timesheets;

	// Bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private User user;

	public TimesheetUser() {
	}

	public int getTimesheetUserId() {
		return this.timesheetUserId;
	}

	public void setTimesheetUserId(int timesheetUserId) {
		this.timesheetUserId = timesheetUserId;
	}

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return this.year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public List<Timesheet> getTimesheets() {
		return this.timesheets;
	}

	public void setTimesheets(List<Timesheet> timesheets) {
		this.timesheets = timesheets;
	}

	public Timesheet addTimesheet(Timesheet timesheet) {
		getTimesheets().add(timesheet);
		timesheet.setTimesheetUser(this);
		return timesheet;
	}

	public Timesheet removeTimesheet(Timesheet timesheet) {
		getTimesheets().remove(timesheet);
		timesheet.setTimesheetUser(null);
		return timesheet;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// Sum day worked except off day
	public double getSumDayWorkExOffday() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double countSumDayWorkExOffday = 0.0;
		for (Timesheet timesheet : listTimesheet) {
			if (!timesheet.getTimeIn().equals("") && !timesheet.getTimeOut().equals("")
					&& timesheet.getOffDay() == null) {
				countSumDayWorkExOffday += 1;
			}
		}
		return countSumDayWorkExOffday;
	}

	// Sum off day
	public double getSumOffday() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double countOffDay = 0.0;
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getOffDay() != null) {
				if (timesheet.getOffDay().equals("1") || timesheet.getOffDay().equals("5")) {
					countOffDay += 1;
				} else if (timesheet.getOffDay().equals("2") || timesheet.getOffDay().equals("3")) {
					countOffDay += 0.5;
				}
			}
		}
		return countOffDay;
	}

	// Sum day worked of weekend
	public double getSumDayWorkedWE() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double countDayWorkedWE = 0.0;
		for (Timesheet timesheet : listTimesheet) {
			String date = timesheet.getDate();
			int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
			if (dayOfWeek == 7 || dayOfWeek == 1) {
				if (!timesheet.getTimeIn().equals("") && !timesheet.getTimeOut().equals("")) {
					countDayWorkedWE += 1;
				}
			}
		}
		return countDayWorkedWE;
	}

	// Sum Day Worked
	public double getSumDayWorked() {

		double countDayWorked = 0.0;
		double sumDayWorkExOffday = getSumDayWorkExOffday();
		double sumOffday = getSumOffday();
		double sumDayWorkendWE = getSumDayWorkedWE();

		countDayWorked = sumDayWorkExOffday + sumOffday - sumDayWorkendWE;

		return countDayWorked;
	}

	// Sum Paid leave days
	public double getSumPaidLeaveDays() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double count = 0;
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeSum() >= 8.0 && timesheet.getTimeInFormatNumber() == 0.0
					&& timesheet.getTimeOutFormatNumber() == 0.0) {
				count += 1;
			}
		}
		return count;
	}

	// Sum Unpaid leave days
	public double getSumUnpaidLeaveDays() {
		double countPaidLeaveDays = getSumPaidLeaveDays();
		double countUnPaidLeaveDays = 0.0;
		if (countPaidLeaveDays > 12) {
			countUnPaidLeaveDays += 1;
		}
		return countUnPaidLeaveDays;
	}

	// Sum Time Worked into sat, sun
	public double getSumTimeWorkedWE() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumTimeWE = 0.0;

		for (Timesheet timesheet : listTimesheet) {
			String date = timesheet.getDate();
			int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);

			if (dayOfWeek == 7 || dayOfWeek == 1) {
				sumTimeWE += timesheet.getTimeSum();
				if (sumTimeWE != 0) {
					String countStr = String.valueOf(sumTimeWE);
					String hourSumStr = countStr;
					String Sumhour[] = hourSumStr.split("\\.");
					hourSumStr = Sumhour[0];
					String minuSumStr = Sumhour[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";
					} else {
						minuSumStr = minuSumStr.substring(0, 2);
						countStr = hourSumStr + "." + minuSumStr;
						sumTimeWE = Double.parseDouble(countStr);
					}

					double minuteSum = Double.parseDouble(minuSumStr);

					if (minuteSum >= 60) {

						sumTimeWE = sumTimeWE + 0.4;
					}
				}
			}
		}

		return sumTimeWE;
	}

	// Sum Time Worked
	public double getSumTimeWorked() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumTime = 0.0;
		String countStr = String.valueOf(sumTime);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		double minuteSumDB = Double.parseDouble(minuSumStr);
		double hourSumDB = Double.parseDouble(hourSumStr);

		for (Timesheet timesheet : listTimesheet) {
			String date = timesheet.getDate();
			int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
			if (dayOfWeek != 7 && dayOfWeek != 1) {
				sumTime += timesheet.getTimeSum();
				double sumTimeOfDate = timesheet.getTimeSum();
				if (sumTimeOfDate != 0) {

					String countStrOfDate = String.valueOf(sumTimeOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {

						minuSumStr = minuSumStr + "0";
					} else if (minuSumStr.length() > 1) {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";
					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumTime = Double.parseDouble(countStr);

					double minuSumStrOfDateDB = Double.parseDouble(minuSumStrOfDate);
					double hourSumStrOfDateDB = Double.parseDouble(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					hourSumDB = hourSumDB + hourSumStrOfDateDB;

					double minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					double hourSumDBM = hourSumDB + hourEntire;

					sumTime = hourSumDBM + minuteSumDBM / 100;
				}
			}
		}

		return sumTime;
	}

	// Sum Over Time
	public double getSumOverTime() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumOvertime = 0.0;
		String countStr = String.valueOf(sumOvertime);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeOt() > 0.0) {
				sumOvertime += timesheet.getTimeOt();

				double sumOverTimeOfDate = timesheet.getTimeOt();
				if (sumOverTimeOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOverTimeOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";
					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvertime = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					hourSumDB = hourSumDB + hourSumStrOfDateDB;

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvertimeStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvertime = Double.parseDouble(sumOvertimeStr);
					
				}
			}
		}
		return sumOvertime;
	}

	// Sum Time Late
	public double getSumBreakTime() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double count = 0.0;
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getBreakTime() > 0.0) {
				count += timesheet.getBreakTime();
			}
		}
		return count;
	}

	// Sum Weekend Over Time
	public double getSumWeekendOverTime() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumOvertimeWE = 0.0;
		String countStr = String.valueOf(sumOvertimeWE);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeWeOt() > 0.0) {
				sumOvertimeWE += timesheet.getTimeWeOt();
				double sumOverTimeWEOfDate = timesheet.getTimeWeOt();
				if (sumOverTimeWEOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOverTimeWEOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";

					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvertimeWE = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					hourSumDB = hourSumDB + hourSumStrOfDateDB;

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvertimeWEStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvertimeWE = Double.parseDouble(sumOvertimeWEStr);

				}
			}
		}
		return sumOvertimeWE;
	}

	// Sum Over Night
	public double getSumOverNight() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumOvernight = 0.0;
		String countStr = String.valueOf(sumOvernight);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeOn() > 0.0) {
				sumOvernight += timesheet.getTimeOn();
				double sumOvernightOfDate = timesheet.getTimeOn();
				if (sumOvernightOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOvernightOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";

					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvernight = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);
					
					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					minuSumStr = String.valueOf(minuteSumDB);
					hourSumDB = hourSumDB + hourSumStrOfDateDB;
					hourSumStr = String.valueOf(hourSumDB);

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvernightStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvernight = Double.parseDouble(sumOvernightStr);
					
				}
			}
		}
		return sumOvernight;
	}

	// Sum Weekend Over Night
	public double getSumWeekendOverNight() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		double sumOvernightWE = 0.0;
		String countStr = String.valueOf(sumOvernightWE);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeWeOn() > 0.0) {
				sumOvernightWE += timesheet.getTimeWeOn();
				double sumOvernightWEOfDate = timesheet.getTimeWeOn();
				if (sumOvernightWEOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOvernightWEOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";
					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}					

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					minuSumStr = String.valueOf(minuteSumDB);
					hourSumDB = hourSumDB + hourSumStrOfDateDB;
					hourSumStr = String.valueOf(hourSumDB);

					int minuteSumDBM = minuteSumDB % 60;
					

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvernightWEString = hourSumStrM + "." + minuteSumDBMStr;
					sumOvernightWE = Double.parseDouble(sumOvernightWEString);

				}
			}
		}
		return sumOvernightWE;
	}

	// Count Day In Month
	public int getCountDayInMonth() {
		int year = Integer.parseInt(this.getYear());
		int month = Integer.parseInt(this.getMonth()) - 1;
		Calendar monthStart = new GregorianCalendar(year, month, 1);
		return monthStart.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	public int getDateSpecifilyWorkedays() {
		// Count Saturday, Sunday
		int countDay = 0;
		int count = 0;
		for (int i = 1; i <= getCountDayInMonth(); i++) {
			String date = String.valueOf(i);
			int dayOfWeek = DateUtils.initDate(this.getYear(), this.getMonth(), date).get(Calendar.DAY_OF_WEEK);

			// Check Date Name == Saturday or Sunday
			if (dayOfWeek == 7 || dayOfWeek == 1) {
				countDay += 1;
			}
		}
		count = getCountDayInMonth() - countDay;
		return count;
	}

	// Add Timesheet
	public List<Timesheet> addTimeSheet(List<Timesheet> listTimesheet, int dateInMonth) {
		List<Timesheet> listTimesheetNew = new ArrayList<Timesheet>();
		listTimesheet = this.sortListTimesheet();

		int index = 0;
		int date = 1;
		for (int i = 1; i <= dateInMonth; i++) {
			if (index < listTimesheet.size() && listTimesheet != null) {
				date = listTimesheet.get(index).getDateFormatNumber();
			}
			if (i < date || i > date) {
				Timesheet timesheet = new Timesheet();
				timesheet.setDate(String.valueOf(i));
				timesheet.setTimeIn("");
				timesheet.setTimeOut("");
				listTimesheetNew.add(timesheet);
			} else if (i == date) {
				if (listTimesheet.size() != 0) {
					listTimesheetNew.add(listTimesheet.get(index));
				} else {
					Timesheet timesheet = new Timesheet();
					timesheet.setDate(String.valueOf(i));
					timesheet.setTimeIn("");
					timesheet.setTimeOut("");
					listTimesheetNew.add(timesheet);
				}
				index += 1;
			}
		}
		return listTimesheetNew;
	}

	// Sort List<TimeSheet>
	public List<Timesheet> sortListTimesheet() {
		List<Timesheet> listTimesheet = this.getTimesheets();
		// Loop from i to ListTimesheet - 1
		for (int i = 0; i < listTimesheet.size() - 1; i++) {
			// Loop from j to ListTimesheet
			for (int j = i; j < listTimesheet.size(); j++) {
				// Get date of Timesheet I
				Timesheet timesheetIntI = new Timesheet();
				timesheetIntI = listTimesheet.get(i);
				// Get date of Timesheet J
				Timesheet timesheetIntJ = new Timesheet();
				timesheetIntJ = listTimesheet.get(j);

				if (timesheetIntI.getDateFormatNumber() > timesheetIntJ.getDateFormatNumber()) {
					// Remove index i
					listTimesheet.remove(i);
					listTimesheet.add(i, timesheetIntJ);
					// Remove index j
					listTimesheet.remove(j);
					listTimesheet.add(j, timesheetIntI);
				}
			}
		}
		return listTimesheet;
	}

}
