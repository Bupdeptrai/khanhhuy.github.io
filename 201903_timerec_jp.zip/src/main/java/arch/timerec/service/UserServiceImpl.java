/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: nguyen-dinhtoan
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import arch.timerec.model.Groups;
import arch.timerec.model.User;
import arch.timerec.repository.UserRepository;
import arch.timerec.repository.GroupRepository;

@Service
public class UserServiceImpl {
    @Autowired
	@Qualifier("javasampleapproachMailSender")
	public EmailService EmailService;
	
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private GroupRepository groupRepository;

    private BCryptPasswordEncoder bcrypass = new BCryptPasswordEncoder();

    @Value("${value.string.pwd}")
    private String strPass;

    @Value("${value.string.FlgDel}")
    private String strFlgDel;

    @Value("${value.string.FlgPwd}")
    private String strFlgPwd;
    
    @Value("${spring.mail.username}")
    private String mailFrom;
    CommonService commom = new CommonService();

    // method Insert and Update employee
    public void insertOrupdate(User user) throws ParseException {

        User findUserId = searchUserId(user.getUserId());
		Map<String, String> getSendMail= new HashMap<String, String>();
        if (findUserId == null) {
            // create new employee
        	
            user.setPassword(GeneratePassword.gen(8));
            getSendMail = commom .SendMail(user);
        	user.setPassword(bcrypass.encode(user.getPassword()));
            user.setCreateDate(commom.currentDate());
            user.setDelFlg(strFlgDel);
            user.setPwdFlg(strFlgPwd);
            userRepository.save(user);
            EmailService.sendMail(getSendMail.get("mailform"), getSendMail.get("toMail"), getSendMail.get("subject"), getSendMail.get("body"));
        } else {
            if (user.getPassword() == null || user.getPassword().equals("")) {
                // change information employee
                user.setUpdateDate(commom.currentDate());
                user.setCreateDate(findUserId.getCreateDate());
                user.setPassword(findUserId.getPassword());
                user.setPwdFlg(findUserId.getPwdFlg());
                userRepository.save(user);
            }
        }
    }

    // change password
    public void updatePassword(User user, String password) {

        user.setPassword(bcrypass.encode(password));
        user.setPwdFlg("1");
        userRepository.save(user);
    }

    // reset password
    public void resetPassword(User user) {
    	Map<String, String> getSendMail= new HashMap<String, String>();
    	
        try {
            user.setUpdateDate(commom.currentDate());
            user.setPassword(GeneratePassword.gen(8));
            getSendMail = commom .SendMail(user);
        	user.setPassword(bcrypass.encode(user.getPassword()));
            userRepository.save(user);
        	EmailService.sendMail(getSendMail.get("mailform"), getSendMail.get("toMail"), getSendMail.get("subject"), getSendMail.get("body"));

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    // get value User
    public User searchUserId(String userId) {
        User user = userRepository.findByUserId(userId);
        return user;
    }

    // autoCode UserId
    public String autoCodeUserId() {
        List<User> lstUser = (List<User>) userRepository.findAll();
        String userId = lstUser.get(lstUser.size() - 1).getUserId();
        CommonService autoCode = new CommonService();
        String uId = autoCode.autoUserId(userId);
        return uId;
    }
    
 // autoCode staffId
    public String autoCodeStaffId() {
        List<User> lstUser = (List<User>) userRepository.findAll();
        String staffId = lstUser.get(lstUser.size() - 1).getStaffId();
        CommonService autoCode = new CommonService();
        String sId = autoCode.autoStaffId(staffId);
        return sId;
    }
    
    
    public void updateGroupId(String adduserId,String deluserid, String groupId) {
    		    	   	    	
    	    	String [] add = adduserId.split("/");
    	    	
    	    	for(String item : add) {
    	    		if(!item.equals("")) {
    	    			User userUpdate = userRepository.findByUserId(item);
    	            	Groups groupUpdate = groupRepository.findByGroupId(groupId);
    	            	userUpdate.setGroup(groupUpdate);
    	            	userRepository.save(userUpdate);
    	    		}    		
    	    	}
    	    	   	    	
    	    	String [] del = deluserid.split("/");
    	    	
    	    	String groupfree = "GR0001";
    	    	
    	    	for(String item : del) {
    	    		if(!item.equals("")) {
    	    			User userUpdate = userRepository.findByUserId(item);
    	            	Groups groupUpdate = groupRepository.findByGroupId(groupfree);
    	            	userUpdate.setGroup(groupUpdate);
    	            	userRepository.save(userUpdate);
    	    		}    		
    	    	}
    	    	
    	    }
    
    
    
    
}
