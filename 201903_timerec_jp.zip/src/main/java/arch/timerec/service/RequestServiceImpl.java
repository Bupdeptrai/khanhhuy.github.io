/*
 Author : Ton That Cu ly.
 Creat Date : 15-06-2018.
 Version : 1.0.1
*/
package arch.timerec.service;

import java.text.ParseException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import arch.timerec.common.DateUtils;
import arch.timerec.model.Holiday;
import arch.timerec.model.Request;
import arch.timerec.model.Timesheet;
import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;
import arch.timerec.repository.HolidayRepository;
import arch.timerec.repository.RequestRepository;
import arch.timerec.repository.TimesheetRepository;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;

@Service
public class RequestServiceImpl {
	@Autowired
	private RequestRepository requestRepository;

	@Autowired
	private TimesheetUserRepository timesheetUserRepository;

	@Autowired
	private TimesheetUserServiceImpl timesheetuserserviceimpl;

	@Autowired
	private TimesheetRepository timesheetRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private HolidayRepository holidayRepository;

	CommonService common = new CommonService();

	public void acceptRequest(int reqId, String userId) throws ParseException {
		try {

			// get Request
			Request selectedReq = requestRepository.findByRequestId(reqId);
			selectedReq.setStatus("accepted");
			selectedReq.setApproverId(userId);
			selectedReq.setApprovalDate(common.currentDate());
			requestRepository.save(selectedReq);

			// get date/month From
			String dayFrom = selectedReq.getDateFrom();
			String yearFrom = dayFrom.substring(0, 4);
			int yearFromInt = Integer.parseInt(yearFrom);
			String monthFrom = dayFrom.substring(4, 6);
			int monthFromInt = Integer.parseInt(monthFrom);
			String dateFrom = dayFrom.substring(6, 8);
			int dayFromInt = Integer.parseInt(dateFrom);

			// get date/month To
			String dayTo = selectedReq.getDateTo();
			String yearTo = dayTo.substring(0, 4);
			int yearToInt = Integer.parseInt(yearTo);
			String monthTo = dayTo.substring(4, 6);
			int monthToInt = Integer.parseInt(monthTo);
			String dateTo = dayTo.substring(6, 8);
			int dayToInt = Integer.parseInt(dateTo);

			String useridRequest = selectedReq.getTimesheet().getTimesheetUser().getUser().getUserId();
			// find and Update timesheet of the same Month
			for (int yearOff = yearFromInt; yearOff <= yearToInt; yearOff++) {
				String yearOffStr = String.valueOf(yearOff);
				// Update one or many Timesheet of the same Month
				if (yearFrom.equals(yearTo)) {
					if (monthFrom.equals(monthTo)) {
						for (int dayOff = dayFromInt; dayOff <= dayToInt; dayOff++) {
							String dayOffString = String.valueOf(dayOff);
							if (dayOffString.length() == 1) {
								dayOffString = "0" + dayOffString;
							}

							Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(useridRequest,
									dayOffString, monthFrom, yearFrom);
							if (selectedTimesheet != null) {

								updateTimesheet(selectedTimesheet, userId, selectedReq, yearFrom, monthFrom,
										dayOffString);
							}
						}
					}
					// Update one or many Timesheet of different Month
					else {
						for (int monthOff = monthFromInt; monthOff <= monthToInt; monthOff++) {
							// get last date in month From
							int lastDayOfMonth = lastDayOfMonth(yearFromInt, monthOff);
							String monthString = String.valueOf(monthOff);
							if (monthString.length() == 1) {
								monthString = "0" + monthString;
							}
							// monthOff = monthFrom
							if (monthString.equals(monthFrom)) {

								for (int dayOff = dayFromInt; dayOff <= lastDayOfMonth; dayOff++) {
									String dayOffString = String.valueOf(dayOff);
									if (dayOffString.length() == 1) {
										dayOffString = "0" + dayOffString;
									}

									Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
											useridRequest, dayOffString, monthString, yearFrom);
									if (selectedTimesheet != null) {

										updateTimesheet(selectedTimesheet, userId, selectedReq, yearFrom, monthString,
												dayOffString);
									}

								}
							}
							// monthOff = monthTo
							else if (monthString.equals(monthTo)) {
								for (int dayOff = 1; dayOff <= dayToInt; dayOff++) {
									String dayOffString = String.valueOf(dayOff);
									if (dayOffString.length() == 1) {
										dayOffString = "0" + dayOffString;
									}

									Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
											useridRequest, dayOffString, monthString, yearFrom);
									if (selectedTimesheet != null) {

										updateTimesheet(selectedTimesheet, userId, selectedReq, yearFrom, monthString,
												dayOffString);
									}
								}
							}
							// monthOff is between month from and month To
							else if (monthString != monthFrom && monthString != monthTo) {

								for (int dayOff = 1; dayOff <= lastDayOfMonth; dayOff++) {
									String dayOffString = String.valueOf(dayOff);
									if (dayOffString.length() == 1) {
										dayOffString = "0" + dayOffString;
									}

									Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
											useridRequest, dayOffString, monthString, yearFrom);
									if (selectedTimesheet != null) {

										updateTimesheet(selectedTimesheet, userId, selectedReq, yearFrom, monthString,
												dayOffString);
									}
								}
							}
						}
					}
				}
				// year From # year To
				else if (yearOffStr.equals(yearFrom) && !yearFrom.equals(yearTo)) {
					for (int monthOff = monthFromInt; monthOff <= 12; monthOff++) {
						// get the last day Of month
						int lastDayOfMonth = lastDayOfMonth(yearFromInt, monthOff);
						String monthString = String.valueOf(monthOff);

						if (monthString.length() == 1) {
							monthString = "0" + monthString;
						}

						// find Timesheet in month From
						if (monthString.equals(monthFrom)) {
							for (int dayOff = dayFromInt; dayOff <= lastDayOfMonth; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}

								Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
										useridRequest, dayOffString, monthString, yearOffStr);
								if (selectedTimesheet != null) {

									updateTimesheet(selectedTimesheet, userId, selectedReq, yearOffStr, monthString,
											dayOffString);
								}
							}
						}
						// find Timesheet Of months greater than monthFrom
						if (monthOff > monthFromInt) {
							for (int dayOff = 1; dayOff <= lastDayOfMonth; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}

								Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
										useridRequest, dayOffString, monthString, yearOffStr);
								if (selectedTimesheet != null) {

									updateTimesheet(selectedTimesheet, userId, selectedReq, yearOffStr, monthString,
											dayOffString);
								}
							}
						}
					}
				} else if (yearOffStr.equals(yearTo) && !yearFrom.equals(yearTo)) {
					for (int monthOff = 1; monthOff <= monthToInt; monthOff++) {
						// get last date in month before month To
						int lastDateOfMonth = lastDayOfMonth(yearToInt, monthOff);

						String monthString = String.valueOf(monthOff);
						if (monthString.length() == 1) {
							monthString = "0" + monthString;
						}
						// find Timesheet of month before month TO
						if (monthOff < monthToInt) {
							for (int dayOff = 1; dayOff <= lastDateOfMonth; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}

								Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
										useridRequest, dayOffString, monthString, yearOffStr);
								if (selectedTimesheet != null) {

									updateTimesheet(selectedTimesheet, userId, selectedReq, yearOffStr, monthString,
											dayOffString);
								}
							}
						}
						// find and Update Timesheets of month To
						else if (monthString.equals(monthTo)) {
							for (int dayOff = 1; dayOff <= dayToInt; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}

								Timesheet selectedTimesheet = timesheetRepository.findByUserIdDateMonthYear(
										useridRequest, dayOffString, monthString, yearOffStr);
								if (selectedTimesheet != null) {

									updateTimesheet(selectedTimesheet, userId, selectedReq, yearOffStr, monthString,
											dayOffString);
								}
							}
						}
					}
				}

			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public void denyRequest(int reqId, String userId) throws ParseException {
		try {
			Request selectedReq = requestRepository.findByRequestId(reqId);
			selectedReq.setStatus("denied");
			selectedReq.setApproverId(userId);
			selectedReq.setApprovalDate(common.currentDate());
			requestRepository.save(selectedReq);

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public void insertRequest(String date, String month, String year, String userid, Request formrequest)
			throws ParseException {

		User u = userRepository.findByUserId(userid);
		String dateFrom = formrequest.getDateFromFormat();
		String dateTo = formrequest.getDateToFormat();

		// get year/month/date start Off
		String yearFrom = dateFrom.substring(0, 4);
		String monthFrom = dateFrom.substring(5, 7);
		String dayFrom = dateFrom.substring(8, 10);

		// get year/month/date end Off
		String yearTo = dateTo.substring(0, 4);
		String monthTo = dateTo.substring(5, 7);
		String dayTo = dateTo.substring(8, 10);

		insertDay(u, yearFrom, yearTo, monthFrom, monthTo, dayFrom, dayTo, formrequest);
		insertRequests(date, month, year, userid, formrequest);

	}

	public void insertDay(User u, String yearFrom, String yearTo, String monthFrom, String monthTo, String dayFrom,
			String dayTo, Request selectedReq) {

		Timesheet tss = new Timesheet();
		int monthFromInt = Integer.parseInt(monthFrom);
		int monthToInt = Integer.parseInt(monthTo);
		int yearFromInt = Integer.parseInt(yearFrom);
		int yearToInt = Integer.parseInt(yearTo);
		int dayFromInt = Integer.parseInt(dayFrom);
		int dayToInt = Integer.parseInt(dayTo);
		String styleOff = selectedReq.getStyleOff();

		// insert TimesheetUser
		for (int yearOff = yearFromInt; yearOff <= yearToInt; yearOff++) {
			String yearOffStr = String.valueOf(yearOff);
			for (int monthOff = 1; monthOff <= 12; monthOff++) {
				String monthOffString = String.valueOf(monthOff);

				if (monthOffString.length() == 1) {
					monthOffString = "0" + monthOffString;
				}
				TimesheetUser findTsuByMonth = timesheetUserRepository.findByTimesheetUserUsId(u.getUserId(),
						monthOffString, yearOffStr);
				if (findTsuByMonth == null) {
					TimesheetUser tsuInsert = new TimesheetUser();
					tsuInsert.setMonth(monthOffString);
					tsuInsert.setYear(yearOffStr);
					tsuInsert.setUser(u);
					timesheetUserRepository.save(tsuInsert);
				}
			}
			// year From = Year To
			if (yearFrom.equals(yearTo)) {
				// Insert one or many Timesheet of the same Month
				if (monthFrom.equals(monthTo)) {
					TimesheetUser findTsuByMonth = timesheetUserRepository.findByTimesheetUserUsId(u.getUserId(),
							monthFrom, yearOffStr);
					for (int dayOff = dayFromInt; dayOff <= dayToInt; dayOff++) {
						String dayOffString = String.valueOf(dayOff);
						if (dayOffString.length() == 1) {
							dayOffString = "0" + dayOffString;
						}

						// get Day Of week
						int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthFrom, dayOffString)
								.get(Calendar.DAY_OF_WEEK);
						String yearMonthDate = yearOffStr + monthFrom + dayOffString;

						// insert Timesheet for Request Change The Time
						if (styleOff == null) {
							tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
									dayOffString);
							if (tss == null) {
								tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
							}
						}
						// insert Timesheet for Request Off
						else {
							Holiday holiday = holidayRepository.findByDate(yearMonthDate);
							if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

								tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
										dayOffString);
								if (tss == null) {
									tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
								}
							}

						}

					}

				}
				// Insert one or many Timesheet of the Other Month
				else {
					for (int monthInt = monthFromInt; monthInt <= monthToInt; monthInt++) {
						// get last date in month From
						int lastDayOfMonth = lastDayOfMonth(yearFromInt, monthInt);
						String monthString = String.valueOf(monthInt);

						if (monthString.length() == 1) {
							monthString = "0" + monthString;
						}
						TimesheetUser findTsuByMonth = timesheetUserRepository.findByTimesheetUserUsId(u.getUserId(),
								monthString, yearOffStr);

						if (monthString.equals(monthFrom)) {
							// Insert one or many Timesheet of the Month From

							for (int dayOff = dayFromInt; dayOff <= lastDayOfMonth; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}
								// get Day Of week
								int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
										.get(Calendar.DAY_OF_WEEK);
								String yearMonthDate = yearOffStr + monthString + dayOffString;

								// insert Timesheet for Request Change The Time
								if (styleOff == null) {
									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}
								// insert Timesheet for Request Off
								else {
									Holiday holiday = holidayRepository.findByDate(yearMonthDate);
									if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

										tss = timesheetRepository
												.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(), dayOffString);
										if (tss == null) {
											tss = timesheetuserserviceimpl.insertTimesheet(dayOffString,
													findTsuByMonth);
										}
									}

								}

							}
						} else if (monthString.equals(monthTo)) {

							// Insert one or many Timesheet of the Month To
							for (int dayOff = 1; dayOff <= dayToInt; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}
								// get Day Of week
								int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
										.get(Calendar.DAY_OF_WEEK);
								String yearMonthDate = yearOffStr + monthString + dayOffString;

								// insert Timesheet for Request Change The Time
								if (styleOff == null) {
									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}
								// insert Timesheet for Request Off
								else {
									Holiday holiday = holidayRepository.findByDate(yearMonthDate);
									if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

										tss = timesheetRepository
												.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(), dayOffString);
										if (tss == null) {
											tss = timesheetuserserviceimpl.insertTimesheet(dayOffString,
													findTsuByMonth);
										}
									}

								}
							}
						}
						// Insert Timesheet of the Month between MonthFrom and MonthTo
						else if (monthString != monthFrom && monthString != monthTo) {
							for (int dayOff = 1; dayOff <= lastDayOfMonth; dayOff++) {
								String dayOffString = String.valueOf(dayOff);
								if (dayOffString.length() == 1) {
									dayOffString = "0" + dayOffString;
								}
								// get Day Of week
								int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
										.get(Calendar.DAY_OF_WEEK);
								String yearMonthDate = yearOffStr + monthString + dayOffString;

								// insert Timesheet for Request Change The Time
								if (styleOff == null) {
									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}
								// insert Timesheet for Request Off
								else {
									Holiday holiday = holidayRepository.findByDate(yearMonthDate);
									if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

										tss = timesheetRepository
												.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(), dayOffString);
										if (tss == null) {
											tss = timesheetuserserviceimpl.insertTimesheet(dayOffString,
													findTsuByMonth);
										}
									}

								}

							}

						}

					}
				}
			}
			// year From # year To
			if (yearOffStr.equals(yearFrom) && !yearFrom.equals(yearTo)) {
				for (int monthInt = monthFromInt; monthInt <= 12; monthInt++) {
					// get last day of month
					int lastDayOfMonth = lastDayOfMonth(yearFromInt, monthInt);

					String monthString = String.valueOf(monthInt);
					if (monthString.length() == 1) {
						monthString = "0" + monthString;
					}
					TimesheetUser findTsuByMonth = timesheetUserRepository.findByTimesheetUserUsId(u.getUserId(),
							monthString, yearOffStr);
					// Insert Timesheet of Month From
					if (monthString.equals(monthFrom)) {

						for (int dayOff = dayFromInt; dayOff <= lastDayOfMonth; dayOff++) {
							String dayOffString = String.valueOf(dayOff);
							if (dayOffString.length() == 1) {
								dayOffString = "0" + dayOffString;
							}
							// get Day Of week
							int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
									.get(Calendar.DAY_OF_WEEK);
							String yearMonthDate = yearOffStr + monthString + dayOffString;

							// insert Timesheet for Request Change The Time
							if (styleOff == null) {
								tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
										dayOffString);
								if (tss == null) {
									tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
								}
							}
							// insert Timesheet for Request Off
							else {
								Holiday holiday = holidayRepository.findByDate(yearMonthDate);
								if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}

							}

						}
					}
					// Insert Timeshet of Months greater than Month From
					else if (monthInt > monthFromInt) {
						for (int dayOff = 1; dayOff <= lastDayOfMonth; dayOff++) {
							String dayOffString = String.valueOf(dayOff);
							if (dayOffString.length() == 1) {
								dayOffString = "0" + dayOffString;
							}
							// get Day Of week
							int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
									.get(Calendar.DAY_OF_WEEK);
							String yearMonthDate = yearOffStr + monthString + dayOffString;

							// insert Timesheet for Request Change The Time
							if (styleOff == null) {
								tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
										dayOffString);
								if (tss == null) {
									tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
								}
							}
							// insert Timesheet for Request Off
							else {
								Holiday holiday = holidayRepository.findByDate(yearMonthDate);
								if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}

							}
						}

					}

				}
			}
			// Insert Time sheet Of month in year To
			else if (yearOffStr.equals(yearTo) && !yearFrom.equals(yearTo)) {
				for (int monthInt = 1; monthInt <= monthToInt; monthInt++) {
					// get last date in month before month To
					int lastDayOfMonth = lastDayOfMonth(yearToInt, monthInt);
					String monthString = String.valueOf(monthInt);
					if (monthString.length() == 1) {
						monthString = "0" + monthString;
					}
					TimesheetUser findTsuByMonth = timesheetUserRepository.findByTimesheetUserUsId(u.getUserId(),
							monthString, yearOffStr);

					// Insert Timesheet of Month To
					if (monthString.equals(monthTo)) {
						for (int dayInt = 1; dayInt <= dayToInt; dayInt++) {
							String dayOffString = String.valueOf(dayInt);
							if (dayOffString.length() == 1) {
								dayOffString = "0" + dayOffString;
							}

							// get Day Of week
							int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
									.get(Calendar.DAY_OF_WEEK);
							String yearMonthDate = yearOffStr + monthString + dayOffString;

							// insert Timesheet for Request Change The Time
							if (styleOff == null) {
								tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
										dayOffString);
								if (tss == null) {
									tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
								}
							}
							// insert Timesheet for Request Off
							else {
								Holiday holiday = holidayRepository.findByDate(yearMonthDate);
								if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}

							}
						}
					}
					// Insert Timesheet Of months smaller than month To
					else if (monthInt < monthToInt) {

						for (int dayOff = 1; dayOff <= lastDayOfMonth; dayOff++) {
							String dayOffString = String.valueOf(dayOff);
							if (dayOffString.length() == 1) {
								dayOffString = "0" + dayOffString;
							}
							// get Day Of week
							int dayOffOfWeek = DateUtils.initDate(yearOffStr, monthString, dayOffString)
									.get(Calendar.DAY_OF_WEEK);
							String yearMonthDate = yearOffStr + monthString + dayOffString;

							// insert Timesheet for Request Change The Time
							if (styleOff == null) {
								tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
										dayOffString);
								if (tss == null) {
									tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
								}
							}
							// insert Timesheet for Request Off
							else {
								Holiday holiday = holidayRepository.findByDate(yearMonthDate);
								if (dayOffOfWeek != 7 && dayOffOfWeek != 1 && holiday == null) {

									tss = timesheetRepository.findAllTimesheetIns(findTsuByMonth.getTimesheetUserId(),
											dayOffString);
									if (tss == null) {
										tss = timesheetuserserviceimpl.insertTimesheet(dayOffString, findTsuByMonth);
									}
								}

							}
						}

					}
				}
			}
		}

	}

	// Insert Request to Database
	public void insertRequests(String date, String month, String year, String userid, Request formrequest) {

		TimesheetUser findtsu = timesheetUserRepository.findByTimesheetUserUsId(userid, month, year);
		Timesheet tss = new Timesheet();
		TimesheetUser tsu = new TimesheetUser();
		User u = new User();

		try {
			if (findtsu == null) {
				tsu.setMonth(month);
				tsu.setYear(year);
				u.setUserId(userid);
				tsu.setUser(u);
				timesheetUserRepository.save(tsu);
				tss = timesheetuserserviceimpl.insertTimesheet(date, tsu);
			} else {
				tss = timesheetRepository.findAllTimesheetIns(findtsu.getTimesheetUserId(), date);
				if (tss == null) {
					tss = timesheetuserserviceimpl.insertTimesheet(date, findtsu);
				}

			}

			String time_inrq = formrequest.getTimeInRequest().replace(":", "");
			String time_outrq = formrequest.getTimeOutRequest().replace(":", "");
			String time_in = formrequest.getTimeIn().replace(":", "");
			String time_out = formrequest.getTimeOut().replace(":", "");
			Request request = new Request();
			request.setTimeIn(time_in);
			request.setTimeOut(time_out);
			request.setTimeInRequest(time_inrq);
			request.setTimeOutRequest(time_outrq);
			request.setReason(formrequest.getReason());
			request.setNote(formrequest.getNote());
			request.setTimesheet(tss);
			request.setDateFrom(formrequest.getDateFrom());
			request.setDateTo(formrequest.getDateTo());
			request.setStatus("pending");
			request.setCreateDate(common.currentDate());
			request.setCreatorId(userid);
			request.setStyleOff(formrequest.getStyleOff());
			requestRepository.save(request);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	// Update Timesheet is Accepted
	public void updateTimesheet(Timesheet selectedTimesheet, String userid, Request selectedReq, String yearFrom,
			String monthFrom, String dayOffString) throws ParseException {

		String styleOff = selectedReq.getStyleOff();
		if (styleOff != null) {
			selectedTimesheet.setOffDay(styleOff);
		}

		if (selectedReq.getTimeInRequest().equals("") || selectedReq.getTimeInRequest().equals("0000")) {
			selectedTimesheet.setTimeIn(selectedTimesheet.getTimeIn());
		} else {
			selectedTimesheet.setTimeIn(selectedReq.getTimeInRequest());
		}
		if (selectedReq.getTimeOutRequest().equals("") || selectedReq.getTimeInRequest().equals("0000")) {
			selectedTimesheet.setTimeOut(selectedTimesheet.getTimeOut());
		} else {
			selectedTimesheet.setTimeOut(selectedReq.getTimeOutRequest());
		}

		if (!selectedTimesheet.getTimeIn().equals("")) {
			// Calculate time late
			// selectedTimesheet.setTimeLate(selectedTimesheet.getTimeIn());
			if (!selectedTimesheet.getTimeOut().equals("")) {
				// Calculate hour worked
				selectedTimesheet.setTimeSum(selectedTimesheet.getTimeIn());
				// Calculate weekend OT
				int dayOfWeek = DateUtils.initDate(yearFrom, monthFrom, dayOffString).get(Calendar.DAY_OF_WEEK);
				if (dayOfWeek == 7 || dayOfWeek == 1) {
					
					selectedTimesheet.setTimeWeOn(selectedTimesheet.calculateTimeOn(selectedTimesheet.getTimeOut()));
					selectedTimesheet.setTimeWeOt(selectedTimesheet.calculateTimeOt(selectedTimesheet.getTimeOut()));

				} else {
					// Calculate OT
					
					selectedTimesheet.setTimeOn(selectedTimesheet.calculateTimeOn(selectedTimesheet.getTimeOut()));
					selectedTimesheet.setTimeOt(selectedTimesheet.calculateTimeOt(selectedTimesheet.getTimeOut()));
				}
				
			}
		}

		selectedTimesheet.setUpdateId(userid);
		selectedTimesheet.setUpdateDate(common.currentDate());
		timesheetRepository.save(selectedTimesheet);
	}

	// get Last day Of month
	public int lastDayOfMonth(int year, int month) {
		Calendar monthStart = new GregorianCalendar(year, month - 1, 1);
		return monthStart.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

}
