/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: tran-quocviet
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.service;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import arch.timerec.common.DateUtils;
import arch.timerec.model.Holiday;
import arch.timerec.model.Timesheet;
import arch.timerec.repository.HolidayRepository;
import arch.timerec.repository.TimesheetRepository;

@Service
public class HolidayService {
	@Autowired
	private HttpSession session;
	@Autowired
	TimesheetRepository timesheetRepository;
	
	@Autowired
	HolidayRepository holidayRepo;
	
	// get day in month
	public int getDayInMonth(String month, String year) {	
		 
        //Calendar monthStart = new GregorianCalendar(year1, month1, 1);
        Calendar monthStart = new GregorianCalendar(Integer.parseInt(year), Integer.parseInt(month)-1, 1);
        return monthStart.getActualMaximum(Calendar.DAY_OF_MONTH);
    }  
	
	// get count holiday
	public int getholiday(String month, String year) {
		int cntHoliday= 0;
		 List<Holiday> listHoliday = (List<Holiday>) holidayRepo.findAll();
		 int dayInMonth = getDayInMonth(month, year); 
		 for(Holiday holi : listHoliday) {
	        	String holYear = holi.getDate().substring(0,4);
	         	String holMonth = holi.getDate().substring(4,6);
	         	String holDay= holi.getDate().substring(6,8);         	
	         	if (year.equals(holYear)) {
		         	if (month.equals(holMonth)) {
		         		for(int i=1; i<= dayInMonth; i++) {	         			
		         			//String date= String.valueOf(i);
		         			if(i < 10) {
		         				String date= String.valueOf(i);
		         				date = "0" + date;        			
				         		if(date.equals(holDay)){
				         			 	cntHoliday += 1;          			
				         		}
		         			}else if(i >= 10) {
		         				String date= String.valueOf(i);
		         				if(date.equals(holDay)){
			         			 	cntHoliday += 1;          			
		         				}
		         			}
		         		}	
		         	}
	         	}
	         }  
		 return cntHoliday;
	}
	
	// sum day work in month except holiday, saturday, sunday
	public int getDateSpecifilyWorkedays(String month, String year) {
        
        int cntWeekendDay = 0;		// Count of Saturday, Sunday in month
        int cntSpecifiedDay = 0;	// Count of specified workdays     
         
        
        int dayInMonth = getDayInMonth(month, year);        
        
        for (int i =1 ; i <= dayInMonth; i++) {
        	 String date = String.valueOf(i);
        	 int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
        	 
             // Count of Saturday, Sunday in month
             if (dayOfWeek == 7 || dayOfWeek == 1) {
             	cntWeekendDay += 1;
             }                          
        }         
        
        int cntHoliday = getholiday(month, year);
        
        cntSpecifiedDay = dayInMonth - cntWeekendDay - cntHoliday;

        return cntSpecifiedDay;
    }
	
	//sum day worked except off day
	public double getSumDayWorked(String userId, String month, String year) {
		 userId=(String) session.getAttribute("userid");
        List<Timesheet> listTimesheet =(List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);
        double count = 0.0;
        for (Timesheet timesheet : listTimesheet) {
            if (!timesheet.getTimeIn().equals("") && !timesheet.getTimeOut().equals("") && timesheet.getOffDay() == null) {
                count += 1;
            }            
        }
        return count;
    }
	
	//Sum off day
    public double getSumOffday(String userId, String month, String year) {
    	List<Timesheet> listTimesheet = timesheetRepository.findAllTimesheets(userId, month, year);
    	double countOff = 0.0;
    	for(Timesheet timesheet : listTimesheet) {
    		if(timesheet.getOffDay() != null) {
	    		if(timesheet.getOffDay().equals("1") || timesheet.getOffDay().equals("5")) {
	    			countOff += 1;
	    		}
	    		else if(timesheet.getOffDay().equals("2") || timesheet.getOffDay().equals("3")) {
	    			countOff += 0.5;
	    		}
    		}
    	}
    	return countOff;
    }
    
    //Sum day worked of weekend
    public double getSumDayWorkedWE(String userId, String month, String year) {
    	List<Timesheet> listTimesheet = timesheetRepository.findAllTimesheets(userId, month, year);
    	double countDayWorkedWE = 0.0;
    	for(Timesheet timesheet : listTimesheet) {
    		/*int date = Integer.parseInt(timesheet.getDate());*/
    		String date = timesheet.getDate();
    		int dayOfWeek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);
    		
			if(dayOfWeek == 7 || dayOfWeek == 1) {
				if (!timesheet.getTimeIn().equals("") && !timesheet.getTimeOut().equals("")) {
    			countDayWorkedWE += 1;
				}
			}    			    		
    		
    	}
    	return countDayWorkedWE;
    }
	
	// Sum Over Time
    public double getSumOverTime(String userId, String month, String year) {
    	userId=(String) session.getAttribute("userid");
        List<Timesheet> listTimesheet = (List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);
        double sumOvertime = 0.0;
		String countStr = String.valueOf(sumOvertime);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeOt() > 0.0) {
				sumOvertime += timesheet.getTimeOt();

				double sumOverTimeOfDate = timesheet.getTimeOt();
				if (sumOverTimeOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOverTimeOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";
					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvertime = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					hourSumDB = hourSumDB + hourSumStrOfDateDB;

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvertimeStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvertime = Double.parseDouble(sumOvertimeStr);
					
				}
			}
		}
		return sumOvertime;
    }
    
    //sum over time weekend
    public double getSumWeekendOverTime(String userId, String month, String year) {
        List<Timesheet> listTimesheet = (List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);
        double sumOvertimeWE = 0.0;
		String countStr = String.valueOf(sumOvertimeWE);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeWeOt() > 0.0) {
				sumOvertimeWE += timesheet.getTimeWeOt();
				double sumOverTimeWEOfDate = timesheet.getTimeWeOt();
				if (sumOverTimeWEOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOverTimeWEOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";

					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvertimeWE = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					hourSumDB = hourSumDB + hourSumStrOfDateDB;

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvertimeWEStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvertimeWE = Double.parseDouble(sumOvertimeWEStr);

				}
			}
		}
		return sumOvertimeWE;
    }
    
    //Sum over night
    public double getSumOverNight(String userId, String month, String year) {
    	List<Timesheet> listTimesheet = (List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);
    	double sumOvernight = 0.0;
		String countStr = String.valueOf(sumOvernight);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeOn() > 0.0) {
				sumOvernight += timesheet.getTimeOn();
				double sumOvernightOfDate = timesheet.getTimeOn();
				if (sumOvernightOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOvernightOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";

					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}
					countStr = hourSumStr + "." + minuSumStr;
					sumOvernight = Double.parseDouble(countStr);

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);
					
					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					minuSumStr = String.valueOf(minuteSumDB);
					hourSumDB = hourSumDB + hourSumStrOfDateDB;
					hourSumStr = String.valueOf(hourSumDB);

					int minuteSumDBM = minuteSumDB % 60;

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvernightStr = hourSumStrM + "." + minuteSumDBMStr;
					sumOvernight = Double.parseDouble(sumOvernightStr);
					
				}
			}
		}
		return sumOvernight;
    }
    
    //Sum over night weekend
    public double getSumWeekendOverNight(String userId, String month, String year) {
    	List<Timesheet> listTimesheet = (List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);    	
    	double sumOvernightWE = 0.0;
		String countStr = String.valueOf(sumOvernightWE);
		String hourSumStr = countStr;
		String Sumhour[] = hourSumStr.split("\\.");
		hourSumStr = Sumhour[0];
		String minuSumStr = Sumhour[1];
		int minuteSumDB = Integer.parseInt(minuSumStr);
		int hourSumDB = Integer.parseInt(hourSumStr);
		for (Timesheet timesheet : listTimesheet) {
			if (timesheet.getTimeWeOn() > 0.0) {
				sumOvernightWE += timesheet.getTimeWeOn();
				double sumOvernightWEOfDate = timesheet.getTimeWeOn();
				if (sumOvernightWEOfDate != 0) {

					String countStrOfDate = String.valueOf(sumOvernightWEOfDate);
					String hourSumStrOfDate = countStrOfDate;
					String SumhourOfDate[] = hourSumStrOfDate.split("\\.");
					hourSumStrOfDate = SumhourOfDate[0];
					String minuSumStrOfDate = SumhourOfDate[1];

					if (minuSumStr.length() == 1) {
						minuSumStr = minuSumStr + "0";

					} else {
						minuSumStr = minuSumStr.substring(0, 2);

					}
					if (minuSumStrOfDate.length() == 1) {
						minuSumStrOfDate = minuSumStrOfDate + "0";
					} else if (minuSumStrOfDate.length() > 1) {
						minuSumStrOfDate = minuSumStrOfDate.substring(0, 2);
					}					

					int minuSumStrOfDateDB = Integer.parseInt(minuSumStrOfDate);
					int hourSumStrOfDateDB = Integer.parseInt(hourSumStrOfDate);

					minuteSumDB = minuteSumDB + minuSumStrOfDateDB;
					minuSumStr = String.valueOf(minuteSumDB);
					hourSumDB = hourSumDB + hourSumStrOfDateDB;
					hourSumStr = String.valueOf(hourSumDB);

					int minuteSumDBM = minuteSumDB % 60;
					

					double hour = minuteSumDB / 60;
					int hourEntire = (int) hour;

					int hourSumDBM = hourSumDB + hourEntire;
					String hourSumStrM = String.valueOf(hourSumDBM);
					String minuteSumDBMStr = String.valueOf(minuteSumDBM);
					
					String sumOvernightWEString = hourSumStrM + "." + minuteSumDBMStr;
					sumOvernightWE = Double.parseDouble(sumOvernightWEString);

				}
			}
		}
		return sumOvernightWE;
    }
    
    
	
	//Sum OverTime DK;
    public double getSumOvertimeDK(String month, String year) {
    	double sumOTDK = 0.0;
    	String userId=(String) session.getAttribute("userid");
    	List<Timesheet> listTimesheet =(List<Timesheet>) timesheetRepository.findAllTimesheets(userId, month, year);
    	int dateSpecial= getDateSpecifilyWorkedays(month, year);
    	double sumDayWorked= getSumDayWorked(userId, month, year) + getSumOffday(userId, month, year) - getSumDayWorkedWE(userId, month, year);
    	double SumOverTime= getSumOverTime(userId, month, year);
    	double SumOveTimeWE = getSumWeekendOverTime(userId, month, year);
    	double SumOverNight = getSumOverNight(userId, month, year);
    	double SumOverNightWE = getSumWeekendOverNight(userId, month, year);
    	
    	for(Timesheet timesheet: listTimesheet) {  
    		if(timesheet != null) {
	    		if(sumDayWorked != 0.0) {
	    			sumOTDK=((SumOverTime + SumOveTimeWE + SumOverNight + SumOverNightWE)/sumDayWorked)*dateSpecial;
	    		}
    		}
    	} return sumOTDK;
    }
}
