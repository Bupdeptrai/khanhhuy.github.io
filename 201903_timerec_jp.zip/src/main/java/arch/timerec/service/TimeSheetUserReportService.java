/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: ho-nguyenmainguyen
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import arch.timerec.common.DateUtils;
import arch.timerec.model.Holiday;
import arch.timerec.model.Special;
import arch.timerec.model.Timesheet;
import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;
import arch.timerec.repository.HolidayRepository;
import arch.timerec.repository.SpecialRepository;
import arch.timerec.repository.TimesheetRepository;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;

@Service
public class TimeSheetUserReportService implements TimeSheetService {

	@Autowired
	private TimesheetUserRepository timeSheetUserRepository;

	@Autowired
	TimesheetRepository timesheetRepository;

	@Autowired
	HolidayRepository holidayRepository;

	@Autowired
	SpecialRepository specialRepository;

	@Autowired
	private HttpSession session;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	HolidayService holidayService;

	@Override
	public List<Map<String, Object>> report(int timesheetuserid, Locale locale) {

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		List<TimesheetUser> listTimeSheetUser = new ArrayList<TimesheetUser>();

		listTimeSheetUser = timeSheetUserRepository.findByTimesheetUserId(timesheetuserid);
		String date_report = "";
		String date_detail = "";

		if (listTimeSheetUser.size() != 0 && listTimeSheetUser != null) {
			for (int i = 0; i < listTimeSheetUser.size(); i++) {

				// Create new Object TimesheetUser
				TimesheetUser timesheetUser = new TimesheetUser();
				// Create new Object Timesheet
				List<Timesheet> listTimeSheet = new ArrayList<Timesheet>();

				// Set TimesheetUser
				timesheetUser = listTimeSheetUser.get(i);
				// Set List Timesheet
				listTimeSheet = timesheetUser.getTimesheets();

				String year = timesheetUser.getYear();
				String month = timesheetUser.getMonth();

				date_report = year + "/" + month;
				date_detail = date_report + "/" + "01" + " - " + date_report + "/" + timesheetUser.getCountDayInMonth();

				if (listTimeSheet.size() != 0 && listTimeSheet != null) {

					List<Timesheet> listTimesheetNew = new ArrayList<Timesheet>();
					// Add Timesheet 29 - 31 day
					listTimesheetNew = timesheetUser.addTimeSheet(listTimeSheet, timesheetUser.getCountDayInMonth());

					for (int j = 0; j < listTimesheetNew.size(); j++) {
						Map<String, Object> item = new HashMap<String, Object>();
						Timesheet timesheet = listTimesheetNew.get(j);

						item.put("date_report", date_report);
						item.put("date_detail", date_detail);
						item.put("date", timesheet.getDateFormatNumber());
						item.put("time_in", timesheet.getTimeIn());
						item.put("time_out", timesheet.getTimeOut());
						item.put("time_late", timesheet.getBreakTime());
						item.put("time_ot", timesheet.getTimeOt());
						item.put("time_we_ot", timesheet.getTimeWeOt());
						item.put("time_on", timesheet.getTimeOn());
						item.put("time_we_on", timesheet.getTimeWeOn());
						item.put("date_name", DateUtils.getDayOfWeekName(year, month, timesheet.getDate(), locale));
						item.put("working_time", timesheet.getTimeSum());

						if (j == 0) {
							item.put("name", timesheetUser.getUser().getName());
							item.put("userId", timesheetUser.getUser().getStaffId());
							item.put("sum_working_date", timesheetUser.getSumDayWorked());
							item.put("holidays", 0.0);
							item.put("sum_date", timesheetUser.getSumDayWorked());
						}

						result.add(item);
					} // End for j
				} // End if
			} // End for i
		} // End if
		return result;
	}

	@Override
	public List<Map<String, Object>> reportMonthly(String monthVal, String yearVal, Locale locale) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();

		List<TimesheetUser> listTimeSheetUser = new ArrayList<TimesheetUser>();
		String monthly_year = "";
		String date_detail = "";

		String monthValues = monthVal;
		String yearValues = yearVal;

		// get data follow GROUP_ID
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String Name = auth.getName();
		User user = userRepository.findByUserId(Name);
		String typeRole = user.getRole().getRoleName();
		String groupId = user.getGroup().getGroupId();
		if (typeRole.equals("ROLE_ADMIN")) {
			listTimeSheetUser = timeSheetUserRepository.findByMonthYearAdmin(monthValues, yearValues);
		} else if (typeRole.equals("ROLE_LEADER")) {
			listTimeSheetUser = timeSheetUserRepository.findByMonthYearLeader(monthValues, yearValues, groupId);
		}

		if (listTimeSheetUser.size() != 0 && listTimeSheetUser != null) {
			for (int i = 0; i < listTimeSheetUser.size(); i++) {

				Map<String, Object> item = new HashMap<String, Object>();
				TimesheetUser timesheetUser = new TimesheetUser();
				List<Timesheet> listTimeSheet = new ArrayList<Timesheet>();

				timesheetUser = listTimeSheetUser.get(i);
				listTimeSheet = timesheetUser.getTimesheets();
				String year = timesheetUser.getYear();
				String month = timesheetUser.getMonth();

				monthly_year = year + "/" + month;
				date_detail = monthly_year + "/" + "01" + " - " + monthly_year + "/"
						+ timesheetUser.getCountDayInMonth();

				List<Timesheet> listTimesheetNew = new ArrayList<Timesheet>();
				listTimesheetNew = timesheetUser.addTimeSheet(listTimeSheet, timesheetUser.getCountDayInMonth());

				for (int j = 0; j < listTimesheetNew.size(); j++) {

					Timesheet timesheet = listTimesheetNew.get(j);
					int date = j + 1;
					String value = "";
					if (timesheet.getTimeInFormatNumber() == 0 && timesheet.getTimeOutFormatNumber() == 0
							&& timesheet.getTimeSum() == 8.0) {
						value = "OFF";
					} else {
						value = String.valueOf(timesheet.getTimeSum());
					}
					item.put("date_" + date, value);
				}

				// Add date null
				if (listTimesheetNew.size() < 31) {
					for (int k = listTimesheetNew.size() + 1; k <= 31; k++) {
						item.put("date_" + k, "x");
					}
				}
				if (i == 0) {
					item.put("monthly_year", monthly_year);
					item.put("monthly_detail", date_detail);
				}

				item.put("no", i + 1);
				item.put("date_name_1", DateUtils.getDayOfWeekName(year, month, "01", locale));
				item.put("date_name_2", DateUtils.getDayOfWeekName(year, month, "02", locale));
				item.put("date_name_3", DateUtils.getDayOfWeekName(year, month, "03", locale));
				item.put("date_name_4", DateUtils.getDayOfWeekName(year, month, "04", locale));
				item.put("date_name_5", DateUtils.getDayOfWeekName(year, month, "05", locale));
				item.put("date_name_6", DateUtils.getDayOfWeekName(year, month, "06", locale));
				item.put("date_name_7", DateUtils.getDayOfWeekName(year, month, "07", locale));
				item.put("name", timesheetUser.getUser().getName());
				item.put("total_working_time", timesheetUser.getSumTimeWorked());
				item.put("total_working_date", timesheetUser.getSumDayWorked());
				item.put("holiday_yes", timesheetUser.getSumPaidLeaveDays());
				item.put("holiday_no", timesheetUser.getSumUnpaidLeaveDays());
				// Total WorkDays = Day worked + Paid leave + Unpaid leave
				double totalWorkDays = timesheetUser.getSumDayWorked() + timesheetUser.getSumPaidLeaveDays()
						+ timesheetUser.getSumUnpaidLeaveDays();
				item.put("total_date", totalWorkDays);
				item.put("total_time_late", timesheetUser.getSumBreakTime());
				double totalTimeOTBAS = timesheetUser.getSumOverTime() + timesheetUser.getSumOverNight();
				item.put("total_time_ot", totalTimeOTBAS);
				double totalTimeOTWE = timesheetUser.getSumWeekendOverTime() + timesheetUser.getSumWeekendOverNight();
				item.put("end_year", totalTimeOTWE);
				item.put("holidays", 0.0);
				// totalOverTime = Over Time + Weekend Over Time + Over night + Over night
				// weekend
				double totalOverTime = timesheetUser.getSumOverTime() + timesheetUser.getSumOverNight()
						+ timesheetUser.getSumWeekendOverTime() + timesheetUser.getSumWeekendOverNight();
				item.put("total", totalOverTime);

				result.add(item);
			}
		}
		return result;
	}

	@Override
	public TimesheetUser myTimeSheet(String userId, String month, String year) {

		List<TimesheetUser> listTimesheetUser = new ArrayList<TimesheetUser>();
		TimesheetUser timesheetUser = new TimesheetUser();
		timesheetUser = null;
		String monthString = month;

		Integer countHoli = 0;
		listTimesheetUser = timeSheetUserRepository.findByUserIdMonthYear(userId, month, year);
		List<Holiday> listHoliday = (List<Holiday>) holidayRepository.findByYear(year);
		List<Special> listSpecial = specialRepository.findByYear(year);

		if (listTimesheetUser.size() != 0 && listTimesheetUser != null) {
			timesheetUser = listTimesheetUser.get(0);
		}
		List<Timesheet> listTimesheetNew = new ArrayList<Timesheet>();
		List<Timesheet> listTimesheet = new ArrayList<Timesheet>();
		if (timesheetUser != null) {

			listTimesheet = timesheetUser.getTimesheets();

			// Add 29 days false
			listTimesheetNew = timesheetUser.addTimeSheet(listTimesheet, timesheetUser.getCountDayInMonth());

			// Add Holiday
			for (Timesheet timesheet : listTimesheetNew) {
				String dateOfTimesheet = timesheet.getDate();
				if (dateOfTimesheet.length() == 1) {
					dateOfTimesheet = "0" + dateOfTimesheet;
				}
				if (listHoliday.size() != 0) {
					for (Holiday holiday : listHoliday) {
						String dateHoli = holiday.getDate().substring(6, 8);
						String monthHoli = holiday.getDate().substring(4, 6);
						String yearHoli = holiday.getDate().substring(0, 4);

						if (dateHoli.equals(dateOfTimesheet) && monthHoli.equals(monthString)
								&& yearHoli.equals(year)) {
							timesheet.setOffDay(holiday.getName());
							timesheet.setTimesheetUser(timesheetUser);
							if (!timesheet.getTimeIn().equalsIgnoreCase("")
									|| !timesheet.getTimeOut().equalsIgnoreCase("")) {
								timesheetRepository.save(timesheet);
							}
							countHoli = countHoli + 1;

						}
					}
				}

				// set Time OT for Special Day
				if (listSpecial.size() != 0) {
					for (Special special : listSpecial) {
						String dateSpec = special.getDate().substring(6, 8);
						String monthSpec = special.getDate().substring(4, 6);
						String yearSpec = special.getDate().substring(0, 4);

						if (dateSpec.equals(dateOfTimesheet) && monthSpec.equals(month) && yearSpec.equals(year)) {
							if (timesheet.getTimeSum() > special.getWorking_Time()) {
								timesheet.setTimeOt(timeOtSpeciaDay(timesheet.getTimeSum(), special.getWorking_Time(),
										timesheet.getTimeOn()));
								timesheetRepository.save(timesheet);
							}
						}
					}
				}

			}

			// Add date null
			if (listTimesheetNew.size() < timesheetUser.getCountDayInMonth()) {
				for (int k = listTimesheetNew.size() + 1; k <= 31; k++) {
					Timesheet timesheet = new Timesheet();
					timesheet.setDate(String.valueOf(k));
					timesheet.setTimeIn("");
					timesheet.setTimeOut("");
					timesheet.setTimeSum(0.0);
					listTimesheetNew.add(timesheet);
				}
			}
			session.setAttribute("countHoli", countHoli);
			timesheetUser.setTimesheets(listTimesheetNew);
		} else {
			timesheetUser = new TimesheetUser();
			User user = userRepository.findByUserId(userId);
			timesheetUser.setMonth(monthString);
			timesheetUser.setYear(year);
			timesheetUser.setUser(user);
			for (int k = 1; k <= timesheetUser.getCountDayInMonth(); k++) {
				String dateString = String.valueOf(k);
				if (dateString.length() == 1) {
					dateString = "0" + dateString;
				}
				Timesheet timesheet = new Timesheet();
				timesheet.setDate(dateString);
				timesheet.setTimeIn("");
				timesheet.setTimeOut("");
				timesheet.setTimeSum(0.0);

				// Add Holiday
				if (listHoliday.size() != 0) {
					for (Holiday holiday : listHoliday) {
						String dateHoli = holiday.getDate().substring(6, 8);
						String monthHoli = holiday.getDate().substring(4, 6);
						String yearHoli = holiday.getDate().substring(0, 4);
						if (monthHoli.equals(monthString) && yearHoli.equals(year) && dateHoli.equals(dateString)) {
							timesheet.setOffDay(holiday.getName());
							countHoli = countHoli + 1;
						}

					}
				}

				listTimesheetNew.add(timesheet);

			}
			session.setAttribute("countHoli", countHoli);
			timesheetUser.setTimesheets(listTimesheetNew);

		}

		return timesheetUser;
	}

	// Calculate TimeOt of Special day
	public double timeOtSpeciaDay(double timeSum, double workingTime, double timeOn) {
		double timeOtSpeciaDay = 0.0;
		double timeMinus = 0.0;
		// get hour and minute of Time Sum
		String timeSumStr = String.valueOf(timeSum);
		String timeSumSpl = timeSumStr;
		String timeSumArray[] = timeSumSpl.split("\\.");
		String hourSumStr = timeSumArray[0];
		String minuteStr = timeSumArray[1];
		if (minuteStr.length() == 1) {
			minuteStr = minuteStr + "0";
		} else if (minuteStr.length() > 1) {
			minuteStr = minuteStr.substring(0, 2);
		}
		int minuteSumDB = Integer.parseInt(minuteStr);
		int hourSumDB = Integer.parseInt(hourSumStr);

		// get hour and minute of working Time
		String workingTimeStr = String.valueOf(workingTime);
		String workingTimeSpl = workingTimeStr;
		String workingTimeArray[] = workingTimeSpl.split("\\.");

		String hourWT = workingTimeArray[0];
		String minuteWTStr = workingTimeArray[1];
		if (minuteWTStr.length() == 1) {
			minuteWTStr = minuteWTStr + "0";
		} else if (minuteWTStr.length() > 1) {
			minuteWTStr = minuteWTStr.substring(0, 2);
		}
		int minuteWTDB = Integer.parseInt(minuteWTStr);
		int hourWTDB = Integer.parseInt(hourWT);

		// get hour and minute of Time On
		String timeOnStr = String.valueOf(timeOn);
		String timeOnSpl = timeOnStr;
		String timeOnArray[] = timeOnSpl.split("\\.");
		String hourOn = timeOnArray[0];
		String minuteOnStr = timeOnArray[1];
		if (minuteOnStr.length() == 1) {
			minuteOnStr = minuteOnStr + "0";
		} else if (minuteOnStr.length() > 1) {
			minuteOnStr = minuteOnStr.substring(0, 2);
		}
		int mineteOn = Integer.parseInt(minuteOnStr);
		int hourOnDB = Integer.parseInt(hourOn);

		// Calculate timeMinus between time sum and workingTime
		double minuteTM = 0.0;
		int hourTM = 0;
		if (minuteSumDB < minuteWTDB) {
			minuteTM = minuteSumDB + 60 - minuteWTDB;
			hourTM = hourSumDB - 1 - hourWTDB;
			timeMinus = (double) (hourTM + minuteTM / 100);
		} else {
			minuteTM = minuteSumDB - minuteWTDB;
			hourTM = hourSumDB - hourWTDB;
			timeMinus = (double) (hourTM + minuteTM / 100);
		}

		// get hour and minute of Minus Time
		String timeMinusStr = String.valueOf(timeMinus);
		String timeMinuseSpl = timeMinusStr;
		String timeMinusArray[] = timeMinuseSpl.split("\\.");
		String minuteTMStr = timeMinusArray[1];
		if (minuteTMStr.length() == 1) {
			minuteTMStr = minuteTMStr + "0";
		} else if (minuteTMStr.length() > 1) {
			minuteTMStr = minuteTMStr.substring(0, 2);
		}
		int minuteTMDB = Integer.parseInt(minuteTMStr);
		

		// Calculate TimeOt of Special day
		int hourSpe = 0;
		double minuteSpe = 0.0;
		if (minuteTMDB < mineteOn) {
			hourSpe = hourTM - hourOnDB - 1;
			minuteSpe = minuteTMDB + 60 - mineteOn;
			timeOtSpeciaDay = (double) (hourSpe + minuteSpe / 100);
		} else {
			hourSpe = hourTM - hourOnDB;
			minuteSpe = minuteTMDB - mineteOn;
			timeOtSpeciaDay = (double) (hourSpe + minuteSpe / 100);
		}

		return timeOtSpeciaDay;
	}
}