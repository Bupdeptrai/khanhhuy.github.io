/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: nguyen-dinhtoan
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;

import arch.timerec.model.User;
import arch.timerec.repository.UserRepository;

public class CommonService {

	@Autowired
	UserRepository userRep;
	
    // method create auto code userId
    public String autoUserId(String userid) {
        String struserid = userid.substring(4, 8);
        int userId = Integer.parseInt(struserid);
        ++userId;
        String countUserId =""+userId;
            if(countUserId.trim().length()!=4) {
                int count = 4-countUserId.trim().length();
                for (int i = 0; i < count; i++) {
                    countUserId = "0"+countUserId;
                }
            }
            return "ARCH".concat(""+countUserId);
        }
    
 // method create auto code staffId
    public String autoStaffId(String staffid) {
        String strstaffid = staffid.substring(1, 5);
        int staffId = Integer.parseInt(strstaffid);
        ++staffId;
        String countStaffId =""+staffId;
            if(countStaffId.trim().length()!=4) {
                int count = 4-countStaffId.trim().length();
                for (int i = 0; i < count; i++) {
                	countStaffId = "0"+countStaffId;
                }
            }
            return "s".concat(""+countStaffId);
        }

    public String autoGroupId(String groupid) {
        String strgroupid = groupid.substring(2, 6);
        int groupId = Integer.parseInt(strgroupid);
        ++groupId;
        String countGroupId =""+groupId;
            if(countGroupId.trim().length()!=4) {
                int count = 4-countGroupId.trim().length();
                for (int i = 0; i < count; i++) {
                	countGroupId = "0"+countGroupId;
                }
            }
            return "GR".concat(""+countGroupId);
        }
    // get value current date
    public Date currentDate() throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        Date curenddate = dateFormat.parse(dateFormat.format(date));
        return curenddate;
    }

    // Status Employee working
    public Map<String, String> mapStatus(String local) {
        Map<String, String> mapstatus = new HashMap<String, String>();
        if (local.equals("ja_JP")) {
        	mapstatus.put("0", "無効");
            mapstatus.put("1", "有効");
        } else {
           mapstatus.put("0", "Inactive");
           mapstatus.put("1", "Active");
        }
        return mapstatus;
    }
	
	 public Map<String, String> SendMail(User user ){
    	Map<String, String> mapSendmail= new HashMap<String, String>();
    	mapSendmail.put("mailform", "testsendmaildn@gmail.com");
    	mapSendmail.put("toMail", user.getEmail());
    	mapSendmail.put("subject", "New Password");
    	mapSendmail.put("body", user.getPassword());
    	
    
    	return  mapSendmail;
    }   
	 

	 
	
	 
}
