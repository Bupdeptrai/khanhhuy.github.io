package arch.timerec.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import arch.timerec.model.Groups;
import arch.timerec.repository.GroupRepository;

@Service
public class GroupServiceLImpl {
	
	 @Autowired
	 private GroupRepository groupRepository;
	 CommonService commom = new CommonService();

	 public void insertorupdategroup(Groups groups) throws ParseException {
			Groups findGroupID = groupRepository.findByGroupId(groups.getGroupId());
			
	        if (findGroupID == null) {

	        	groups.setCreateDate(commom.currentDate());
	        	groups.setStatus(1);
	        	groupRepository.save(groups);

	            
	        } else {
	        	groups.setCreateDate(commom.currentDate());
	        	groups.setStatus(0);
	        	groupRepository.save(groups);
	        }
	    }

	    public String autoCodeGroupId() {
	    	
	        List<Groups> lstGroup = (List<Groups>) groupRepository.findAll();
	        CommonService autoCode = null;
	        String groupId;
	        String uId = null;
	        if(lstGroup == null) {
	        	groupId = "GR0001";
	        }
	        else{
	        	groupId = lstGroup.get(lstGroup.size() - 1).getGroupId();
	        autoCode = new CommonService();
	      
	        }
	        uId = autoCode.autoGroupId(groupId);
	        return uId;
	        
	    }
	    

}
