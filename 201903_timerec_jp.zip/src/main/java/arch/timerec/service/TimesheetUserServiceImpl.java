/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: tran-ngocmy
 * Create day: 2017/12/11
 * Version: 1.0
 */

package arch.timerec.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import arch.timerec.common.DateUtils;
import arch.timerec.model.Timesheet;
import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;
import arch.timerec.repository.TimesheetRepository;
import arch.timerec.repository.TimesheetUserRepository;

@Service
public class TimesheetUserServiceImpl {

    @Autowired
    private TimesheetUserRepository timesheetuserrepository;
    @Autowired
    private TimesheetRepository timesheetrepository;

    CommonService common = new CommonService();

    public String insertOrupdate(HttpSession session) {

        String messNo = null;
        String year = "";
        String month = "";
        String day = "";
        String time = "";
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HHmm").format(Calendar.getInstance().getTime());
        String CheckIn[] = timeStamp.split("-");
        year = CheckIn[0];
        month = CheckIn[1];
        day = CheckIn[2];
        int hours = Integer.parseInt(CheckIn[3].substring(0,2)) ;
        time = String.valueOf(String.format("%02d", hours)).concat(CheckIn[3].substring(2));
        int timeOut = Integer.parseInt(time);
        int dayOut = Integer.parseInt(day);
        String idUser = (String) session.getAttribute("userid");
        User userUpdate = new User();
        userUpdate.setUserId(idUser);
        // search timesheet_user
        TimesheetUser tsu = timesheetuserrepository.findByTimesheetUserUsId(idUser, month, year);
        // Check TimeIn
        Timesheet timesheet;
        if (tsu == null) {
            tsu = new TimesheetUser();
            tsu.setUser(userUpdate);
            tsu.setMonth(month);
            tsu.setYear(year);
            timesheetuserrepository.save(tsu);
        }
        // insert table Timesheet
        String actionCheck = (String) session.getAttribute("checkInOut");
        int timesheet_user_id = tsu.getTimesheetUserId();
        if (actionCheck.equals("checkin")) {
            timesheet = timesheetrepository.findAllTimesheetIns(timesheet_user_id, day);
            if (timesheet == null) {
                timesheet = new Timesheet();
                tsu.setTimesheetUserId(timesheet_user_id);
                timesheet.setDate(day);
                timesheet.setTimeIn(time);
                timesheet.setTimeOut(" ");
//                timesheet.setTimeLate(timesheet.getTimeIn());
                timesheet.setTimeOn(0.0);
                timesheet.setTimeWeOn(0.0);
                timesheet.setTimeOt(0.0);
                timesheet.setTimeWeOt(0.0);
                timesheet.setTimeSum(0.0);
                timesheet.setTimesheetUser(tsu);
                timesheetrepository.save(timesheet);
                // Display message "You have been checked in successfully.
                messNo = "0";
            } else {
                // Check-in when having data exist in TBL due to request day-off
                if (timesheet.getTimeIn().equals("") && timesheet.getTimeOut().equals("")) {
                    timesheet.setTimeIn(time);
                    timesheet.setTimeOut("");
//                    timesheet.setTimeLate(timesheet.getTimeIn());
                    timesheetrepository.save(timesheet);
                    // Display message "You have been checked in successfully.
                    messNo = "0";
                } else
                    // Display message "You already checked in. You cannot do it again."
                    messNo = "1";
            }
            // Check TimeOut
        } else {
            timesheet = timesheetrepository.findAllTimesheetIns(timesheet_user_id, day);
            if (timesheet == null && timeOut > 600) {
                messNo = "4";
            } else {
                if (timesheet != null && timesheet.getTimeIn().equals("")) {
                    messNo = "4";
                } else {
                    // ------------------------------
                    // Format dayOut small 10
                    String dayOut_fm = "";
                    if (dayOut < 10) {
                        dayOut_fm = "0";
                    }
                    int monthOut = Integer.parseInt(month);
                    // Format monthOut small 10
                    String monthOut_fm = "";
                    if (monthOut < 10) {
                        monthOut_fm = "0";
                    }
                    // Check timeOut before 6:00 AM
                    if (0 <= timeOut && timeOut <= 600) {
                        // Check Date 01/02 -> 01/12
                        if (dayOut == 1 && monthOut != 1) {
                            String monthBefore = monthOut_fm.concat(String.valueOf(monthOut - 1));
                            TimesheetUser tsuBefore = timesheetuserrepository.findByTimesheetUserUsId(idUser,
                                    monthBefore, year);
                            TimesheetUser timesheetUser = new TimesheetUser();
                            timesheetUser.setMonth(monthBefore);
                            timesheetUser.setYear(year);
                            int dayInMonth = timesheetUser.getCountDayInMonth();
                            timesheet = timesheetrepository.findByTimesheetUserDate(tsuBefore.getTimesheetUserId(),
                                    String.valueOf(dayInMonth));
                        }
                        // Check Date 01/01
                        else if (dayOut == 1 && monthOut == 1) {
                            int yearOut = Integer.parseInt(year);
                            String yearBefore = String.valueOf(yearOut - 1);
                            TimesheetUser tsuBefore = timesheetuserrepository.findByTimesheetUserUsId(idUser, "12",
                                    yearBefore);

                            TimesheetUser timesheetUser = new TimesheetUser();
                            timesheetUser.setMonth("12");
                            timesheetUser.setYear(yearBefore);
                            int dayInMonth = timesheetUser.getCountDayInMonth();

                            timesheet = timesheetrepository.findByTimesheetUserDate(tsuBefore.getTimesheetUserId(),
                                    String.valueOf(dayInMonth));
                        }
                        // difference date 01
                        else {
                            timesheet = timesheetrepository.findByTimesheetUserDate(timesheet_user_id,
                                    dayOut_fm.concat(String.valueOf(dayOut - 1)));
                        }
                    }
                    // Check Time out < 24h
                    else {

                        timesheet = timesheetrepository.findByTimesheetUserDate(timesheet_user_id,
                                dayOut_fm.concat(String.valueOf(dayOut)));
                    }

                    // Caculator TimeWeOt, TimeWeOn
                    if (timesheet != null) {
                        timesheet.setTimeOut(time);
                        int dayOfWeek = DateUtils.initDate(year, month, day).get(Calendar.DAY_OF_WEEK);
                        if (dayOfWeek == 7 || dayOfWeek == 1) {
                            timesheet.setTimeWeOt(timesheet.calculateTimeOt(time));
                            timesheet.setTimeWeOn(timesheet.calculateTimeOn(time));

                        } else {
                            timesheet.setTimeOt(timesheet.calculateTimeOt(time));
                            timesheet.setTimeOn(timesheet.calculateTimeOn(time));
                        }

                        timesheet.setTimeSum(timesheet.getTimeIn());
                        timesheetrepository.save(timesheet);
                        // Display message "You have been checked out successfully."
                        messNo = "2";
                    } else {
                        // Display message "You already checked out. You cannot do it again."
                        messNo = "3";
                    }
                }
            }
        }
        return messNo;
    }

    public Timesheet insertTimesheet (String date, TimesheetUser tsu) {
    	Timesheet ts = new Timesheet();
         ts.setDate(date);
         ts.setTimeIn("");
         ts.setTimeOut("");
         ts.setBreakTime(0.0);
         ts.setTimeOn(0.0);
         ts.setTimeWeOn(0.0);
         ts.setTimeOt(0.0);
         ts.setTimeWeOt(0.0);
         ts.setTimeSum(0.0);
         ts.setTimesheetUser(tsu);
         timesheetrepository.save(ts);
         return ts;
    }
}