/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: ho-nguyenmainguyen
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.service;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import arch.timerec.model.TimesheetUser;

public interface TimeSheetService {

    public List<Map<String, Object>> report(int timsheetuserid, Locale locale);
    public List<Map<String, Object>> reportMonthly(String year, String month, Locale locale);
    public TimesheetUser myTimeSheet(String userId, String year, String month);
}