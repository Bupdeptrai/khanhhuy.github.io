package arch.timerec.common;

import java.util.Calendar;
import java.util.Locale;

public class DateUtils {
	public static Calendar initDate(int year, int month, int date) {
		Calendar cal = Calendar.getInstance();
    	cal.setFirstDayOfWeek(Calendar.MONDAY);
    	cal.set(year, month - 1, date);
    	return cal;
	}
	
	public static Calendar initDate(String year, String month, String date) {
		int _year = Integer.parseInt(year);
		int _month = Integer.parseInt(month);
		int _date = Integer.parseInt(date);
		Calendar cal = Calendar.getInstance();
    	cal.setFirstDayOfWeek(Calendar.MONDAY);
    	cal.set(_year, _month - 1, _date);
    	return cal;
	}
	
	public static String getDayOfWeekName(String year, String month, String date, Locale locale) {
		Calendar cal = initDate(year, month, date);
		return cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, locale);
	}
}
