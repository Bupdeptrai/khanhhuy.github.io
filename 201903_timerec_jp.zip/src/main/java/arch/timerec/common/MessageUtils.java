package arch.timerec.common;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

@Service
public class MessageUtils {
	@Autowired  
    private static MessageSource messageSource;

    public static String getMessage(Locale loc, String code) {
        return messageSource.getMessage(code, new Object[]{}, loc);
    }
}
