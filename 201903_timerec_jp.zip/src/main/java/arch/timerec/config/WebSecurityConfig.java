/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.config;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


/*
 * Class name: WebSecurityConfig
 *
 * Defines callback methods to customize the Java-based configuration for Spring MVC
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Autowired
    private CheckAutheticationSuccessHandler successHandler;
    
    @Autowired
    private CustomAuthFailureHandler failHandler;

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
    }

    // Check request to the application is authenticated with form based login or
    // HTTP basic authentication
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        
		http
            .authorizeRequests()
                .antMatchers("/").hasAnyRole("ADMIN", "LEADER", "MEMBER")
                .antMatchers("/login").permitAll()
                .antMatchers("/myTimesheet").hasAnyRole("ADMIN", "LEADER", "MEMBER")
                .antMatchers("/changePassword").hasAnyRole("ADMIN", "LEADER", "MEMBER")
                .antMatchers("/addUser").hasRole("ADMIN")
                .antMatchers("/userList").hasRole("ADMIN")
                .antMatchers("/updateUser").hasRole("ADMIN")
                .antMatchers("/searchUser").hasRole("ADMIN")
                .antMatchers("/deleteUser").hasRole("ADMIN")
                .antMatchers("/dailyTimesheet").hasAnyRole("ADMIN", "LEADER")
                .antMatchers("/monthlyTimesheet").hasAnyRole("ADMIN", "LEADER")
                .antMatchers("/CheckRequest").hasAnyRole("ADMIN", "LEADER")
                .antMatchers("/groupAdmin").hasRole("ADMIN")
                .antMatchers("/addGroup").hasRole("ADMIN")
                .antMatchers("/deleteGroup").hasRole("ADMIN")
                .antMatchers("/updateGroup").hasRole("ADMIN")
                .antMatchers("/searchGroup").hasRole("ADMIN")
                .antMatchers("/inactiveGroup").hasRole("ADMIN")
                .antMatchers("/activeGroup").hasRole("ADMIN")
                .antMatchers("/SpecialList").hasRole("ADMIN")
                .antMatchers("/download").hasRole("ADMIN")
                .antMatchers("/processExcelSpecial").hasRole("ADMIN")
                .anyRequest().authenticated()
                .and()
            .formLogin()
                .loginPage("/login")
                .usernameParameter("userId")
                .passwordParameter("password")
                .successHandler(successHandler)
                .failureHandler(failHandler)                   
                .and()
            .logout()
				.logoutUrl("/logout")
				.logoutSuccessUrl("/login?logout")
                .invalidateHttpSession(true)
                .permitAll();
        http
            .exceptionHandling()
            .accessDeniedPage("/403");

    }

    // Omits Spring Security and none of Spring Security’s features will be
    // available (Impact global security)
    @Override
    public void configure(WebSecurity web) throws Exception {
        web
            .ignoring()
            .antMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**");
    }
}
