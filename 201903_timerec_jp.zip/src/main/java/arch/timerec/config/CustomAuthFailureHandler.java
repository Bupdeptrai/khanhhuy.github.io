package arch.timerec.config;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;




@Component
public class CustomAuthFailureHandler implements AuthenticationFailureHandler{
	@Autowired
	MessageSource msgSrc;
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	@Override
    public void onAuthenticationFailure( HttpServletRequest request, HttpServletResponse response,
            AuthenticationException exception) throws IOException, ServletException {
        redirectStrategy.sendRedirect(request, response, "/login?error");
        Model model ; 
        Locale locale;
        HttpSession session = request.getSession();
        String user = request.getParameter("userId");
        String pass = request.getParameter("password");
        
        session.setAttribute("userFail", user);
        
        session.setAttribute("passFail", pass);
    }
}
