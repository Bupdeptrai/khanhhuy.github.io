package arch.timerec.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import arch.timerec.model.User;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;

@Component
public class CheckAutheticationSuccessHandler implements AuthenticationSuccessHandler {

    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Autowired
    UserRepository userRepo;
    
    @Autowired 
    TimesheetUserRepository timesheetUserRepo;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication auth)
            throws IOException, ServletException {
        HttpSession session = request.getSession();
        String userId = auth.getName();
        User loginUser = userRepo.findByUserId(userId);
        
        
        session.setAttribute("userid", loginUser.getUserId());
        session.setAttribute("password", loginUser.getPassword());
        session.setAttribute("name", loginUser.getName());
        
        session.setAttribute("groupid", loginUser.getGroup().getGroupId());
        
        if (loginUser.getDelFlg().equals("0")) {
            redirectStrategy.sendRedirect(request, response, "/login?error");
        } else if (loginUser.getPwdFlg().equals("0")) {
            redirectStrategy.sendRedirect(request, response, "/changePassword");
        } else {
            redirectStrategy.sendRedirect(request, response, "/");
        }
    }
}
