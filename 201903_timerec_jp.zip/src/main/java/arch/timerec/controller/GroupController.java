package arch.timerec.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import arch.timerec.model.Groups;
import arch.timerec.model.Role;
import arch.timerec.model.User;
import arch.timerec.repository.DailyTimesheetRepository;
import arch.timerec.repository.GroupRepository;
import arch.timerec.repository.MonthlyTimesheetRepository;
import arch.timerec.repository.RoleRepository;
import arch.timerec.repository.TimesheetRepository;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;
import arch.timerec.service.GroupServiceLImpl;
import arch.timerec.service.RequestServiceImpl;
import arch.timerec.service.TimeSheetUserReportService;
import arch.timerec.service.TimesheetUserServiceImpl;
import arch.timerec.service.UserServiceImpl;

@Controller
public class GroupController {

	@Autowired
	DailyTimesheetRepository dailyRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	MonthlyTimesheetRepository monthlyRepository;

	@Autowired
	TimesheetUserRepository timesheetUserRepository;

	@Autowired
	TimesheetRepository timesheetRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	MessageSource msgSrc;

	@Autowired
	TimesheetUserServiceImpl TimesheetUserImpl;

	@Autowired
	UserServiceImpl userserviceimpl;

	@Autowired
	GroupServiceLImpl groupServiceLImpl;

	@Autowired
	RequestServiceImpl requestServiceImpl;

	@Autowired
	TimeSheetUserReportService timeSheetUserReportService;

	@Autowired
	GroupRepository groupRepository;

	@Value("${button.save.success}")
	private String messageSave;


	@RequestMapping(value = "/groupAdmin")
	public String groupAdmin(Model model, HttpServletRequest request, HttpSession session) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		User user = userRepository.findByUserId(userId);
		String typeRole = user.getRole().getRoleName();

		if (typeRole.equals("ROLE_ADMIN")) {

			List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
			model.addAttribute("listGroup", listGroup);
		}
		return "Group";
	}

	@RequestMapping(value = "/groupAdmin", method = RequestMethod.POST)
	public String deleteGroup(@ModelAttribute("groupForm") Groups groupForm, BindingResult bindingResult, Model model,
			HttpSession session) throws ParseException {
		String sessionUserid = (String) session.getAttribute("userid");
		if (bindingResult.hasErrors()) {
			model.addAttribute("groupId", groupServiceLImpl.autoCodeGroupId());
			return "AddGroup";
		}

		groupForm.setCreateId(sessionUserid);
		groupServiceLImpl.insertorupdategroup(groupForm);
		model.addAttribute("message", messageSave);
		model.addAttribute("groupId", groupServiceLImpl.autoCodeGroupId());
		model.addAttribute("groupForm", new Groups());
		return "AddGroup";
	}

	@RequestMapping(value = "/groupLeader")
	public String groupLeader(Model model, HttpServletRequest request, HttpSession session) {

		String groupid = (String) session.getAttribute("groupid");
		String url = request.getParameter(groupid);
		if (url == null) {
			return "403";
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		User user = userRepository.findByUserId(userId);
		String typeRole = user.getRole().getRoleName();

		if (typeRole.equals("ROLE_LEADER")) {

			Groups group = groupRepository.findByGroupId(groupid);
			List<User> listUser = userRepository.findGroupMember(groupid);
			model.addAttribute("group", group);
			model.addAttribute("listUser", listUser);
		}
		return "GroupLeader";
	}

	@RequestMapping(value = "/addGroup", method = RequestMethod.GET)
	public String registrationgroup(Model model, HttpServletRequest request, HttpSession session) {
		model.addAttribute("groupForm", new Groups());
		model.addAttribute("groupId", groupServiceLImpl.autoCodeGroupId());
		return "AddGroup";
	}

	@RequestMapping(value = "/addGroup", method = RequestMethod.POST)
	public String insertorupdategroup(@ModelAttribute("groupForm") Groups groupForm, BindingResult bindingResult,
			Model model, HttpSession session) throws ParseException {
		String sessionUserid = (String) session.getAttribute("userid");
		String groupName = groupForm.getGroupName();
		if (groupName.trim().isEmpty() || groupName == null) {
			model.addAttribute("mess_err", "1");
			return "AddGroup";
		}
		if (bindingResult.hasErrors()) {
			model.addAttribute("groupId", groupServiceLImpl.autoCodeGroupId());
			return "AddGroup";
		}

		groupForm.setCreateId(sessionUserid);
		groupServiceLImpl.insertorupdategroup(groupForm);
		model.addAttribute("message", messageSave);
		model.addAttribute("groupId", groupServiceLImpl.autoCodeGroupId());
		model.addAttribute("groupForm", new Groups());
		return "AddGroup";
	}

	@RequestMapping(value = "/updateGroup", method = RequestMethod.GET)
	public String updateGroup(Model model, HttpServletRequest request) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		User user = userRepository.findByUserId(userId);
		String typeRole = user.getRole().getRoleName();
		String checkSt = request.getParameter("checkSt");
		if (typeRole.equals("ROLE_ADMIN")) {
			List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
			model.addAttribute("listGroup", listGroup);
			model.addAttribute("userForm", new User());
			model.addAttribute("userId", userserviceimpl.autoCodeUserId());
		}

		String groupId = request.getParameter("groupId");
		Groups group = groupRepository.findByGroupId(groupId);
		model.addAttribute("group", group);

		String groupfree = "GR0001";
		List<User> listUser = (List<User>) userRepository.findGroupMember(groupId);
		List<User> lstleader = (List<User>) userRepository.findGroupLeader(groupId);
		model.addAttribute("listUser", listUser);
		model.addAttribute("checkSt", checkSt);
		model.addAttribute("lstleader", lstleader);

		List<User> listGroupFree = (List<User>) userRepository.findGroupMember(groupfree);
		model.addAttribute("listGroupFree", listGroupFree);
		return "UpdateGroup";
	}

	@RequestMapping(value = "/updateGroup", method = RequestMethod.POST)
	public String updateMemberPost(HttpServletRequest request) {
		String groupId = request.getParameter("groupid");
		String leader = request.getParameter("leader");
		String listAdd[] = request.getParameterValues("listadd");
		String listDelete[] = request.getParameterValues("listdelete");
		User uLNew = null;
		if (leader != null && !leader.equals("")) {
			uLNew = userRepository.findByUserId(leader);
		}
		List<User> uLOldL = userRepository.findGroupMember(groupId);
		List<Role> role = (List<Role>) roleRepository.findAll();
		if (uLNew != null) {
			uLNew.setRole(role.get(1));
			userRepository.save(uLNew);
		}
		if (uLOldL.size() > 0) {
			User uLOld = uLOldL.get(0);
			if (uLOld != null && uLOld != uLNew) {
				uLOld.setRole(role.get(2));
				userRepository.save(uLOld);
			}
		}
		if ((ArrayUtils.contains(listDelete, leader) && !leader.equals(""))) {
			User uLOld = uLOldL.get(0);
			if (uLOld != null) {
				uLOld.setRole(role.get(2));
				userRepository.save(uLOld);
			}
		}
		StringBuffer add = new StringBuffer();
		StringBuffer del = new StringBuffer();
		for (String item : listAdd) {
			add.append(item + "/");
		}

		for (String item : listDelete) {
			del.append(item + "/");
		}

		String adduserid = add.toString();
		String deluserid = del.toString();

		userserviceimpl.updateGroupId(adduserid, deluserid, groupId);

		return "redirect:/updateGroup" + "?groupId=" + groupId;
	}

	@RequestMapping(value = "/deleteGroup")
	public String deleteGroup(Model model, @RequestParam String groupId, HttpServletRequest request) {
		userRepository.findByUserGroup(groupId);
		groupRepository.delete(groupId);
		return "redirect:/groupAdmin";
	}

	@RequestMapping(value = "/searchGroup", method = RequestMethod.GET)
	public String searchUser(Model model, @RequestParam("searchVal") String value,
			@RequestParam("cond") String search) {
		List<Groups> listGroupSearch = new ArrayList<>();
		if (search.equals("groupName")) {
			listGroupSearch = groupRepository.findByGroupName(value);
		} else if (search.equals("groupId")) {
			listGroupSearch = groupRepository.searchByGroupId(value);
		}
		model.addAttribute("listGroup", listGroupSearch);
		return "Group";
	}

	@RequestMapping(value = "/inactiveGroup")
	public String inactiveGroup(HttpSession session, Model model, @RequestParam String groupId,
			HttpServletRequest request) throws ParseException {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		User user = userRepository.findByUserId(userId);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Date curenddate = dateFormat.parse(dateFormat.format(date));
		Groups group = groupRepository.findByGroupId(groupId);
		group.setStatus(0);
		group.setUpdateId(user.getUserId());
		group.setUpdateDate(curenddate);
		groupRepository.save(group);
		return "redirect:/updateGroup" + "?groupId=" + groupId;
	}

	@RequestMapping(value = "/activeGroup")
	public String activeGroup(HttpSession session, Model model, @RequestParam String groupId,
			HttpServletRequest request) throws ParseException {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = auth.getName();
		User user = userRepository.findByUserId(userId);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Date curenddate = dateFormat.parse(dateFormat.format(date));
		Groups group = groupRepository.findByGroupId(groupId);
		group.setStatus(1);
		group.setUpdateId(user.getUserId());
		group.setUpdateDate(curenddate);
		groupRepository.save(group);
		return "redirect:/updateGroup" + "?groupId=" + groupId;
	}
}
