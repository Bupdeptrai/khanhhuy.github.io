package arch.timerec.controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import arch.timerec.model.Request;
import arch.timerec.service.RequestServiceImpl;

@Controller
public class RequestOffController {
	

	@Autowired
	RequestServiceImpl requestServiceImpl;
	
	@RequestMapping(value = "/sendRequestOff", method = RequestMethod.POST)
    public @ResponseBody Request SendRequestOff(Model model, @RequestParam("dateFrom") String datefrom,
    		@RequestParam("dateTo") String dateto,
    		@RequestParam("radio") String radio,
    		@RequestParam("reason") String reason,
    		HttpSession session,HttpServletRequest request) throws ParseException{
    	
	    	String dateFrom = datefrom.replace("/", "");
	    	String dateTo = dateto.replace("/", "");
	    	Request formRequest = new Request(); 
	    	
	    	formRequest.setDateFrom(dateFrom);
	    	formRequest.setDateTo(dateTo);
	    	formRequest.setReason(reason);
	    	formRequest.setTimeIn("0000");
			formRequest.setTimeInRequest("0000");
			formRequest.setTimeOut("0000");
			formRequest.setTimeOutRequest("0000");
			formRequest.setStyleOff(radio);
	    			
	    	String yearVal = dateFrom.substring(0, 4);        
	    	String monthVal = dateFrom.substring(4, 6);
	    	String dayVal = dateFrom.substring(6,8);
	    		
	        String userid = (String) session.getAttribute("userid");
	        requestServiceImpl.insertRequest(dayVal,monthVal, yearVal, userid, formRequest);
	    	           
        return  formRequest;
    }
}
