/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: ho-nguyenmainguyen
 * Create day: 2017/12/04
 * Version: 1.0
 */

package arch.timerec.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.jasperreports.JasperReportsXlsxView;

import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;
import arch.timerec.service.TimeSheetService;
import arch.timerec.service.TimeSheetUserReportService;

@Controller
public class ReportController {

    @Autowired
    private TimeSheetService timeSheetService; 

    @Autowired
    private UserRepository userrepository;

    @Autowired
    TimeSheetUserReportService timeSheetUserReportService;

    @Autowired
    private TimesheetUserRepository timesheetuserRepository;

    @Autowired
    private ApplicationContext applicationContext; 

    // Export Daily Report
    @GetMapping("/reportDaily/{userId}")
    public ModelAndView exportDailyReportExcel(@PathVariable String userId, HttpServletRequest request, Model model, HttpSession session, Locale locale) {

       String month_year = request.getParameter("m");
       String yearVal = month_year.substring(0, 4);
       String monthVal = month_year.substring(5, 7);
       
       // Get locale languge
       String localeStr = locale.getLanguage();
       
       TimesheetUser tsu = timesheetuserRepository.findByTimesheetUserUsId(userId, monthVal, yearVal);

       // Export Data Excel
       if (tsu != null && tsu.getTimesheets().size() > 0) {
           JasperReportsXlsxView view = new JasperReportsXlsxView();
           
           // Check Format Excel English (en) or Japan (ja)
           if (localeStr.equals("ja")) {
             view.setUrl("classpath:reports/daily_report_jp.jrxml");
           } else  {
             view.setUrl("classpath:reports/daily_report.jrxml");
           } 
           
           view.setApplicationContext(applicationContext);

           String year = "";
           String month = "";
           String day = "";
           String time = "";
           User user = new User();
           user = userrepository.findByUserId(userId);
           // Get Date Time
           String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HHmm").format(Calendar.getInstance().getTime());
           String CheckIn[] = timeStamp.split("-");
           year = CheckIn[0];
           month = CheckIn[1];
           day = CheckIn[2];
           time = CheckIn[3];

           String test = "DailyReport_" + user.getName() + "_" + year + month + day + time + ".xls";
           Properties ppt = new Properties();
           ppt.put("Content-Disposition", "attachment; filename=" + test);
           view.setHeaders(ppt);

           Map<String, Object> params = new HashMap<String, Object>();
           params.put("datasource", timeSheetService.report(tsu.getTimesheetUserId(), locale));

           return new ModelAndView(view, params);
       }
       // No data export
       else {
           // Set message
           session.setAttribute("mesReport", "nodata");
           String month = yearVal+"/"+monthVal;

           return new ModelAndView("redirect:/myTimesheet"+"?userid="+userId+"&m="+month, null);
       }
    }

    // Export Monthly Report
    @GetMapping("/reportMonthly")
    public ModelAndView exportMonthlyReportExcel(HttpServletRequest request,  HttpSession session, Locale locale) {

        String month_year = request.getParameter("mm");
        String yearVal = month_year.substring(0, 4);
        String monthVal = month_year.substring(5);
        
        // Get locale languge
        String localeStr = locale.getLanguage();

        List<TimesheetUser> listTimesheetUser = new ArrayList<TimesheetUser>();
        listTimesheetUser = timesheetuserRepository.findByMonthYear(yearVal, monthVal);
        if (listTimesheetUser != null && listTimesheetUser.size() != 0) {

           JasperReportsXlsxView view = new JasperReportsXlsxView();
           
           // Check Format Excel English (en) or Japan (jp)
           if (localeStr.equals("ja")) {
             view.setUrl("classpath:reports/monthly_report_jp.jrxml");
           } else  {
             view.setUrl("classpath:reports/monthly_report.jrxml");
           } 
           
           view.setApplicationContext(applicationContext);

           String year = "";
           String month = "";
           String day = "";
           String time = "";
           String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HHmm").format(Calendar.getInstance().getTime());
           String CheckIn[] = timeStamp.split("-");
           year = CheckIn[0];
           month = CheckIn[1];
           day = CheckIn[2];
           time = CheckIn[3];

           String test = "MonthlyReport_" + year + month + day + time + ".xls";
           Properties ppt = new Properties();
           ppt.put("Content-Disposition", "attachment; filename=" + test);
           view.setHeaders(ppt);

           Map<String, Object> params = new HashMap<String, Object>();
           params.put("datasource", timeSheetService.reportMonthly(yearVal, monthVal, locale));

           return new ModelAndView(view, params);
        }
        // No data export
        else {
            // Set message
            session.setAttribute("mesReport", "nodata");
            String month = yearVal+"/"+monthVal;

            return new ModelAndView("redirect:/monthlyTimesheet"+"?m="+month, null);
        }
    }
}
