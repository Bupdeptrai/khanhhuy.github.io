/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: doan-xuanliem
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import arch.timerec.common.DateUtils;
import arch.timerec.model.Groups;
import arch.timerec.model.Request;
import arch.timerec.model.Role;
import arch.timerec.model.Timesheet;
import arch.timerec.model.TimesheetUser;
import arch.timerec.model.User;
import arch.timerec.repository.DailyTimesheetRepository;
import arch.timerec.repository.GroupRepository;
import arch.timerec.repository.MonthlyTimesheetRepository;
import arch.timerec.repository.RequestRepository;
import arch.timerec.repository.RoleRepository;
import arch.timerec.repository.TimesheetRepository;
import arch.timerec.repository.TimesheetUserRepository;
import arch.timerec.repository.UserRepository;
import arch.timerec.service.CommonService;
import arch.timerec.service.HolidayService;
import arch.timerec.service.RequestServiceImpl;
import arch.timerec.service.TimeSheetUserReportService;
import arch.timerec.service.TimesheetUserServiceImpl;
import arch.timerec.service.UserServiceImpl;
import arch.timerec.validator.CommonValidator;
import arch.timerec.validator.UpdateUserValidator;
import arch.timerec.validator.UserValidator;

/*
 * Class name: MainController
 *
 * Responsible for processing user requests, building an model and passes it to the view
 */
@Controller
public class MainController {

	@Autowired
	DailyTimesheetRepository dailyRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	MonthlyTimesheetRepository monthlyRepository;

	@Autowired
	TimesheetUserRepository timesheetUserRepository;

	@Autowired
	TimesheetRepository timesheetRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	RequestRepository requestRepository;

	@Autowired
	MessageSource msgSrc;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private UpdateUserValidator updateuserValidator;

	@Autowired
	TimesheetUserServiceImpl TimesheetUserImpl;

	@Autowired
	UserServiceImpl userserviceimpl;

	@Autowired
	RequestServiceImpl requestServiceImpl;

	@Autowired
	TimeSheetUserReportService timeSheetUserReportService;

	@Autowired
	HolidayService holidayService;

	@Autowired
	GroupRepository groupRepository;

	// value message save User success = 1
	@Value("${button.save.success}")
	private String messageSave;

	// value message update User = 2
	@Value("${button.updateInfo.success}")
	private String messageInfo;

	// value message changepassword = 3
	@Value("${button.updatePass.success}")
	private String messagePass;

	private CommonService commonservice = new CommonService();

	CommonValidator commonValidator = new CommonValidator();

	@Autowired
	TimeSheetUserReportService timesheetUserReportservice;

	@Autowired
	RequestServiceImpl requestService;

	// Temp list to store request list of before search
	public static List<Request> tmpRequestLst;

	@GetMapping("/403")
	public String accessDenied() {
		return "403";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout, Locale locale, HttpSession session,
			HttpServletRequest request) {
		LocaleContextHolder.setLocale(locale);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userName = auth.getName();
		User user = userRepository.findByUserId(userName);
		
		
		
		if (user != null && user.getDelFlg().equals("1")) {
			String typeUser = user.getRole().getRoleName();
			String name = user.getName();
			session.setAttribute("type", typeUser);
			session.setAttribute("name", name);
			return "CheckInOut";
		}

		if (error != null) {
			String userIdFail = (String) session.getAttribute("userFail");
			  
			String passwordFail = (String) session.getAttribute("passFail");
			model.addAttribute("userId",userIdFail);
			model.addAttribute("password",passwordFail);
				model.addAttribute("error", msgSrc.getMessage("msg.login.invalid", null, locale));
		}
			
			
		if (logout != null)
			model.addAttribute("message", msgSrc.getMessage("msg.logout", null, locale));
		
		return "login";
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String checkin(Model model, HttpSession session, HttpServletRequest req) throws ParseException {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String Name = auth.getName();
		User user = userRepository.findByUserId(Name);
		String typeUser = user.getRole().getRoleName();
		String userId = user.getUserId();
		Date montyearVal = commonservice.currentDate();
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		String yearmonthcurrent = df.format(montyearVal);
		String year = yearmonthcurrent.substring(0, 4);
		String month = yearmonthcurrent.substring(5, 7);

		// warning checkrequest
		String groupId = user.getGroup().getGroupId();
		if (typeUser.equals("ROLE_ADMIN")) {
			Integer countRequest = requestRepository.findCountReqPending("pending");
			model.addAttribute("countRequest", countRequest);
		} else if (typeUser.equals("ROLE_LEADER")) {
			Integer countRequest = requestRepository.findCountReqLeaderPending("pending", groupId);
			model.addAttribute("countRequest", countRequest);
		}

		// warning overtime
		TimesheetUser tsu = timesheetUserRepository.findByTimesheetUserUsId(userId, month, year);
		if (tsu != null) {
			Double overtimeDK = holidayService.getSumOvertimeDK(month, year);

			model.addAttribute("overtimeDK", overtimeDK);

		}

		// warning the times over 45,60,75 in one year from 4 ~ 3	
		
		int yearInt = Integer.parseInt(year);   	
    	int countOvertimeDK = 0;   	
    	int monthInt = Integer.parseInt(month);
    	if(monthInt > 3) {
	    	for(int yearDK = yearInt; yearDK <= yearInt + 1; yearDK++) {
	    		if(yearDK == yearInt) {
	    			String yearDKStr = String.valueOf(yearDK);
	    			
	        		for(int monthIntDK = 4; monthIntDK <= 12; monthIntDK++) {
	        			String monthStr = String.valueOf(monthIntDK);
	        			if(monthStr.length() == 1) {
	        				monthStr = "0" + monthStr;
	        			}
	        			TimesheetUser tsuDk = timesheetUserRepository.findByTimesheetUserUsId(userId,monthStr,yearDKStr);
	        			if(tsuDk != null) {
	        				double sumOverTimeDK = holidayService.getSumOvertimeDK(monthStr, yearDKStr);
	        				if (sumOverTimeDK >= 45 && sumOverTimeDK < 60) {
	        					countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 60 && sumOverTimeDK < 75) {
	    						countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 75) {
	    						countOvertimeDK += 1;
	    					}
	        			}
	        			 
	        		}
	    		}else if (yearDK == yearInt + 1) {
	    			String yearDKStr = String.valueOf(yearDK);
	    			
	    			for(int monthIntDK = 1; monthIntDK <= 3; monthIntDK++) {
	        			String monthStr = String.valueOf(monthIntDK);
	        			if(monthStr.length() == 1) {
	        				monthStr = "0" + monthStr;
	        			}
	        			TimesheetUser tsuDk = timesheetUserRepository.findByTimesheetUserUsId(userId,monthStr,yearDKStr);
	        			if(tsuDk != null) {
	        				double sumOverTimeDK = holidayService.getSumOvertimeDK(monthStr, yearDKStr);
	        				if (sumOverTimeDK >= 45 && sumOverTimeDK < 60) {
	        					countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 60 && sumOverTimeDK < 75) {
	    						countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 75) {
	    						countOvertimeDK += 1;
	    					}
	        			}
	        			 
	        		}
				}
	    		
	    	}
    	} else if(monthInt <= 3) {
    		for(int yearDK = yearInt - 1; yearDK <= yearInt; yearDK++) {
	    		if(yearDK == yearInt - 1) {
	    			String yearDKStr = String.valueOf(yearDK);
	    			
	        		for(int monthIntDK = 4; monthIntDK <= 12; monthIntDK++) {
	        			String monthStr = String.valueOf(monthIntDK);
	        			if(monthStr.length() == 1) {
	        				monthStr = "0" + monthStr;
	        			}
	        			TimesheetUser tsuDk = timesheetUserRepository.findByTimesheetUserUsId(userId,monthStr,yearDKStr);
	        			if(tsuDk != null) {
	        				double sumOverTimeDK = holidayService.getSumOvertimeDK(monthStr, yearDKStr);
	        				if (sumOverTimeDK >= 45 && sumOverTimeDK < 60) {
	        					countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 60 && sumOverTimeDK < 75) {
	    						countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 75) {
	    						countOvertimeDK += 1;
	    					}
	        			}
	        			 
	        		}
	    		}else if (yearDK == yearInt) {
	    			String yearDKStr = String.valueOf(yearDK);
	    			
	    			for(int monthIntDK = 1; monthIntDK <= 3; monthIntDK++) {
	        			String monthStr = String.valueOf(monthIntDK);
	        			if(monthStr.length() == 1) {
	        				monthStr = "0" + monthStr;
	        			}
	        			TimesheetUser tsuDk = timesheetUserRepository.findByTimesheetUserUsId(userId,monthStr,yearDKStr);
	        			if(tsuDk != null) {
	        				double sumOverTimeDK = holidayService.getSumOvertimeDK(monthStr, yearDKStr);
	        				if (sumOverTimeDK >= 45 && sumOverTimeDK < 60) {
	        					countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 60 && sumOverTimeDK < 75) {
	    						countOvertimeDK += 1;
	    					} if (sumOverTimeDK >= 75) {
	    						countOvertimeDK += 1;
	    					}
	        			}
	        			 
	        		}
				}
	    		
	    	}
    	}

		model.addAttribute("countOvertimeDK", countOvertimeDK);
		String name = user.getName();
		session.setAttribute("name", name);
		session.setAttribute("type", typeUser);
		return "CheckInOut";
	}

	@RequestMapping(value = "/checkInTime", method = RequestMethod.GET)
	public String checkInTime(Model model, HttpSession session, HttpServletRequest request) {
		String message = null;
		String daytime[] = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime()).split(":");
		int hours = Integer.parseInt((daytime[0]));
		String time = String.valueOf(String.format("%02d", hours)).concat(":" + daytime[1]);
		String checkInOut = request.getParameter("checkInOut");
		session.setAttribute("checkInOut", checkInOut);
		String actionCheckInOut = TimesheetUserImpl.insertOrupdate(session);
		// Display message "Please check in first."
		if (actionCheckInOut.equals("4")) {
			message = "message.havetocheckin";
		}
		// Display message "You already checked in. You cannot do it again."
		if (actionCheckInOut.equals("1")) {
			message = "message.checkedin";
			// Display message "You have been checked in successfully."
		} else if (actionCheckInOut.equals("0")) {
			message = "message.checkinSucess";
			// Display message "You have been checked out successfully."
		} else if (actionCheckInOut.equals("2")) {
			message = "message.checkoutSucess";
			// Display message "You already checked out. You cannot do it again."
		} else if (actionCheckInOut.equals("3")) {
			message = "message.checkedout";
		}

		// warning checkrequest
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String Name = auth.getName();
		User user = userRepository.findByUserId(Name);
		String typeUser = user.getRole().getRoleName();
		String groupId = user.getGroup().getGroupId();
		if (typeUser.equals("ROLE_ADMIN")) {
			Integer countRequest = requestRepository.findCountReqPending("pending");
			model.addAttribute("countRequest", countRequest);
		} else if (typeUser.equals("ROLE_LEADER")) {
			Integer countRequest = requestRepository.findCountReqLeaderPending("pending", groupId);
			model.addAttribute("countRequest", countRequest);
		}

		model.addAttribute("message", message);
		model.addAttribute("time", time);
		return "CheckInOut";
	}

	/* USER LIST SCREEN CONTROLLER */
	/* Processing to get all users */
	@RequestMapping(value = "/userList", method = RequestMethod.GET)
	public String getUserLst(Model model, HttpSession session) {
		// Get user list
		List<User> listUser = (List<User>) userRepository.findAll();
		model.addAttribute("listUser", listUser);
		return "UserList";
	}

	/* DAILY REPORT SCREEN CONTROLLER */
	/* Processing to get daily timesheet of all user */
	@RequestMapping(value = "/dailyTimesheet", method = RequestMethod.GET)
	public String getDailyData(@RequestParam("d") String date, Model model, HttpSession session) {
		// Get date, month, year value
		String yearVal = date.substring(0, 4);
		String monthVal = date.substring(5, 7);
		String dateVal = date.substring(8);
		// Get data list
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String Name = auth.getName();
		User user = userRepository.findByUserId(Name);
		String typeRole = user.getRole().getRoleName();
		String groupId = user.getGroup().getGroupId();
		if (typeRole.equals("ROLE_ADMIN")) {
			List<Timesheet> listTimesheet = dailyRepository.findAllTimesheetGroupAdmin(dateVal, monthVal, yearVal);
			model.addAttribute("listTimesheet", listTimesheet);
		} else if (typeRole.equals("ROLE_LEADER")) {
			List<Timesheet> listTimesheet = dailyRepository.findAllTimesheetGroupLeader(dateVal, monthVal, yearVal,
					groupId);
			model.addAttribute("listTimesheet", listTimesheet);
		}
		session.setAttribute("date", date);
		return "DailyTimesheet";
	}

	/* CHECK REQUEST SCREEN CONTROLLER */
	/* Processing to go Check request screen from User list screen */
	@RequestMapping(value = "/goCheckRequest", method = RequestMethod.GET)
	public String openPage(Model model, HttpSession session) {
		session.removeAttribute("tmpSearch");
		return "redirect:/CheckRequest";
	}

	/* Processing to load list of request */
	@RequestMapping(value = "/CheckRequest", method = RequestMethod.GET)
	public String loadData(Model model, HttpServletRequest request, HttpSession session) {
		String searchVal = request.getParameter("searchVal");
		String tmpSearch = (String) session.getAttribute("tmpSearch");
		String cond = (String) session.getAttribute("tmpCond");
		List<Request> listRequestSearch = null;

		// get groupid to find members for Leader checkRequest
		String groupid = (String) session.getAttribute("groupid");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userName = auth.getName();
		User user = userRepository.findByUserId(userName);
		String typeRole = user.getRole().getRoleName();
		model.addAttribute("typeRole", typeRole);

		// Get request list when redirection from User List screen
		if (searchVal == null && tmpSearch == null) {
			if (typeRole.equals("ROLE_ADMIN")) {
				listRequestSearch = requestRepository.findAllRequest();

			} else if (typeRole.equals("ROLE_LEADER")) {
				listRequestSearch = requestRepository.findAllRequestMemberGropup(groupid);

			}
		} else {
			// Get request list by searching function
			// Search by "Status"
			if (cond.equalsIgnoreCase("status")) {
				if (typeRole.equals("ROLE_ADMIN")) {
					listRequestSearch = requestRepository.findByStatusGroupAdmin(tmpSearch);
				} else if (typeRole.equals("ROLE_LEADER")) {
					// listRequestSearch = requestService.findByStatus(tmpSearch);
					listRequestSearch = requestRepository.findByStatus(tmpSearch, groupid);
				}
			}
			// Search by "dateFrom"
			if (cond.equalsIgnoreCase("date")) {
				// Check if search value has correct date format
				Map<String, String> mapChkDate = commonValidator.checkDateFormat(tmpSearch);
				// When search value match date format
				if (mapChkDate.get("showDateValidate") == null) {
					// Get date, month, year value
					String yearVal = tmpSearch.substring(0, 4);
					String monthVal = tmpSearch.substring(5, 7);
					String dateVal = tmpSearch.substring(8, 10);

					if (typeRole.equals("ROLE_ADMIN")) {
						listRequestSearch = requestRepository.findByDateGroupAdmin(yearVal + monthVal + dateVal);
					} else if (typeRole.equals("ROLE_LEADER")) {
						
						listRequestSearch = requestRepository.findByDate(yearVal + monthVal + dateVal, groupid);
					}
					// When search value don't match date format
				} else {
					model.addAttribute("error", mapChkDate);
					// Get request list from search result before
					listRequestSearch = tmpRequestLst;
				}
			}
			// Search by "User Id"
			if (cond.equalsIgnoreCase("id")) {
				if (typeRole.equals("ROLE_ADMIN")) {
					listRequestSearch = requestRepository.findByUserIdGroupAdmin(tmpSearch);
				} else if (typeRole.equals("ROLE_LEADER")) {
					
					listRequestSearch = requestRepository.findByUserId(tmpSearch, groupid);
				}
			}
			// Search by "Name"
			if (cond.equalsIgnoreCase("name")) {
				if (typeRole.equals("ROLE_ADMIN")) {
					listRequestSearch = requestRepository.findByNameGroupAdmin(tmpSearch);
				} else if (typeRole.equals("ROLE_LEADER")) {
					
					listRequestSearch = requestRepository.findByName(tmpSearch, groupid);
				}
			}
		}
		// Store the search result into temp request list
		tmpRequestLst = listRequestSearch;
		// Set request list to model
		model.addAttribute("listRequest", listRequestSearch);
		return "CheckRequest";
	}

	/* Processing to search list of request */
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(@RequestParam("cond") String cond, @RequestParam("searchVal") String searchVal, Model model,
			HttpSession session) {
		session.setAttribute("tmpSearch", searchVal);
		session.setAttribute("tmpCond", cond);
		return "redirect:/CheckRequest" + "?cond=" + cond + "&searchVal=" + searchVal;
	}

	/* Processing to accept request */
	@RequestMapping(value = "accept/{requestId}", method = RequestMethod.GET)
	public String acceptRequest(@PathVariable String requestId, Model model, HttpSession session)
			throws NumberFormatException, ParseException {
		String sessionUserid = (String) session.getAttribute("userid");
		requestService.acceptRequest(Integer.parseInt(requestId), sessionUserid);
		return "redirect:/CheckRequest";
	}

	/* Processing to deny request */
	@RequestMapping(value = "deny/{requestId}", method = RequestMethod.GET)
	public String denyRequest(@PathVariable String requestId, Model model, HttpSession session)
			throws NumberFormatException, ParseException {
		String sessionUserid = (String) session.getAttribute("userid");
		requestService.denyRequest(Integer.parseInt(requestId), sessionUserid);
		return "redirect:/CheckRequest";
	}

	/* MONTHLY TIMESHEET SCREEN CONTROLLER */
	@RequestMapping(value = "/monthlyTimesheet", method = RequestMethod.GET)
	public String MonthlyReport(Model model, @RequestParam("m") String mon, Locale locale, HttpSession session) {
		// Get date, month, year value
		String yearVal = mon.substring(0, 4);
		String monthVal = mon.substring(5);
		// Get message export
		String mes = (String) session.getAttribute("mesReport");
		session.removeAttribute("mesReport");

		List<TimesheetUser> listTimeSheetUser = new ArrayList<TimesheetUser>();
		List<TimesheetUser> listTimeSheetUserPrint = new ArrayList<TimesheetUser>();

		// get List data follow GROUP_ID
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String Name = auth.getName();
		User user = userRepository.findByUserId(Name);
		String typeRole = user.getRole().getRoleName();
		String groupId = user.getGroup().getGroupId();
		if (typeRole.equals("ROLE_ADMIN")) {
			listTimeSheetUser = timesheetUserRepository.findByMonthYearAdmin(yearVal, monthVal);
		} else if (typeRole.equals("ROLE_LEADER")) {
			listTimeSheetUser = timesheetUserRepository.findByMonthYearLeader(yearVal, monthVal, groupId);
		}

		List<String> date_name = new ArrayList<String>();
		List<Integer> date_name_diff = new ArrayList<Integer>();

		for (int i = 1; i <= 31; i++) {
			Calendar date = DateUtils.initDate(yearVal, monthVal, String.valueOf(i));
			if (date != null) {
				// Set date of week view
				date_name.add(date.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, locale));
				// Set date of week in If
				date_name_diff.add(date.get(Calendar.DAY_OF_WEEK));
			}
		}

		if (listTimeSheetUser.size() != 0 || listTimeSheetUser != null) {
			for (int i = 0; i < listTimeSheetUser.size(); i++) {

				TimesheetUser timesheetUser = new TimesheetUser();
				List<Timesheet> listTimeSheet = new ArrayList<Timesheet>();
				List<Timesheet> listTimesheetNew = new ArrayList<Timesheet>();

				timesheetUser = listTimeSheetUser.get(i);
				listTimeSheet = timesheetUser.getTimesheets();

				if (listTimeSheet.size() != 0 || listTimeSheet != null) {

					// Add 29 days false
					listTimesheetNew = timesheetUser.addTimeSheet(listTimeSheet, timesheetUser.getCountDayInMonth());

					// Add date null
					if (listTimesheetNew.size() < 31) {
						for (int k = listTimesheetNew.size() + 1; k <= 31; k++) {
							Timesheet timesheet = new Timesheet();
							timesheet.setTimeSum(0.0);
							listTimesheetNew.add(timesheet);
						}
					}
				}
				timesheetUser.setTimesheets(listTimesheetNew);
				listTimeSheetUserPrint.add(timesheetUser);
			}
		}

		model.addAttribute("listTimeSheetUser", listTimeSheetUserPrint);
		model.addAttribute("lstDayOfWeek", date_name);
		model.addAttribute("lstDayOfWeekDiff", date_name_diff);
		model.addAttribute("message", mes);

		return "MonthlyTimesheet";
	}

	/* ADD NEW USER SCREEN CONTROLLER */

	// show view form insert formation
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String registration(Model model, HttpServletRequest request, HttpSession session) {

		List<Role> lstrole = (List<Role>) roleRepository.findAll();
		List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
		// set model
		model.addAttribute("listGroup", listGroup);
		model.addAttribute("lstRole", lstrole);
		model.addAttribute("userForm", new User());
		model.addAttribute("userId", userserviceimpl.autoCodeUserId());
		model.addAttribute("staffId", userserviceimpl.autoCodeStaffId());
		return "AddUser";
	}

	// Insert staff information
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String insertOrupdateUser(@ModelAttribute("userForm") User userForm, BindingResult bindingResult,
			Model model, HttpSession session) throws ParseException {
		userValidator.validate(userForm, bindingResult);
		// get session userId
		String sessionUserid = (String) session.getAttribute("userid");
		List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
		List<Role> lstrole = (List<Role>) roleRepository.findAll();
		model.addAttribute("listGroup", listGroup);
		model.addAttribute("lstRole", lstrole);
		// check error input
		if (bindingResult.hasErrors()) {
			model.addAttribute("userId", userserviceimpl.autoCodeUserId());
			model.addAttribute("staffId", userserviceimpl.autoCodeStaffId());
			return "AddUser";
		}

		userForm.setCreateId(sessionUserid);
		userserviceimpl.insertOrupdate(userForm);
		model.addAttribute("message", messageSave);
		model.addAttribute("userId", userserviceimpl.autoCodeUserId());
		model.addAttribute("staffId", userserviceimpl.autoCodeStaffId());
		model.addAttribute("userForm", new User());

		return "AddUser";
	}

	// Update Staff information
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model,
			HttpSession session, final RedirectAttributes redirectAttributes) throws ParseException {
		updateuserValidator.validate(userForm, bindingResult);

		// contructor user
		List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
		List<Role> lstrole = (List<Role>) roleRepository.findAll();
		String sessionUserid = (String) session.getAttribute("userid");
		User u = new User();
		u = userRepository.findByUserId(userForm.getUserId());

		String sttus = u.getDelFlg();

		if (sttus.equals("1")) {
			// check error input
			if (bindingResult.hasErrors()) {
				redirectAttributes.addFlashAttribute("bindingResult", bindingResult);
				redirectAttributes.addFlashAttribute("userForm", userForm);
				return "redirect:/updateUser" + "?userid=" + userForm.getUserId();
			}

			model.addAttribute("lstRole", lstrole);
			model.addAttribute("listGroup", listGroup);
			userForm.setCreateId(u.getCreateId());
			userForm.setUpdateId(sessionUserid);
			userserviceimpl.insertOrupdate(userForm);
			return "redirect:/updateUser" + "?userid=" + userForm.getUserId() + "&updateUser=" + messageInfo;
		} else {
			userForm.setName(u.getName());
			userForm.setPhone(u.getPhone());
			userForm.setRole(u.getRole());
			userForm.setGroup(u.getGroup());
			userForm.setCreateId(u.getCreateId());
			userForm.setUpdateId(sessionUserid);
			userserviceimpl.insertOrupdate(userForm);
			return "redirect:/updateUser" + "?userid=" + userForm.getUserId() + "&updateUser=" + messageInfo;

		}

	}

	// Show view form update information
	@RequestMapping(value = "/updateUser", method = RequestMethod.GET)
	public String updateInfo(Model model, HttpServletRequest request, @ModelAttribute("userForm") final User userForm,
			Locale locale) {

		// get parameter date
		String userId = request.getParameter("userid");
		String resetPass = request.getParameter("resetPass");
		String updateuser = request.getParameter("updateUser");

		User user = new User();
		user = userserviceimpl.searchUserId(userId);

		String status = user.getDelFlg();

		List<Groups> listGroup = (List<Groups>) groupRepository.findAll();
		List<Role> lstrole = (List<Role>) roleRepository.findAll();
		Map<String, String> mapStatus = new HashMap<String, String>();
		String localeString = locale.toString();
		// Set date of week English
		if (localeString.equalsIgnoreCase("en")) {
			mapStatus = commonservice.mapStatus("en");
		} else if (localeString.equalsIgnoreCase("ja_JP")) {
			mapStatus = commonservice.mapStatus("ja_JP");
		}
		// set model
		model.addAttribute("status", status);
		model.addAttribute("listGroup", listGroup);
		model.addAttribute("listStaus", mapStatus);
		model.addAttribute("lstRole", lstrole);
		model.addAttribute("userForm", user);

		if (resetPass != null) {
			// set message value "Reseted Password Success!"

			model.addAttribute("message", messagePass);
		}
		if (updateuser != null) {
			// set message value "Update Information Success!"
			model.addAttribute("message", messageInfo);
		}

		if (model.asMap().containsKey("bindingResult")) {
			model.addAttribute("org.springframework.validation.BindingResult.userForm",
					model.asMap().get("bindingResult"));
		}

		return "UpdateUser";
	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteUser(Model model, HttpServletRequest request, Locale locale) {

		String userId = request.getParameter("userid");

		User user = userRepository.findByUserId(userId);
		List<Request> requests = requestRepository.findByUserId(userId);

		if (requests != null) {
			for (Request rq : requests) {
				requestRepository.delete(rq);
			}
		}

		List<TimesheetUser> timesheetUsers = user.getTimesheetUsers();

		if (timesheetUsers != null) {
			for (TimesheetUser tsu : timesheetUsers) {
				List<Timesheet> timesheets = timesheetRepository.findByListTimesheetId(tsu.getTimesheetUserId());
				for (Timesheet ts : timesheets) {
					timesheetRepository.delete(ts);
				}
				timesheetUserRepository.delete(tsu);
			}
		}

		userRepository.delete(user);
		List<User> listUser = (List<User>) userRepository.findAll();

		model.addAttribute("listUser", listUser);
		return "UserList";

	}

	// show view form changepassword
	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	public String changePassword(Model model, HttpSession session) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userName = auth.getName();
		User user = userRepository.findByUserId(userName);
		String idUser = user.getUserId();
		model.addAttribute("pwdChangeFlg", user.getPwdFlg());
		session.setAttribute("userName", user.getName());
		session.setAttribute("userid", idUser);
		return "ChangePassword";
	}

	// Update password staff delpwdflg ='1'
	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public String updatePassword(Model model, HttpServletRequest request, HttpSession session) {
		User user = new User();

		Map<String, String> maperrors = new HashMap<String, String>();
		// get value password input
		String passwordold = request.getParameter("passwordold");
		String passwordnew = request.getParameter("passwordnew");
		String passwordconfirm = request.getParameter("passwordconfirm");
		String userId = (String) session.getAttribute("userid");
		// get model User
		user = userRepository.findByUserId(userId);

		// Check password input
		maperrors = commonValidator.checkChangePassword(passwordold, passwordnew, passwordconfirm, user);

		// check input password in form
		if (maperrors.size() > 0) {
			model.addAttribute("confirmPass", maperrors);
			return "ChangePassword";
		}

		// service reset password
		userserviceimpl.updatePassword(user, passwordnew);
		model.addAttribute("message", messagePass);

		return "ChangePassword";
	}

	// reset password staff delpwdflg ='0'
	@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
	public String resetPassword(Model model, HttpServletRequest request, HttpSession session) {
		User user = new User();
		String userId = request.getParameter("userid");
		user = userRepository.findByUserId(userId);
		// service reset password
		userserviceimpl.resetPassword(user);

		model.addAttribute("resetPass", "resetpass");
		return "redirect:/updateUser" + "?userid=" + userId;
	}

	// show view List MyTimeSheet of staff
	@RequestMapping(value = "/myTimesheet", method = RequestMethod.GET)
	public String myTimesheet(Model model, HttpServletRequest request, HttpSession session, Locale locale)
			throws ParseException {
		// get userid to session
		Date currentDate = commonservice.currentDate();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String currentDateStr = df.format(currentDate);

		String useridRq = request.getParameter("userid");
		String flg = request.getParameter("flg");
		String buttontRq = "true";
		String userid = "";
		String userIdsame = "";
		if (useridRq != null && flg != null) {
			userid = useridRq;
			buttontRq = "false";
			userIdsame = useridRq.equals((String) session.getAttribute("userid")) ? "same" : "";
		} else {
			userid = (String) session.getAttribute("userid");
		}
		String montyearVal = request.getParameter("m");
		String yearVal = montyearVal.substring(0, 4);
		String monthVal = montyearVal.substring(5, 7);

		TimesheetUser timesheetUser = new TimesheetUser();
		timesheetUser = timeSheetUserReportService.myTimeSheet(userid, monthVal, yearVal);
		// check error checkInOut
		int countErro = 0;
		List<Timesheet> listTimesheet = timesheetRepository.findAllTimesheets(userid, monthVal, yearVal);
		if(listTimesheet.size() != 0) {
			for (Timesheet ts : listTimesheet) {
				String dateOfts = ts.getDate();
				String dateOfTs = yearVal + monthVal + dateOfts;
				if ((!ts.getTimeIn().equals("") && ts.getTimeOut().equals("")) && !dateOfTs.equals(currentDateStr)) {
					countErro += 1;
				}
			}
		}
		

		// Get message export
		String mes = (String) session.getAttribute("mesReport");
		session.removeAttribute("mesReport");
		// count Holiday
		Integer countHoli = (Integer) session.getAttribute("countHoli");
		// find max RequestId
		

		// Add Date Of Week
		List<String> date_name = new ArrayList<String>();
		List<Integer> date_name_diff = new ArrayList<Integer>();

		for (int i = 1; i <= 31; i++) {
			Calendar date = DateUtils.initDate(yearVal, monthVal, String.valueOf(i));
			if (date != null) {
				// Set date of week view
				date_name.add(date.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, locale));
				// Set date of week in If
				date_name_diff.add(date.get(Calendar.DAY_OF_WEEK));

			}
		}
		
		model.addAttribute("countErro", countErro);
		model.addAttribute("countHoli", countHoli);
		model.addAttribute("timesheetUsers", timesheetUser);
		model.addAttribute("listDayOfWeek", date_name);
		model.addAttribute("lstDayOfWeekDiff", date_name_diff);
		model.addAttribute("message", mes);
		model.addAttribute("messagetimesheet", buttontRq);

		// request userId same session userId
		model.addAttribute("useridsame", userIdsame);
		// userid export mytimesheet
		model.addAttribute("Id", userid);
		// title Timesheet and move page monthly timesheet to my timesheet
		model.addAttribute("buttontRq", buttontRq);
		model.addAttribute("Locale", locale.toString());
		return "MyTimeSheet";
	}

	@RequestMapping(value = "/sendRequest", method = RequestMethod.POST)
	public @ResponseBody Request SendRequest(Model model, @RequestParam("date-request") String month_year,
			@RequestParam("time_in_request") String timeInRequest,
			@RequestParam("time_out_request") String timeoutRequest, @RequestParam("time_in") String timein,
			@RequestParam("time_out") String timeout, @RequestParam("reason") String reason,
			@RequestParam("note") String note, HttpSession session)
			throws ParseException {

		Request formRequest = new Request();

		formRequest.setTimeInRequest(timeInRequest);
		formRequest.setTimeOutRequest(timeoutRequest);
		formRequest.setReason(reason);
		formRequest.setNote(note);
		formRequest.setTimeIn(timein);
		formRequest.setTimeOut(timeout);
		// substring mont, year, day
		String yearVal = month_year.substring(0, 4);
		String monthVal = month_year.substring(5, 7);
		String date = month_year.substring(8);

		// check date number length < 10
		if (date.length() == 1) {
			date = "0" + date;
		}
		formRequest.setDateFrom(yearVal + monthVal + date);
		formRequest.setDateTo(yearVal + monthVal + date);
		String userid = (String) session.getAttribute("userid");
		requestServiceImpl.insertRequest(date, monthVal, yearVal, userid, formRequest);
		return formRequest;
	}

	@RequestMapping(value = "/changeTime", method = RequestMethod.GET)
	@ResponseBody
	public String changeTime(Model model, @RequestParam("time_in") String timein,
			@RequestParam("time_out") String timeout, @RequestParam("timesheetId") String timesheetId,
			HttpSession session) {

		Timesheet timesheet = timesheetRepository.findByTimesheetId(timesheetId);
		if (timesheet != null) {
			timein = timein.replace(":", "");
			timeout = timeout.replace(":", "");
			int year = Integer.parseInt(timesheet.getTimesheetUser().getYear());
			int month = Integer.parseInt(timesheet.getTimesheetUser().getMonth());
			int date = Integer.parseInt(timesheet.getDate());

			int dayofweek = DateUtils.initDate(year, month, date).get(Calendar.DAY_OF_WEEK);

			timesheet.setTimeIn(timein);
			timesheet.setTimeOut(timeout);
//			timesheet.setTimeLate(timein);
			timesheet.setTimeSum(timein);

			if (dayofweek == 1 || dayofweek == 7) {
				timesheet.setTimeWeOt(timesheet.calculateTimeOt(timeout));
				timesheet.setTimeWeOn(timesheet.calculateTimeOn(timeout));
			} else {
				timesheet.setTimeOt(timesheet.calculateTimeOt(timeout));
				timesheet.setTimeOn(timesheet.calculateTimeOn(timeout));
			}

			timesheetRepository.save(timesheet);
			return "success";
		}

		return "fail";
	}

	// Search User
	@RequestMapping(value = "/searchUser", method = RequestMethod.GET)
	public String searchUser(Model model, @RequestParam("searchVal") String search, HttpSession session,
			HttpServletRequest request) {
		String searchVal = request.getParameter("searchVal");
		String cond = request.getParameter("cond");
		if (cond.equalsIgnoreCase("id")) {
			List<User> listUser = userRepository.listSearchUserId(searchVal);
			model.addAttribute("listUser", listUser);
		} else if (cond.equalsIgnoreCase("name")) {
			List<User> listUser = userRepository.listSearchName(searchVal);
			model.addAttribute("listUser", listUser);
		} else {
			List<User> listUser = userRepository.listSearchGroupName(searchVal);
			model.addAttribute("listUser", listUser);
		}

		return "UserList";
	}

}
