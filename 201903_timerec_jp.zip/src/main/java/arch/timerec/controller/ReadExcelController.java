package arch.timerec.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import arch.timerec.model.Holiday;
import arch.timerec.model.Special;
import arch.timerec.repository.HolidayRepository;
import arch.timerec.repository.SpecialRepository;

@Controller
public class ReadExcelController {

	@Autowired
	SpecialRepository specialRepository;

	@Autowired
	HolidayRepository holidayRepository;

	private static final String FILE_NAME = "/excel-format/holiday-format.xlsx";
	private static final String APPLICATION_XLSX = "application/xlsx";

	// find List Holiday
	@RequestMapping(value = "/SpecialList")
	public String listHoliday(Model model) {
		List<Special> listOfSpecial = (List<Special>) specialRepository.findAll();
		model.addAttribute("listOfSpecial", listOfSpecial);
		List<Holiday> listOfHol = (List<Holiday>) holidayRepository.findAll();
		model.addAttribute("listOfHol", listOfHol);

		return "Special";
	}

	// DownLoad File Format
	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public void downloadFile(HttpServletResponse response) throws IOException {
		File file = new ClassPathResource(FILE_NAME).getFile();
		InputStream inputStream = new FileInputStream(file);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");
		response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);

		ServletOutputStream outputStream = response.getOutputStream();
		IOUtils.copy(inputStream, outputStream);

		outputStream.close();
		inputStream.close();

	}

	@RequestMapping(value = "/processExcelSpecial", method = RequestMethod.POST)
	public @ResponseBody String processExcel2007(@RequestParam("excelName") MultipartFile excelName, Model model,HttpServletRequest request) {
		HttpSession session = request.getSession();
		List<Special> listOfSpecial = new ArrayList<>();
		List<Holiday> listOfHol = new ArrayList<>();
		String yearHoliday, yearSpecicalDay;
		yearHoliday = yearSpecicalDay = new String();
		String fileName2 = excelName.getOriginalFilename();
		String fileName[] = fileName2.split("\\.");

		if (!fileName[1].equals("xlsx")) {
			return "File Invalid";
		}
		int countError = 0;
		try {
			int i = 1;// Don't get title
			// Creates a workbook object from the uploaded excelfile
			XSSFWorkbook workbook = new XSSFWorkbook(excelName.getInputStream());
			// Creates a worksheet object representing the first sheet
			XSSFSheet worksheet = workbook.getSheetAt(0);
			int sheetLastRow1 = workbook.getSheetAt(0).getPhysicalNumberOfRows() -1;
			int sheetLastRow2 = workbook.getSheetAt(1).getPhysicalNumberOfRows() -1;
			// Reads the data in excel file until last row is encountered
			
			if (sheetLastRow1 < 1 || sheetLastRow2 < 1) {
				return "NoData";
			}
			while (i <= sheetLastRow1) {
				XSSFRow rowYear = worksheet.getRow(1);
				DateFormat formatteryear = new SimpleDateFormat("yyyyMMdd");
				Date year = new Date();
				try {
					year = rowYear.getCell(0).getDateCellValue();
				} catch (Exception ex) {
					throw new IllegalStateException();
				}
				String yearString = formatteryear.format(year);
				yearSpecicalDay = yearString.substring(0, 4);
				
				// Creates an object for the Special Model
				Special special = new Special();
				// Creates an object representing a single row in excel
				XSSFRow row = worksheet.getRow(i++);
				// Sets the Read data to the model class
				// special.setId(row.getCell(0).getStringCellValue());
				// convert Date to String
				DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
				Date date = row.getCell(0).getDateCellValue();
				String dateString = formatter.format(date);
				
				special.setDate(dateString);
				special.setConTent(row.getCell(1).getStringCellValue());
				special.setWorking_Time(new Double(row.getCell(2).getNumericCellValue()));

				// persist data into database in here
				listOfSpecial.add(special);
			}
			worksheet = workbook.getSheetAt(1);
			i = 1;

			while (i <= sheetLastRow2) {
				XSSFRow rowYear = worksheet.getRow(1);
				DateFormat formatteryear = new SimpleDateFormat("yyyyMMdd");
				Date year = new Date();
				try {
					year = rowYear.getCell(0).getDateCellValue();
				} catch (Exception ex) {
					throw new IllegalStateException();
				}
				String yearString = formatteryear.format(year);
				yearHoliday = yearString.substring(0, 4);

				// Creates an object for the Holiday Model
				Holiday hol = new Holiday();
				// Creates an object representing a single row in excel
				XSSFRow row = worksheet.getRow(i++);
				// Sets the Read data to the model class
				// hol.setHolId(row.getCell(0).getStringCellValue());
				// convert Date to String
				DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
				Date date = row.getCell(0).getDateCellValue();
				String dateString = formatter.format(date);
				hol.setDate(dateString);
				hol.setDateOfWeek(row.getCell(1).getStringCellValue());
				hol.setName(row.getCell(2).getStringCellValue());

				// persist data into database in here

				listOfHol.add(hol);
			}

			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
			if(e.getClass().equals(IllegalStateException.class)) {
				countError = 1;
			}
		} 
		
		if(countError != 0) {
			return "Invalid Format Date";			
		}else {
			if (!yearSpecicalDay.isEmpty()) {
				String idValues = specialRepository.getListIdByYear(yearSpecicalDay);
				if (idValues != null) {
					List<Special> listSpeial = new ArrayList<>();
					for (String item : idValues.split(",")) {
						Special spc = new Special();
						spc.setId(Integer.parseInt(item));
						listSpeial.add(spc);
					}
					specialRepository.delete(listSpeial);
				}
			}
			if (!yearHoliday.isEmpty()) {
				String idValues = holidayRepository.getListIdByYear(yearHoliday);
				if (idValues != null) {
					List<Holiday> listHol = new ArrayList<>();
					for (String item : idValues.split(",")) {
						Holiday hol = new Holiday();
						hol.setHolId(Integer.parseInt(item));
						listHol.add(hol);
					}
					holidayRepository.delete(listHol);
				}
			}
			holidayRepository.save(listOfHol);
			specialRepository.save(listOfSpecial);
		}
		
		session.setAttribute("uploadsuccess", "success");
		return "/SpecialList";
	}

}
