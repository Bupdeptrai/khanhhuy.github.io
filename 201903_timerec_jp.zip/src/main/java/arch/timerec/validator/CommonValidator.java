/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: nguyen-dinhtoan
 * Create day: 2017/12/13
 * Version: 1.0
 */
package arch.timerec.validator;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import arch.timerec.model.User;

public class CommonValidator {
    
          Pattern specailCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        Pattern lowerCasePatten = Pattern.compile("[a-z ]");
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");
      

    BCryptPasswordEncoder bcryPassEncoder = new BCryptPasswordEncoder();
    public Map<String, String> checkChangePassword (String pwdold, String pwdnew, String pwdConfirm, User user) {
        Map<String, String> mapCheck = new HashMap<String, String>();
        if (pwdold.isEmpty()) {
            // set Password old
            mapCheck.put("pwdoldem", "1");
        }
        if (pwdnew.isEmpty()) {
            // set Password new
            mapCheck.put("pwdnewem", "2");
        }
        if (pwdConfirm.isEmpty()) {
            // confirm Password new
            mapCheck.put("pwdconfirmem", "3");
        }
        if(!bcryPassEncoder.matches(pwdold, user.getPassword())) {
            // password old invalid
            mapCheck.put("invalidpwdold", "4");
        }
        
        if(pwdnew.length() < 8 || pwdnew.length() > 50) {
            // size password new
            mapCheck.put("sizepwdnew", "5");
        }
        
        if(!pwdnew.equals(pwdConfirm)) {
            // check confirm password new
            mapCheck.put("confirmpwdnew", "6");
        }
        
        if (!specailCharPatten.matcher(pwdnew).find()) {
            // password specailCharPatten
            mapCheck.put("specailpwdnew", "7");
        }
        if (!UpperCasePatten.matcher(pwdnew).find()) {
            // Password UpperCasePatten
            mapCheck.put("Upperpwdnew", "8");
        }
        
        if (!lowerCasePatten.matcher(pwdnew).find()) {
            // Password lowerCasePatten
            mapCheck.put("lowerpwdnew", "9");
        }
        
        if(bcryPassEncoder.matches(pwdnew, user.getPassword())) {
            // password old some password new
            mapCheck.put("pwdnewsamepwdold", "10");
        }
        
        return mapCheck;
    }
    
    public Map<String, String> checkDateFormat(String value) {
        Map<String, String> chkDateMap = new HashMap<String, String>();
        Pattern pattern = Pattern.compile("([12]\\d{3}/(0?[1-9]|1[0-2])/(0?[1-9]|[12][0-9]|3[01])$)",
                Pattern.CASE_INSENSITIVE);
        if(!pattern.matcher(value).matches()){
            chkDateMap.put("showDateValidate", "1");
        }
        return chkDateMap;
    }
}

