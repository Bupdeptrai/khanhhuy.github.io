/*
 * System name: Time record system
 * Company name: ARCH-VN
 * Author: nguyen-dinhtoan
 * Create day: 2017/11/30
 * Version: 1.0
 */

package arch.timerec.validator;

import arch.timerec.model.User;
import arch.timerec.repository.UserRepository;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/*
 * Class name: UserValidator
 *
 * Validate inputted value for I/U user
 */
@Component
public class UserValidator implements Validator {
    @Autowired
    private UserRepository userRepository;

    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object obj, Errors errors) {
        try {
        User user = (User) obj;

        // Check pattern email
        Pattern pattern = Pattern.compile("[A-Z0-9_]+[A-Z0-9._+-]+@[A-Z0-9]+[A-Z.-]+[A-Z]+\\.[A-Z]{2,3}$", Pattern.CASE_INSENSITIVE);
        Pattern patternphone = Pattern.compile("[0-9]+[0-9]$", Pattern.CASE_INSENSITIVE);

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "msg.validate.notempty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "msg.validate.notempty");
        
      

        
        // check name exist number
        if (!user.getName().equals("")) {
            for (int i = 0; i < user.getName().length(); i++) {
                if (Character.isDigit(user.getName().charAt(i))) {
                    errors.rejectValue("name", "msg.validate.name.number");
                    break;
                }
            }
        }

        // check phone exist character and size > 20
        if (!user.getPhone().equals("")) {
            if (!(patternphone.matcher(user.getPhone()).matches())) {
                errors.rejectValue("phone", "msg.validate.phone.character");
            }
            
            if (user.getPhone().length() > 20 ) {
                errors.rejectValue("phone", "msg.validate.phone.size");
            }
        }
        
        // value email not blank
        if (!user.getEmail().equals("")) {

            // check email exist
            if (userRepository.findByEmail(user.getEmail()) != null) {
                errors.rejectValue("email", "msg.validate.email.dup");
            }

            // check email match pattern
            if (!(pattern.matcher(user.getEmail()).matches())) {
                errors.rejectValue("email", "msg.validate.email.invalid");
            } else {
                
                // check email full size
                if (user.getEmail().getBytes("UTF8").length != user.getEmail().length()) {
                    errors.rejectValue("email", "msg.validate.email.invalid");
                }
            }
                
        }
        
        }catch (Exception e) {
            e.printStackTrace();
        }{
            
        }

    }

}
