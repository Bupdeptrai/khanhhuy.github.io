timerec_jp
