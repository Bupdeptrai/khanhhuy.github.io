const withSaSS = require('@zeit/next-sass')
module.exports = withSaSS()