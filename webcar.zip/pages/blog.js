import React from 'react';
import BaseLayout from '../components/layouts/BaseLayout';



class Blog extends React.Component {
  render() {
    return (
      <BaseLayout>
        <h1>I am Blog Page</h1>
      </BaseLayout>
    )
  }
}

export default Blog;