import React from 'react';
import BaseLayout from '../components/layouts/BaseLayout';

class Cv extends React.Component {
  render() {
    return (
      <BaseLayout>
        <h1>I am Cv Page</h1>
      </BaseLayout>
    )
  }
}

export default Cv;