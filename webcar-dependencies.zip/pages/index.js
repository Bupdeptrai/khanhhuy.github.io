const Index = () =>
  <div> Welcome Page</div>
export default Index;